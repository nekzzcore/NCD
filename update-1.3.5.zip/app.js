// ===== GoalTracker Pro - Main Application =====

// ☁️ Облачный сервер (настраивается в Настройки → Синхронизация, пусто = локально)
const CLOUD_URL = '';

// 📦 Версия встроенного бандла (должна совпадать с package.json / version.json на сервере)
const APP_VERSION = '1.3.5';
// 🌐 Сервер обновлений (version.json + updates/latest.zip)
const UPDATE_BASE_URL = 'https://goaltracker-pro.sayonara778.workers.dev';

const nativeUpdater = window.Capacitor?.Plugins?.CapacitorUpdater;

class GoalTracker {
    constructor() {
        this.user = null;
        this.goals = [];
        this.achievements = [];
        this.habits = [];
        this.events = [];
        this.notes = {};
        this.settings = {
            theme: 'dark',
            notifications: true,
            habitReminders: false,
            deadlineWarnings: true,
            calendarReminders: true,
            streakAlerts: true,
            notificationSound: true,
            notificationVibration: true,
            reminderDays: 3,
            gamification: true,
            autoSync: true
        };
        this.updatedAt = null;
        this._dirty = false;
        this._syncTimer = null;
        this._dataEpoch = 0;
        this._resetting = false;
        this.gamification = {
            xp: 0,
            level: 1,
            hp: 100,
            maxHp: 100,
            streak: 0,
            lastActiveDate: null,
            badges: [],
            completedGoals: 0,
            totalHabits: 0,
            activeHabits: 0,
            earlyCompletions: 0,
            lateCompletions: 0,
            skipProtectionPotions: 0,
            injuryDebuffUntil: null,
        };
        this.currentView = 'profile';
        this.currentMonth = new Date();
        this.selectedDate = null;
        this.notificationManager = null;
        this.deferredPrompt = null;
        this.gamificationEngine = null;
        this.init();
    }

    init() {
        this.loadData();
        
        // Preserve legacy RPG data without starting its engine or interface effects.
        this.gamificationEngine = null;

        this.bindEvents();
        this.initTheme();

        // Инициализация менеджера уведомлений
        if (window.NotificationManager) {
            this.notificationManager = new window.NotificationManager(this);
            this.notificationManager.init().then(() => {
                this.rescheduleAllNotifications();
            });
        }

        if (this.user) {
            this.showApp();
        } else {
            this.showAuth();
            // Новое устройство: сетевой автовход только после первой отрисовки.
            if (this.settings.autoSync) {
                setTimeout(() => { if (!this.user) this.syncData(true); }, 6500);
            }
        }
    }

    // ===== Auth =====
    showAuth() {
        document.getElementById('authScreen').style.display = 'flex';
        document.getElementById('app').style.display = 'none';
        window.avatarVideo?.refresh();

        if (this.authBound) return;
        this.authBound = true;

        // Avatar selector
        document.querySelectorAll('.avatar-option').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.avatar-option').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
            });
        });

        document.getElementById('authForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            if (this._creatingProfile || this.user) return;
            const nickname = document.getElementById('authNickname').value.trim();
            const avatar = document.querySelector('.avatar-option.active')?.dataset.avatar || '😊';

            if (nickname.length < 2) {
                this.showToast('Никнейм должен быть от 2 символов', 'error');
                return;
            }

            this._creatingProfile = true;
            this.user = {
                id: crypto.randomUUID(),
                nickname: nickname,
                avatar: avatar,
                createdAt: new Date().toISOString()
            };
            const saved = await this.saveData();
            this._creatingProfile = false;
            if (!saved) { this.user = null; return; }
            this.showApp();
            this.showToast(`Добро пожаловать, ${nickname}! 🎉`, 'success');
        });
    }

    updateGreeting() {
        const hour = new Date().getHours();
        let greeting = 'Добрый день';
        if (hour < 6) greeting = 'Доброй ночи';
        else if (hour < 12) greeting = 'Доброе утро';
        else if (hour < 18) greeting = 'Добрый день';
        else greeting = 'Добрый вечер';
        document.getElementById('dashboardGreeting').textContent = `${greeting}, ${this.user?.nickname || ''}! 👋`;
    }

    showApp() {
        document.getElementById('authScreen').style.display = 'none';
        document.getElementById('app').style.display = 'flex';

        this.updateGreeting();

        this.render();
        this.checkDeadlines();
        this.checkTodayNotes();

        // Supabase attach восстанавливает сессию по сети. Не запускаем его в
        // критическом пути первой отрисовки Android WebView.
        clearTimeout(this._cloudAttachTimer);
        this._cloudAttachTimer = setTimeout(() => window.CloudSync?.attach(this), 5500);

        // В Capacitor локальный сервер и так работает офлайн. Service Worker там
        // нельзя оставлять: его старый cache-first кэш может перекрыть новый OTA-бандл.
        if ('serviceWorker' in navigator) {
            if (window.Capacitor?.isNativePlatform?.()) {
                navigator.serviceWorker.getRegistrations()
                    .then(registrations => Promise.all(registrations.map(registration => registration.unregister())))
                    .catch(() => {});
                if ('caches' in window) {
                    caches.keys()
                        .then(keys => Promise.all(keys.filter(key => key.startsWith('goaltracker-')).map(key => caches.delete(key))))
                        .catch(() => {});
                }
            } else {
                navigator.serviceWorker.register('/sw.js').catch(() => {});
            }
        }

        // PWA Install Prompt
        let deferredPrompt = null;
        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            deferredPrompt = e;
            this.showInstallButton();
        });
        window.addEventListener('appinstalled', () => {
            deferredPrompt = null;
            this.hideInstallButton();
            this.showToast('Приложение установлено! 🎉', 'success');
        });
        // Сохраняем ссылку на prompt для использования в UI
        this.deferredPrompt = deferredPrompt;

        // Тихая синхронизация при запуске (подтянуть данные с сервера)
        if (this.settings.autoSync) {
            setTimeout(() => this.syncData(true), 7000);
        }
    }

    async resetProfile() {
        if (!confirm('Сбросить профиль и все локальные данные? Это действие нельзя отменить. Серверные копии не удаляются.')) return;
        this._resetting = true;
        this._dataEpoch++;
        clearTimeout(this._syncTimer);
        try {
            await this.cancelAllNotifications();
            window.CloudSync?.prepareLocalReset();
            await window.ProfileStorage.reset();
            location.reload();
        } catch (error) {
            this._resetting = false;
            this.showToast('Не удалось сбросить данные: ' + error.message, 'error');
        }
    }

    // ===== Data Management =====
    loadData() {
        const data = window.ProfileStorage.get();
        if (!data) return;
        this._storedExtras = data;
        this.user = data.user || null;
        this.goals = data.goals || [];
        this.achievements = data.achievements || [];
        this.habits = Array.isArray(data.habits) ? data.habits : [];
        this.events = data.events || [];
        this.notes = data.notes || {};
        this.settings = { ...this.settings, ...(data.settings || {}) };
        this.settings.habitReminders = false;
        this.gamification = { ...this.gamification, ...(data.gamification || {}) };
        this.updatedAt = data.updatedAt || null;
        this.notes = this.normalizeNotes(this.notes);
    }

    serialize() {
        return {
            ...this._storedExtras,
            schemaVersion: 1,
            profileReset: this.user ? false : !!this._storedExtras?.profileReset,
            user: this.user,
            goals: this.goals,
            achievements: this.achievements,
            habits: this.habits,
            events: this.events,
            notes: this.notes,
            settings: this.settings,
            gamification: this.gamification,
            updatedAt: this.updatedAt
        };
    }

    async saveData({ deferAutoSync = false } = {}) {
        if (this._resetting) return false;
        this._dirty = true;
        const saved = await this.persistData();
        if (saved && !deferAutoSync) this.scheduleAutoSync();
        return saved;
    }

    async persistData() {
        try {
            await window.ProfileStorage.save(this.serialize());
            try { window.CloudSync?.localChanged(); } catch {}
            return true;
        } catch (error) {
            console.error('Profile save failed:', error);
            this.showToast('Не удалось сохранить профиль. Экспортируйте данные и проверьте свободное место.', 'error');
            return false;
        }
    }

    scheduleAutoSync() {
        if (window.CloudSync?.configured()) { window.CloudSync.localChanged(); return; }
        if (this._resetting || !this.settings.autoSync || !this.user) return;
        clearTimeout(this._syncTimer);
        this._syncTimer = setTimeout(() => this.syncData(true), 2000);
    }

    getSyncBase() {
        // Синхронизация только если явно задан URL в настройках
        if (this.settings.syncUrl) return this.settings.syncUrl.replace(/\/$/, '');
        // По умолчанию — никакого сервера (автономный режим)
        return '';
    }

    // ===== Код доступа (PIN) =====
    // В автономном режиме не нужен. Оставлен для совместимости при включении синхронизации.
    getPin() {
        try { return localStorage.getItem('goalTracker_pin') || ''; }
        catch { return ''; }
    }

    setPin(pin) {
        try { localStorage.setItem('goalTracker_pin', pin); } catch {}
    }

    // В Electron код берётся из pin.txt автоматически — вводить не нужно
    async ensurePin() {
        if (this.getPin()) return;
        if (window.electronAPI?.getSyncPin) {
            try {
                const pin = await window.electronAPI.getSyncPin();
                if (pin) this.setPin(pin);
            } catch {}
        }
    }

    async apiFetch(base, init = {}) {
        await this.ensurePin();
        const headers = { ...(init.headers || {}) };
        const pin = this.getPin();
        if (pin) headers['X-Goal-PIN'] = pin;
        return fetch(base + '/api/data', { ...init, headers });
    }

    showPinModal(message) {
        const modal = document.getElementById('pinModal');
        if (modal.classList.contains('active')) return;
        document.getElementById('pinForm').reset();
        const err = document.getElementById('pinError');
        err.textContent = message || 'Введите код доступа, показанный на ноутбуке';
        err.className = message ? 'pin-error show error' : 'pin-error show';
        modal.classList.add('active');
        setTimeout(() => document.getElementById('pinInput').focus(), 60);
    }

    applyRemote(data) {
        if (this._resetting) return;
        if (data.user) this.user = { ...data.user, id: this.user?.id || data.user.id || crypto.randomUUID() };
        this.goals = data.goals ?? this.goals;
        this.achievements = data.achievements ?? this.achievements;
        this.habits = Array.isArray(data.habits) ? data.habits : this.habits;
        this.events = data.events ?? this.events;
        this.notes = data.notes ?? this.notes;
        this.settings = { ...this.settings, ...(data.settings || {}) };
        this.settings.habitReminders = false;
        this.gamification = { ...this.gamification, ...(data.gamification || {}) };
        this.updatedAt = data.updatedAt || null;
        this._dirty = false;
        this.notes = this.normalizeNotes(this.notes);
        return this.persistData();
    }

    afterRemoteUpdate() {
        if (this.user && document.getElementById('authScreen').style.display !== 'none') {
            // Данные пришли с сервера на новом устройстве — сразу показываем приложение
            this.showApp();
            return;
        }
        this.updateGreeting();
        this.render();
    }

    // ===== Event Binding =====
    bindEvents() {
        this.initModalA11y();
        document.getElementById('openCloudProfileBtn').addEventListener('click', async () => {
            if (this._creatingProfile) return;
            if (!this.user) {
                this._creatingProfile = true;
                this.user = { id: crypto.randomUUID(), nickname: 'Профиль', createdAt: new Date().toISOString() };
                const saved = await this.saveData({ deferAutoSync: true });
                this._creatingProfile = false;
                if (!saved) { this.user = null; return; }
            }
            this.currentView = 'profile'; this.showApp(); this.switchView('profile');
            this.openSettingsModal(); window.CloudSync?.openAuth();
        });
        // Navigation (sidebar + bottom-nav)
        document.querySelectorAll('.nav-item[data-view], .bottom-nav-item[data-view]').forEach(item => {
            item.addEventListener('click', () => this.switchView(item.dataset.view));
        });

        document.querySelectorAll('.nav-item[data-action="settings"]').forEach(item => {
            item.addEventListener('click', () => this.openSettingsModal());
        });

        document.getElementById('toggleSidebar').addEventListener('click', () => {
            document.getElementById('sidebar').classList.toggle('collapsed');
        });

        // Goals
        document.getElementById('addGoalBtn').addEventListener('click', () => this.openGoalModal());
        document.getElementById('addGoalBtn2').addEventListener('click', () => this.openGoalModal());
        document.getElementById('goalForm').addEventListener('submit', (e) => this.saveGoal(e));
        document.getElementById('closeGoalModal').addEventListener('click', () => this.closeModal('goalModal'));
        document.getElementById('cancelGoalBtn').addEventListener('click', () => this.closeModal('goalModal'));
        document.getElementById('closeDetailModal').addEventListener('click', () => this.closeModal('goalDetailModal'));

        // Achievements
        document.getElementById('addAchievementBtn').addEventListener('click', () => this.openAchievementModal());
        document.getElementById('achievementForm').addEventListener('submit', (e) => this.saveAchievement(e));
        document.getElementById('closeAchievementModal').addEventListener('click', () => this.closeModal('achievementModal'));
        document.getElementById('cancelAchievementBtn').addEventListener('click', () => this.closeModal('achievementModal'));

        document.getElementById('allCalendarActivitiesBtn').addEventListener('click', () => this.openCalendarActivities());
        document.getElementById('closeCalendarActivitiesModal').addEventListener('click', () => this.closeModal('calendarActivitiesModal'));
        document.getElementById('addCalendarNoteBtn').addEventListener('click', () => this.openNoteModal(this.selectedDate));

        // Notes
        document.getElementById('noteForm').addEventListener('submit', (e) => this.saveNote(e));
        document.getElementById('closeNoteModal').addEventListener('click', () => this.closeModal('noteModal'));
        document.getElementById('cancelNoteBtn').addEventListener('click', () => this.closeModal('noteModal'));
        document.getElementById('deleteNoteBtn').addEventListener('click', () => this.deleteNote());

        // Settings
        document.getElementById('settingsBtn').addEventListener('click', () => this.openSettingsModal());
        document.getElementById('mobileSettingsBtn').addEventListener('click', () => this.openSettingsModal());
        document.getElementById('closeSettingsModal').addEventListener('click', () => this.closeModal('settingsModal'));
        document.getElementById('resetProfileBtn').addEventListener('click', () => this.resetProfile());

        // Код доступа
        document.getElementById('pinForm').addEventListener('submit', (e) => {
            e.preventDefault();
            const pin = document.getElementById('pinInput').value.replace(/\D/g, '');
            if (pin.length < 4) {
                document.getElementById('pinError').textContent = 'Код — минимум 4 цифры';
                document.getElementById('pinError').className = 'pin-error show error';
                return;
            }
            this.setPin(pin);
            this.closeModal('pinModal');
            this.showToast('Код сохранён — синхронизируемся...', 'success');
            setTimeout(() => this.syncData(false), 200);
        });
        document.getElementById('closePinModal').addEventListener('click', () => this.closeModal('pinModal'));
        document.getElementById('cancelPinBtn').addEventListener('click', () => this.closeModal('pinModal'));
        // Notification settings
        document.getElementById('notificationsEnabled').addEventListener('change', (e) => {
            this.settings.notifications = e.target.checked;
            this.saveData();
            const group = document.getElementById('notificationSettingsGroup');
            if (group) group.style.display = e.target.checked ? 'block' : 'none';
            if (e.target.checked) {
                this.requestNotificationPermission();
                this.rescheduleAllNotifications();
            } else {
                this.cancelAllNotifications();
            }
        });

        document.getElementById('deadlineWarningsEnabled').addEventListener('change', (e) => {
            this.settings.deadlineWarnings = e.target.checked;
            this.saveData();
            this.rescheduleAllNotifications();
        });

        document.getElementById('calendarRemindersEnabled').addEventListener('change', (e) => {
            this.settings.calendarReminders = e.target.checked;
            this.saveData();
            this.rescheduleAllNotifications();
        });

        document.getElementById('streakAlertsEnabled').addEventListener('change', (e) => {
            this.settings.streakAlerts = e.target.checked;
            this.saveData();
            this.rescheduleAllNotifications();
        });

        document.getElementById('notificationSoundEnabled').addEventListener('change', (e) => {
            this.settings.notificationSound = e.target.checked;
            this.saveData();
        });

        document.getElementById('notificationVibrationEnabled').addEventListener('change', (e) => {
            this.settings.notificationVibration = e.target.checked;
            this.saveData();
        });

        document.getElementById('testNotificationBtn').addEventListener('click', () => {
            this.sendTestNotification();
        });

        document.getElementById('reminderDays').addEventListener('change', (e) => {
            this.settings.reminderDays = parseInt(e.target.value);
            this.saveData();
            this.rescheduleAllNotifications();
        });

        // Theme
        document.getElementById('themeBtn').addEventListener('click', () => this.toggleTheme());
        document.getElementById('mobileThemeBtn').addEventListener('click', () => this.toggleTheme());
        document.querySelectorAll('.theme-btn').forEach(btn => {
            btn.addEventListener('click', () => this.setTheme(btn.dataset.theme));
        });

        // Filters
        document.getElementById('filterStatus').addEventListener('change', () => this.renderGoals());
        document.getElementById('sortBy').addEventListener('change', () => this.renderGoals());

        // Calendar
        document.getElementById('prevMonth').addEventListener('click', () => this.changeMonth(-1));
        document.getElementById('nextMonth').addEventListener('click', () => this.changeMonth(1));

        // Sync settings
        document.getElementById('syncNowBtn').addEventListener('click', () => this.syncData());
        document.getElementById('autoSyncEnabled').addEventListener('change', (e) => {
            this.settings.autoSync = e.target.checked;
            this.saveData();
            this.showToast(e.target.checked ? 'Автосинхронизация включена' : 'Автосинхронизация выключена', 'info');
        });
        document.getElementById('syncUrlInput').addEventListener('change', (e) => {
            this.settings.syncUrl = e.target.value.trim() || '';
            this.saveData();
            this.showToast(this.settings.syncUrl ? 'Сервер синхронизации задан' : 'Автономный режим включён', 'success');
            this.openSettingsModal(); // переоткрыть для обновления UI
        });

        // Export/Import
        document.getElementById('exportDataBtn').addEventListener('click', () => this.exportData());
        document.getElementById('exportCSVBtn').addEventListener('click', () => this.exportCSV());
        document.getElementById('exportPDFBtn').addEventListener('click', () => this.exportPDF());
        document.getElementById('importDataBtn').addEventListener('click', () => this.importData());
        document.getElementById('installPwaBtn').addEventListener('click', () => this.installPWA());

        // Modal overlays
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', () => this.closeModal(overlay.parentElement.id));
        });

        // New Gamification Modals
        document.getElementById('profileEditForm').addEventListener('submit', event => this.saveProfileDetails(event));
        document.getElementById('closeProfileEditModal').addEventListener('click', () => this.closeModal('profileEditModal'));
        document.getElementById('cancelProfileEditBtn').addEventListener('click', () => this.closeModal('profileEditModal'));
        
    }

    // ===== View Management =====
    switchView(viewName) {
        const availableViews = new Set(['dashboard', 'goals', 'achievements', 'calendar', 'profile', 'finance', 'social', 'health']);
        if (!availableViews.has(viewName)) viewName = 'profile';
        this.currentView = viewName;
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.toggle('active', item.dataset.view === viewName);
        });
        document.querySelectorAll('.bottom-nav-item').forEach(item => {
            item.classList.toggle('active', item.dataset.view === viewName);
        });
        document.querySelectorAll('.view').forEach(view => {
            view.classList.toggle('active', view.id === `view-${viewName}`);
        });
        this.setHealth3DActive(viewName === 'health');
        this.render();
        // Render finance view when switching to finance
        if (viewName === 'finance') {
            if (window.renderFinanceView) {
                window.renderFinanceView();
            } else if (typeof renderFinanceView === 'function') {
                renderFinanceView();
            }
        }
    }

    setHealth3DActive(active) {
        if (!active) {
            window.health3D?.setActive(false);
            return;
        }

        if (!this._health3DPromise) {
            const status = document.getElementById('bodyScanStatus');
            if (status) status.textContent = 'Статус: скан загружается...';
            this._health3DPromise = import('./health-3d.js').catch(error => {
                this._health3DPromise = null;
                console.error('[Health3D] Не удалось загрузить 3D-модуль:', error);
                const loader = document.getElementById('health3DLoader');
                if (loader) loader.hidden = true;
                if (status) status.textContent = 'Статус: 3D-скан недоступен';
                return null;
            });
        }

        this._health3DPromise.then(() => {
            if (this.currentView === 'health') window.health3D?.setActive(true);
        });
    }

    render() {
        switch (this.currentView) {
            case 'dashboard': this.renderDashboard(); break;
            case 'goals': this.renderGoals(); break;
            case 'achievements': this.renderAchievements(); break;
            case 'calendar': this.renderCalendar(); break;
            case 'profile': this.renderProfile(); break;
            case 'social': window.socialView?.render(); break;
            case 'health': window.healthView?.render(); break;
        }
        window.avatarVideo?.refresh();
    }

    // ===== Dashboard =====
    renderDashboard() {
        const total = this.goals.length;
        const active = this.goals.filter(g => g.status === 'active').length;
        const completed = this.goals.filter(g => g.status === 'completed').length;
        const overallProgress = total > 0
            ? Math.round(this.goals.reduce((s, g) => s + this.calculateProgress(g), 0) / total)
            : 0;

        document.getElementById('totalGoals').textContent = total;
        document.getElementById('activeGoals').textContent = active;
        document.getElementById('completedGoals').textContent = completed;
        document.getElementById('overallProgress').textContent = overallProgress + '%';

        const recent = [...this.achievements].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 5);
        document.getElementById('recentAchievements').innerHTML = recent.length
            ? recent.map(a => this.renderAchievementItem(a)).join('')
            : this.renderEmptyState('🏆', 'Пока нет достижений');

        const deadlines = this.goals.filter(g => g.deadline && g.status === 'active')
            .sort((a, b) => new Date(a.deadline) - new Date(b.deadline)).slice(0, 5);
        document.getElementById('upcomingDeadlines').innerHTML = deadlines.length
            ? deadlines.map(g => this.renderDeadlineItem(g)).join('')
            : this.renderEmptyState('📅', 'Нет активных дедлайнов');

        this.renderProductivityWidget();
        this.renderGoalHealthWidget();

    }

    // ===== Profile (includes Stats) =====
    renderProfile() {
        const container = document.getElementById('profileContent');
        if (!container) return;

        const total = this.goals.length;
        const active = this.goals.filter(g => g.status === 'active').length;
        const completed = this.goals.filter(g => g.status === 'completed').length;
        const totalAchievements = this.achievements.length;
        const overallProgress = total > 0
            ? Math.round(this.goals.reduce((s, g) => s + this.calculateProgress(g), 0) / total)
            : 0;

        const avatar = this.getCustomAvatar();
        const initials = (this.user?.nickname || 'Гость').trim().split(/\s+/).slice(0, 2).map(word => Array.from(word)[0] || '').join('').toLocaleUpperCase('ru-RU');
        container.innerHTML = `
            <div class="profile-header card">
                <div class="profile-avatar-control">
                    <button type="button" class="profile-avatar" id="chooseProfileAvatar" aria-label="Выбрать фото профиля" ${this._avatarLoading ? 'disabled aria-busy="true"' : ''}>
                        ${avatar ? `<img src="${avatar}" alt="Аватар профиля" width="96" height="96">` : `<span class="profile-initials">${this.escapeHtml(initials)}</span>`}
                        <span class="profile-avatar-camera" aria-hidden="true">📷</span>
                    </button>
                    <input type="file" id="profileAvatarFile" accept="image/*" hidden>
                </div>
                <div class="profile-info">
                    <h2>${this.escapeHtml(this.user?.nickname || 'Гость')}</h2>
                    <button type="button" class="btn btn-secondary" id="editProfileBtn">Редактировать профиль</button>
                </div>
            </div>

            <div class="dashboard-grid">
                <div class="card stat-card">
                    <div class="stat-value">${total}</div>
                    <div class="stat-label">Всего целей</div>
                </div>
                <div class="card stat-card">
                    <div class="stat-value">${active}</div>
                    <div class="stat-label">Активных</div>
                </div>
                <div class="card stat-card">
                    <div class="stat-value">${completed}</div>
                    <div class="stat-label">Завершённых</div>
                </div>
                <div class="card stat-card">
                    <div class="stat-value">${overallProgress}%</div>
                    <div class="stat-label">Общий прогресс</div>
                </div>
                <div class="card stat-card">
                    <div class="stat-value">${totalAchievements}</div>
                    <div class="stat-label">Достижений</div>
                </div>
            </div>

            <div class="stats-grid">
                <div class="card">
                    <h3>📊 Прогресс по категориям</h3>
                    <div id="categoryStats"></div>
                </div>
                <div class="card">
                    <h3>📈 Активность за неделю</h3>
                    <div id="weeklyActivity"></div>
                </div>
            </div>

            <div class="card">
                <h3>🏆 Последние достижения</h3>
                <div class="achievements-list">
                    ${[...this.achievements].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 5)
                        .map(a => this.renderAchievementItem(a)).join('') || this.renderEmptyState('🏆', 'Нет достижений')}
                </div>
            </div>
        `;

        document.getElementById('chooseProfileAvatar').addEventListener('click', () => document.getElementById('profileAvatarFile').click());
        document.getElementById('profileAvatarFile').addEventListener('change', event => {
            const file = event.target.files?.[0];
            if (file) this.uploadProfileAvatar(file);
        });
        document.getElementById('editProfileBtn').addEventListener('click', () => this.openProfileEditor());
        this.renderCategoryStats();
        this.renderWeeklyActivity();
        try { document.dispatchEvent(new CustomEvent('goaltracker:profile-rendered')); } catch (e) {}
        if (window.AuthSync) { try { window.AuthSync.bind(); } catch (e) {} }
    }

    profileAvatarKey() {
        return `customAvatarData:${this.user?.id || this.user?.createdAt || 'local'}`;
    }

    getCustomAvatar() {
        try {
            const data = localStorage.getItem(this.profileAvatarKey()) || '';
            return data.length <= 200000 && /^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(data) ? data : '';
        } catch { return ''; }
    }

    async resizeProfileAvatar(file) {
        if (!['image/jpeg','image/png','image/webp','image/gif','image/avif','image/bmp'].includes(file.type)) throw new Error('Выберите растровое изображение: JPG, PNG, WebP, GIF, AVIF или BMP.');
        if (!file.size || file.size > 25 * 1024 * 1024) throw new Error('Фото должно быть не больше 25 МБ.');
        const url = URL.createObjectURL(file);
        try {
            const image = await new Promise((resolve, reject) => {
                const img = new Image();
                img.onload = () => resolve(img);
                img.onerror = () => reject(new Error('Не удалось прочитать изображение. Выберите другое фото.'));
                img.src = url;
            });
            const width = image.naturalWidth, height = image.naturalHeight;
            if (!width || !height || width * height > 40000000) throw new Error('Изображение слишком большое: максимум 40 мегапикселей.');
            const crop = Math.min(width, height), size = Math.min(300, crop);
            const canvas = document.createElement('canvas'); canvas.width = size; canvas.height = size;
            const context = canvas.getContext('2d');
            if (!context) throw new Error('Обработка фото недоступна в этом браузере.');
            context.drawImage(image, (width-crop)/2, (height-crop)/2, crop, crop, 0, 0, size, size);
            const data = canvas.toDataURL('image/webp', .8);
            if (data.length > 200000 || !/^data:image\/(?:webp|png);base64,/.test(data)) throw new Error('Не удалось сжать фото. Выберите другое изображение.');
            return data;
        } finally { URL.revokeObjectURL(url); }
    }

    async uploadProfileAvatar(file) {
        if (this._avatarLoading || !this.user) return false;
        const key = this.profileAvatarKey();
        this._avatarLoading = true;
        this.renderProfile();
        try {
            const data = await this.resizeProfileAvatar(file);
            if (key !== this.profileAvatarKey() || !this.user) throw new Error('Профиль изменился. Выберите фото заново.');
            // Device-local image, deliberately excluded from profile serialization/sync.
            localStorage.setItem(key, data);
            try { window.CloudSync?.localChanged(); } catch {}
            this.showToast('Фото профиля сохранено на устройстве', 'success');
            return true;
        } catch (error) {
            this.showToast(error?.name === 'QuotaExceededError' ? 'Не хватает места для фото. Старый аватар сохранён.' : error.message || 'Не удалось сохранить фото. Повторите попытку.', 'error');
            return false;
        } finally {
            this._avatarLoading = false;
            if (this.currentView === 'profile') this.renderProfile();
        }
    }

    openProfileEditor() {
        if (!this.user || this._profileSaving) return;
        document.getElementById('profileNickname').value = this.user.nickname || '';
        document.getElementById('profileStatus').value = this.user.status || '';
        document.getElementById('profileEditError').hidden = true;
        document.getElementById('profileEditModal').classList.add('active');
        document.getElementById('profileNickname').focus();
    }

    async saveProfileDetails(event) {
        event.preventDefault();
        if (this._profileSaving || !this.user || !document.getElementById('profileEditModal').classList.contains('active')) return false;
        const error = document.getElementById('profileEditError'); error.hidden = true;
        const nickname = document.getElementById('profileNickname').value.trim(), status = document.getElementById('profileStatus').value.trim();
        if (nickname.length < 2 || nickname.length > 32 || status.length > 120) {
            error.textContent = 'Никнейм: от 2 до 32 символов. Статус: до 120 символов.'; error.hidden = false; return false;
        }
        const previous = this.user, dirty = this._dirty;
        const controls = [...document.querySelectorAll('#profileEditForm input, #profileEditForm textarea, #profileEditForm button, #closeProfileEditModal')];
        this._profileSaving = true; controls.forEach(control => { control.disabled = true; });
        document.getElementById('profileEditForm').setAttribute('aria-busy', 'true');
        this.user = { ...previous, nickname, status };
        try {
            if (await this.saveData({ deferAutoSync: true }) !== true) throw new Error('Profile not persisted');
        } catch {
            this.user = previous; this._dirty = dirty;
            error.textContent = 'Не удалось сохранить профиль. Изменения не применены. Повторите попытку.'; error.hidden = false; return false;
        } finally {
            this._profileSaving = false; controls.forEach(control => { control.disabled = false; });
            document.getElementById('profileEditForm').removeAttribute('aria-busy');
        }
        this.closeModal('profileEditModal'); this.updateGreeting(); this.renderProfile();
        this.showToast('Профиль обновлён', 'success');
        return true;
    }

    renderAchievementItem(a) {
        const goal = this.goals.find(g => g.id === a.goalId);
        return `
            <div class="achievement-item">
                <span class="achievement-icon">🏆</span>
                <div class="achievement-info">
                    <div class="achievement-title">${a.protected ? '🔒' : ''} ${this.escapeHtml(a.title)}</div>
                    <div class="achievement-goal">${goal ? this.escapeHtml(goal.title) : 'Общее'}</div>
                </div>
                <span class="achievement-date">${new Date(a.date).toLocaleDateString('ru-RU')}</span>
            </div>
        `;
    }

    renderDeadlineItem(goal) {
        const daysLeft = this.getDaysLeft(goal.deadline);
        let cls = 'normal';
        if (daysLeft < 0) cls = 'urgent';
        else if (daysLeft <= 3) cls = 'warning';
        return `
            <div class="deadline-item ${cls}">
                <div class="deadline-info">
                    <div class="deadline-title">${this.escapeHtml(goal.title)}</div>
                    <div class="deadline-date">${new Date(goal.deadline).toLocaleDateString('ru-RU')}</div>
                </div>
                <span class="deadline-days ${cls}">${daysLeft >= 0 ? daysLeft + ' дн.' : 'Просрочено'}</span>
            </div>
        `;
    }

    renderEmptyState(icon, text) {
        return `<div class="empty-state"><div class="empty-state-icon">${icon}</div><div class="empty-state-text">${text}</div></div>`;
    }

    // ===== Widgets =====

    renderProductivityWidget() {
        const el = document.getElementById('productivityWidget');
        if (!el) return;
        const today = new Date().toISOString().split('T')[0];
        const todayCount = this.achievements.filter(a => a.date === today).length;
        const weekAgo = new Date(); weekAgo.setDate(weekAgo.getDate() - 7);
        const weekCount = this.achievements.filter(a => new Date(a.date) >= weekAgo).length;
        el.innerHTML = `
            <div class="widget-header">
                <span class="widget-icon">📈</span>
                <div><div class="widget-title">Продуктивность</div><div class="widget-subtitle">за 7 дней</div></div>
            </div>
            <div class="widget-stats">
                <div class="widget-stat"><span class="widget-stat-value">${todayCount}</span><span class="widget-stat-label">сегодня</span></div>
                <div class="widget-stat"><span class="widget-stat-value">${weekCount}</span><span class="widget-stat-label">за неделю</span></div>
                <div class="widget-stat"><span class="widget-stat-value">${(weekCount/7).toFixed(1)}</span><span class="widget-stat-label">в среднем</span></div>
            </div>
        `;
    }

    renderGoalHealthWidget() {
        const el = document.getElementById('goalHealthWidget');
        if (!el) return;
        const active = this.goals.filter(g => g.status === 'active');
        const onTrack = active.filter(g => {
            if (!g.deadline) return true;
            return this.calculateProgress(g) >= 50 || this.getDaysLeft(g.deadline) > 7;
        }).length;
        el.innerHTML = `
            <div class="widget-header">
                <span class="widget-icon">💚</span>
                <div><div class="widget-title">Здоровье целей</div><div class="widget-subtitle">${active.length} активных</div></div>
            </div>
            <div class="health-indicators">
                <div class="health-item"><span class="health-dot good"></span><span>В графике: ${onTrack}</span></div>
                <div class="health-item"><span class="health-dot bad"></span><span>Под угрозой: ${active.length - onTrack}</span></div>
            </div>
        `;
    }

    // ===== Goals =====
    renderGoals() {
        const container = document.getElementById('goalsList');
        const filter = document.getElementById('filterStatus').value;
        const sort = document.getElementById('sortBy').value;

        let items = [...this.goals];
        if (filter !== 'all') items = items.filter(g => g.status === filter);
        items.sort((a, b) => {
            switch (sort) {
                case 'priority': {
                    const importance = this.getGoalPriorityWeight(b.priority) - this.getGoalPriorityWeight(a.priority);
                    return importance || (new Date(b.createdAt) - new Date(a.createdAt));
                }
                case 'deadline': return (a.deadline || '9999').localeCompare(b.deadline || '9999');
                case 'progress': return this.calculateProgress(b) - this.calculateProgress(a);
                case 'name': return a.title.localeCompare(b.title);
                default: return new Date(b.createdAt) - new Date(a.createdAt);
            }
        });

        if (!items.length) { container.innerHTML = this.renderEmptyState('🎯', 'Нет целей. Создайте первую!'); return; }
        container.innerHTML = items.map(g => this.renderGoalItem(g)).join('');
        container.querySelectorAll('.goal-item').forEach(item => {
            item.addEventListener('click', () => this.openGoalDetail(item.dataset.id));
        });
    }

    getGoalPriorityWeight(priority) {
        // Retain legacy critical goals; missing/unknown priorities behave as medium.
        switch (priority) {
            case 'critical': return 4;
            case 'high': return 3;
            case 'low': return 1;
            default: return 2;
        }
    }

    renderGoalItem(goal) {
        const progress = this.calculateProgress(goal);
        const steps = this.getSubgoalProgress(goal);
        const pClass = progress >= 100 ? 'complete' : progress >= 60 ? 'high' : progress >= 30 ? 'medium' : 'low';
        const daysLeft = goal.deadline ? this.getDaysLeft(goal.deadline) : null;
        const dClass = daysLeft !== null ? (daysLeft < 0 ? 'urgent' : daysLeft <= 3 ? 'warning' : '') : '';
        return `
            <div class="goal-item${['high', 'critical'].includes(goal.priority) ? ' goal-item-important' : ''}" data-id="${goal.id}">
                <div class="goal-item-header">
                    <span class="goal-item-title">${goal.status === 'completed' ? '✅' : '🎯'} ${this.escapeHtml(goal.title)}</span>
                    <span class="goal-item-category">${this.getCategoryLabel(goal.category)}</span>
                </div>
                ${goal.description ? `<div class="goal-item-description">${this.escapeHtml(goal.description)}</div>` : ''}
                <div class="goal-item-meta">
                    <span class="priority-badge ${this.getPriorityClass(goal.priority)}">${this.getPriorityLabel(goal.priority)}</span>
                    ${goal.deadline ? `<span class="goal-item-deadline ${dClass}">📅 ${new Date(goal.deadline).toLocaleDateString('ru-RU')}</span>` : ''}
                    <span class="goal-subgoal-summary"><span>📝 ${steps.total} подцелей${steps.total ? ` · ${steps.completed}/${steps.total}` : ''}</span>${steps.total ? `<span class="subgoal-mini-bar" role="progressbar" aria-label="Прогресс подцелей" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${steps.percent}"><span style="width:${steps.percent}%"></span></span>` : ''}</span>
                </div>
                <div class="progress-bar"><div class="progress-fill ${pClass}" style="width:${progress}%"></div></div>
                <div class="progress-text"><span>Прогресс</span><span>${progress}%</span></div>
            </div>
        `;
    }

    // ===== Achievements =====
    renderAchievements() {
        const container = document.getElementById('achievementsList');
        const sorted = [...this.achievements].sort((a, b) => new Date(b.date) - new Date(a.date));
        if (!sorted.length) { container.innerHTML = this.renderEmptyState('🏆', 'Пока нет достижений'); return; }

        container.innerHTML = sorted.map(a => {
            const goal = this.goals.find(g => g.id === a.goalId);
            return `
                <div class="achievement-item-full">
                    <span class="achievement-icon">🏆</span>
                    <div class="achievement-info">
                        <div class="achievement-title">${a.protected ? '🔒' : ''} ${this.escapeHtml(a.title)}</div>
                        <div class="achievement-goal">${goal ? this.escapeHtml(goal.title) : 'Общее'}</div>
                        <div class="achievement-date">${new Date(a.date).toLocaleDateString('ru-RU')}</div>
                    </div>
                    <div class="achievement-actions">
                        ${!a.protected ? `
                            <button class="btn-icon btn-edit-achievement" data-id="${a.id}">✏️</button>
                            <button class="btn-icon btn-delete-achievement" data-id="${a.id}">🗑️</button>
                        ` : '<span class="protected-label">🔒 Защищено</span>'}
                    </div>
                </div>
            `;
        }).join('');

        container.querySelectorAll('.btn-edit-achievement').forEach(b => b.addEventListener('click', () => this.openAchievementModal(b.dataset.id)));
        container.querySelectorAll('.btn-delete-achievement').forEach(b => b.addEventListener('click', () => this.deleteAchievement(b.dataset.id)));
    }

    // ===== Calendar =====
    calendarDateString(year, month, day) {
        return `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    }

    getCalendarActivities(dateStr) {
        const notes = this.getNotes(dateStr).map(note => ({ ...note, kind: 'note', title: note.content }));
        const events = this.events.filter(event => event.date === dateStr).map(event => ({ ...event, kind: 'event', title: event.title || event.content || event.name || 'Событие' }));
        const deadlines = this.goals.filter(goal => goal.deadline === dateStr).map(goal => ({ id: goal.id, kind: 'goal', title: goal.title, time: null }));
        return [...notes, ...events, ...deadlines].sort((a, b) => (a.time || '').localeCompare(b.time || ''));
    }

    renderCalendar() {
        const grid = document.getElementById('calendarGrid');
        const year = this.currentMonth.getFullYear(), month = this.currentMonth.getMonth();
        document.getElementById('currentMonth').textContent = new Date(year, month, 1).toLocaleDateString('ru-RU', { month: 'long', year: 'numeric' });
        const today = new Date();
        const prefix = this.calendarDateString(year, month, 1).slice(0, 7);
        if (!this.selectedDate?.startsWith(prefix + '-')) {
            this.selectedDate = this.calendarDateString(year, month, today.getFullYear() === year && today.getMonth() === month ? today.getDate() : 1);
        }
        const todayString = this.calendarDateString(today.getFullYear(), today.getMonth(), today.getDate());
        const startDay = (new Date(year, month, 1).getDay() + 6) % 7;
        const days = new Date(year, month + 1, 0).getDate();
        let html = ['Пн','Вт','Ср','Чт','Пт','Сб','Вс'].map(day => `<div class="calendar-day-header">${day}</div>`).join('');
        for (let cell = 0; cell < 42; cell++) {
            const day = cell - startDay + 1;
            if (day < 1 || day > days) {
                html += `<div class="calendar-day other-month" aria-hidden="true"><span class="calendar-day-number">${new Date(year, month, day).getDate()}</span></div>`;
                continue;
            }
            const ds = this.calendarDateString(year, month, day);
            const activities = this.getCalendarActivities(ds);
            const label = new Date(year, month, day).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' });
            html += `<button type="button" class="calendar-day ${ds === todayString ? 'today' : ''} ${ds === this.selectedDate ? 'selected' : ''} ${activities.length ? 'has-activity' : ''}" data-date="${ds}" aria-label="${label}${activities.length ? ', есть активности' : ''}" aria-pressed="${ds === this.selectedDate}" ${ds === todayString ? 'aria-current="date"' : ''}><span class="calendar-day-number">${day}</span>${activities.length ? `<span class="calendar-indicator calendar-activity-dot ${activities.some(item => item.kind === 'goal') ? 'goal-indicator' : activities.some(item => item.kind === 'event') ? 'event-indicator' : 'note-indicator'}" aria-hidden="true"></span>` : ''}</button>`;
        }
        grid.innerHTML = html;
        grid.querySelectorAll('button[data-date]').forEach(button => button.addEventListener('click', () => this.selectCalendarDate(button.dataset.date)));
        this.renderCalendarAgenda();
    }

    selectCalendarDate(dateStr) {
        this.selectedDate = dateStr;
        this.currentMonth = new Date(dateStr + 'T00:00:00');
        this.currentMonth.setDate(1);
        this.renderCalendar();
    }

    renderCalendarAgenda() {
        const container = document.getElementById('calendarDayEvents');
        document.getElementById('calendarSelectedDate').textContent = new Date(this.selectedDate + 'T00:00:00').toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', weekday: 'long' });
        const activities = this.getCalendarActivities(this.selectedDate);
        container.innerHTML = activities.length ? `<ul class="calendar-agenda-list">${activities.map((item, index) => `<li class="calendar-agenda-item"><time class="calendar-agenda-time">${item.time ? this.escapeHtml(item.time) : 'Без времени'}</time><div class="calendar-agenda-text"><span>${this.escapeHtml(item.title)}</span>${item.kind !== 'note' ? `<small>${item.kind === 'goal' ? 'Дедлайн цели' : 'Событие'}</small>` : ''}</div><div class="calendar-agenda-actions">${item.kind === 'note' ? `<button type="button" class="btn-icon" data-edit-calendar-note="${index}" aria-label="Редактировать запись">✏️</button><button type="button" class="btn-icon" data-delete-calendar-note="${index}" aria-label="Удалить запись">🗑️</button>` : item.kind === 'goal' ? `<button type="button" class="btn-icon" data-open-calendar-goal="${index}" aria-label="Открыть цель">↗</button>` : ''}</div></li>`).join('')}</ul>` : '<p class="calendar-agenda-empty">На этот день планов нет</p>';
        container.querySelectorAll('[data-edit-calendar-note]').forEach(button => button.addEventListener('click', () => this.openNoteModal(this.selectedDate, activities[Number(button.dataset.editCalendarNote)].id)));
        container.querySelectorAll('[data-delete-calendar-note]').forEach(button => button.addEventListener('click', () => this.deleteNote(this.selectedDate, activities[Number(button.dataset.deleteCalendarNote)].id)));
        container.querySelectorAll('[data-open-calendar-goal]').forEach(button => button.addEventListener('click', () => this.openGoalDetail(activities[Number(button.dataset.openCalendarGoal)].id)));
    }

    openCalendarActivities() {
        const year = this.currentMonth.getFullYear(), month = this.currentMonth.getMonth();
        const activities = [];
        for (let day = 1; day <= new Date(year, month + 1, 0).getDate(); day++) {
            const date = this.calendarDateString(year, month, day);
            this.getCalendarActivities(date).forEach(item => activities.push({ ...item, date }));
        }
        document.getElementById('calendarActivitiesTitle').textContent = `Все активности · ${new Date(year, month, 1).toLocaleDateString('ru-RU', { month: 'long', year: 'numeric' })}`;
        const container = document.getElementById('calendarMonthActivities');
        container.innerHTML = activities.length ? activities.map((item, index) => `<button type="button" class="calendar-month-activity" data-activity-index="${index}"><strong>${new Date(item.date + 'T00:00:00').toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' })}</strong><time>${this.escapeHtml(item.time || 'Без времени')}</time><span>${this.escapeHtml(item.title)}</span>${item.kind !== 'note' ? `<small>${item.kind === 'goal' ? 'Дедлайн цели' : 'Событие'}</small>` : ''}</button>`).join('') : '<p class="calendar-agenda-empty">В этом месяце активностей нет</p>';
        container.querySelectorAll('[data-activity-index]').forEach(button => button.addEventListener('click', () => {
            this.closeModal('calendarActivitiesModal');
            this.selectCalendarDate(activities[Number(button.dataset.activityIndex)].date);
            document.querySelector('#calendarGrid .selected')?.focus();
        }));
        document.getElementById('calendarActivitiesModal').classList.add('active');
        (container.querySelector('button') || document.getElementById('closeCalendarActivitiesModal')).focus();
    }

    changeMonth(delta) {
        this.currentMonth = new Date(this.currentMonth.getFullYear(), this.currentMonth.getMonth() + delta, 1);
        this.renderCalendar();
    }

    // ===== Notes =====
    // Нормализация: старый формат (одна заметка на день) → массив записей
    normalizeNotes(notes) {
        const out = {};
        for (const [ds, val] of Object.entries(notes || {})) {
            if (Array.isArray(val)) {
                const list = val.filter(n => n && typeof n.content === 'string' && n.content.trim())
                    .map(n => ({ id: n.id || this.generateId(), content: n.content.trim(), time: n.time || null, createdAt: n.createdAt || new Date().toISOString(), updatedAt: n.updatedAt || n.createdAt || new Date().toISOString() }));
                if (list.length) out[ds] = list;
            } else if (val && typeof val === 'object' && typeof val.content === 'string' && val.content.trim()) {
                out[ds] = [{
                    id: this.generateId(),
                    content: val.content.trim(),
                    time: val.time || null,
                    createdAt: val.updatedAt || new Date().toISOString(),
                    updatedAt: val.updatedAt || new Date().toISOString()
                }];
            } else if (typeof val === 'string' && val.trim()) {
                out[ds] = [{ id: this.generateId(), content: val.trim(), time: null, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }];
            }
        }
        return out;
    }

    // Записи дня: без времени сверху (в порядке добавления), встречи по времени ниже
    getNotes(dateStr) {
        const list = this.notes[dateStr];
        if (!Array.isArray(list) || !list.length) return [];
        const untimed = list.filter(n => !n.time);
        const timed = list.filter(n => n.time).sort((a, b) => a.time.localeCompare(b.time));
        return [...untimed, ...timed];
    }

    openNoteModal(dateStr, noteId = null) {
        this.selectedDate = dateStr;
        const form = document.getElementById('noteForm');
        const del = document.getElementById('deleteNoteBtn');
        const list = Array.isArray(this.notes[dateStr]) ? this.notes[dateStr] : [];
        const note = noteId ? list.find(n => n.id === noteId) : null;

        document.getElementById('noteDate').value = dateStr;
        document.getElementById('noteDateLabel').textContent =
            new Date(dateStr + 'T00:00:00').toLocaleDateString('ru-RU', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

        if (note) {
            document.getElementById('noteModalTitle').textContent = 'Редактировать запись';
            document.getElementById('noteId').value = note.id;
            document.getElementById('noteContent').value = note.content;
            document.getElementById('noteTime').value = note.time || '';
            del.style.display = 'inline-block';
        } else {
            document.getElementById('noteModalTitle').textContent = 'Новая запись';
            form.reset();
            document.getElementById('noteDate').value = dateStr;
            document.getElementById('noteId').value = '';
            del.style.display = 'none';
        }
        document.getElementById('noteModal').classList.add('active');
        setTimeout(() => document.getElementById('noteContent').focus(), 50);
    }

    saveNote(e) {
        e.preventDefault();
        const ds = document.getElementById('noteDate').value;
        const noteId = document.getElementById('noteId').value;
        const content = document.getElementById('noteContent').value.trim();
        const time = document.getElementById('noteTime').value || null;
        if (!content || !ds) return;

        if (!Array.isArray(this.notes[ds])) this.notes[ds] = [];
        const now = new Date().toISOString();

        let note;
        if (noteId) {
            note = this.notes[ds].find(n => n.id === noteId);
            if (note) { note.content = content; note.time = time; note.updatedAt = now; }
        } else {
            note = { id: this.generateId(), content, time, createdAt: now, updatedAt: now };
            this.notes[ds].push(note);
        }
        // чистим пустые дни
        this.notes[ds] = this.notes[ds].filter(n => n.content);
        if (!this.notes[ds].length) delete this.notes[ds];

        this.saveData(); this.closeModal('noteModal'); this.renderCalendar();
        this.showToast(noteId ? 'Запись обновлена!' : 'Запись добавлена!', 'success');
        
        // Перепланируем уведомление для этой заметки
        if (note) this.onNoteChanged(note, ds);
    }

    deleteNote(ds = document.getElementById('noteDate').value, noteId = document.getElementById('noteId').value) {
        if (!ds || !noteId || !Array.isArray(this.notes[ds])) return;
        if (!confirm('Удалить запись?')) return;
        this.onNoteDeleted(noteId);
        this.notes[ds] = this.notes[ds].filter(n => n.id !== noteId);
        if (!this.notes[ds].length) delete this.notes[ds];
        this.saveData(); this.closeModal('noteModal'); this.renderCalendar(); this.showToast('Удалено', 'success');
    }

    // Напоминание о встречах сегодня (при запуске)
    checkTodayNotes() {
        if (!this.settings.notifications) return;
        const ds = new Date().toISOString().split('T')[0];
        const nowHm = `${String(new Date().getHours()).padStart(2, '0')}:${String(new Date().getMinutes()).padStart(2, '0')}`;
        const upcoming = (Array.isArray(this.notes[ds]) ? this.notes[ds] : [])
            .filter(n => n.time && n.time >= nowHm)
            .sort((a, b) => a.time.localeCompare(b.time));
        if (!upcoming.length) return;
        const list = upcoming.slice(0, 3).map(n => `${n.time} — ${n.content}`).join('; ');
        const more = upcoming.length > 3 ? ` и ещё ${upcoming.length - 3}` : '';
        this.showNotification(`Сегодня ${upcoming.length} запис(и): ${list}${more}`);
    }

    // ===== Goal Modal =====
    openGoalModal(goalId = null, parentGoalId = null, subgoalId = null) {
        if (this._goalSaveInProgress || this._goalActionPending) return;
        const parentGoal = parentGoalId ? this.goals.find(goal => goal.id === parentGoalId) : null;
        if (parentGoalId && !parentGoal) return;
        const subgoal = subgoalId ? parentGoal?.subgoals?.find(item => item.id === subgoalId) : null;
        if (subgoalId && !subgoal) return;
        const goal = subgoal || (goalId ? this.goals.find(item => item.id === goalId) : null);
        if (goalId && !goal) return;

        const form = document.getElementById('goalForm');
        const priority = document.getElementById('goalPriority');
        priority.querySelectorAll('[data-legacy-priority]').forEach(option => option.remove());
        form.reset();
        form.dataset.parentGoal = parentGoal?.id || '';
        form.dataset.subgoalId = subgoal?.id || '';
        const error = document.getElementById('goalFormError');
        error.textContent = ''; error.hidden = true;
        const context = document.getElementById('goalParentContext');
        context.textContent = parentGoal ? `Для цели «${parentGoal.title}»` : '';
        context.hidden = !parentGoal;
        document.getElementById('goalId').value = subgoal ? '' : goal?.id || '';
        document.getElementById('goalModalTitle').textContent = subgoal ? 'Редактировать подцель' : goal ? 'Редактировать цель' : parentGoal ? 'Новая подцель' : 'Новая цель';

        if (goal) {
            document.getElementById('goalTitle').value = goal.title;
            document.getElementById('goalDescription').value = goal.description || '';
            // Existing critical goals remain editable without silently losing their priority.
            if (goal.priority === 'critical') {
                const legacy = document.createElement('option');
                legacy.value = 'critical';
                legacy.textContent = 'Критический (сохранённый)';
                legacy.dataset.legacyPriority = 'true';
                priority.appendChild(legacy);
            }
            priority.value = ['low', 'medium', 'high', 'critical'].includes(goal.priority) ? goal.priority : 'medium';
        }
        document.getElementById('goalModal').classList.add('active');
        document.getElementById('goalTitle').focus();
    }

    async saveGoal(e) {
        e.preventDefault();
        const modal = document.getElementById('goalModal');
        if (this._goalSaveInProgress || this._goalActionPending || !modal.classList.contains('active')) return false;
        const form = document.getElementById('goalForm');
        const errorElement = document.getElementById('goalFormError');
        const showError = message => {
            errorElement.textContent = message;
            errorElement.hidden = false;
        };
        errorElement.hidden = true;
        const id = document.getElementById('goalId').value;
        const existing = id ? this.goals.find(goal => goal.id === id) : null;
        const parentGoalId = form.dataset.parentGoal || null;
        const parentGoal = parentGoalId ? this.goals.find(goal => goal.id === parentGoalId) : null;
        const subgoalId = form.dataset.subgoalId || null;
        const existingSubgoal = subgoalId ? parentGoal?.subgoals?.find(item => item.id === subgoalId) : null;
        if ((id && !existing) || (parentGoalId && !parentGoal) || (subgoalId && !existingSubgoal)) {
            showError('Цель больше не найдена. Закройте форму и откройте её заново.');
            return false;
        }
        const title = document.getElementById('goalTitle').value.trim();
        if (!title) {
            showError('Введите название цели.');
            document.getElementById('goalTitle').focus();
            return false;
        }
        const selectedPriority = document.getElementById('goalPriority').value;
        const priority = ['low', 'medium', 'high'].includes(selectedPriority)
            ? selectedPriority
            : (existingSubgoal || existing)?.priority === 'critical' && selectedPriority === 'critical' ? 'critical' : 'medium';
        const editable = {
            title,
            description: document.getElementById('goalDescription').value.trim(),
            priority
        };
        const controls = [...form.querySelectorAll('input, textarea, select, button'), document.getElementById('closeGoalModal')];
        const disabledBefore = controls.map(control => control.disabled);
        const saveButton = form.querySelector('[type="submit"]');
        const saveLabel = saveButton.textContent;
        const previousGoals = this.goals;
        const previousDirty = this._dirty;
        let pendingGoals;
        let goal;
        this._goalSaveInProgress = true;
        controls.forEach(control => { control.disabled = true; });
        saveButton.textContent = 'Сохранение…';
        form.setAttribute('aria-busy', 'true');
        try {
            if (existing) {
                goal = { ...existing, ...editable };
                pendingGoals = this.goals.map(item => item === existing ? goal : item);
            } else if (existingSubgoal) {
                goal = { ...existingSubgoal, ...editable };
                const updatedParent = { ...parentGoal, subgoals: parentGoal.subgoals.map(item => item === existingSubgoal ? goal : item) };
                pendingGoals = this.goals.map(item => item === parentGoal ? updatedParent : item);
            } else {
                goal = {
                    ...editable,
                    id: this.generateId(),
                    category: parentGoal?.category || 'personal',
                    deadline: null,
                    parentId: parentGoalId,
                    tags: [],
                    status: 'active',
                    createdAt: new Date().toISOString(),
                    subgoals: []
                };
                if (parentGoal) {
                    // Keep the existing nested subgoal model; no duplicate root goal.
                    goal.completed = false;
                    const updatedParent = { ...parentGoal, subgoals: [...(parentGoal.subgoals || []), goal] };
                    pendingGoals = this.goals.map(item => item === parentGoal ? updatedParent : item);
                } else {
                    pendingGoals = [...this.goals, goal];
                }
            }
            this.goals = pendingGoals;
            const saved = await this.saveData({ deferAutoSync: true });
            if (saved !== true) throw new Error('Profile persistence did not succeed');
        } catch (error) {
            if (this.goals === pendingGoals) this.goals = previousGoals;
            this._dirty = previousDirty;
            showError('Не удалось сохранить цель. Данные не добавлены. Проверьте доступ к хранилищу и повторите попытку.');
            return false;
        } finally {
            this._goalSaveInProgress = false;
            controls.forEach((control, index) => { control.disabled = disabledBefore[index]; });
            saveButton.textContent = saveLabel;
            form.removeAttribute('aria-busy');
        }
        // Closing does not depend on optional bonuses, notifications or rendering.
        this.closeModal('goalModal');
        this.showToast(existingSubgoal ? 'Подцель сохранена!' : parentGoal ? 'Подцель добавлена!' : 'Цель сохранена!', 'success');
        try {
            this.render();
            if (parentGoal) this.openGoalDetail(parentGoalId);
        } catch (error) {
            console.warn('[goals] Saved, but view refresh failed:', error);
            this.showToast('Цель сохранена. Откройте раздел заново, чтобы обновить экран.', 'warning');
        }
        try {
            if (!existing && !parentGoal) this.onNewGoal();
        } catch (error) {
            console.warn('[goals] Optional reward failed after saving:', error);
        }
        try {
            this.scheduleAutoSync();
            if (!parentGoal) await this.onGoalChanged(goal);
        } catch (error) {
            console.warn('[goals] Saved; background notification or sync failed:', error);
        }
        return true;
    }

    // ===== Goal Detail =====
    openGoalDetail(goalId) {
        const goal = this.goals.find(g => g.id === goalId);
        if (!goal) return;
        const content = document.getElementById('goalDetailContent');
        document.getElementById('detailGoalTitle').textContent = goal.title;

        const progress = this.calculateProgress(goal);
        const subgoals = Array.isArray(goal.subgoals) ? goal.subgoals : [];
        const steps = this.getSubgoalProgress(goal);
        const achievements = this.achievements.filter(a => a.goalId === goalId);

        content.innerHTML = `
            <div class="detail-meta">
                <span class="detail-meta-item">📂 ${this.getCategoryLabel(goal.category)}</span>
                <span class="detail-meta-item"><span class="priority-badge ${this.getPriorityClass(goal.priority)}">${this.getPriorityLabel(goal.priority)}</span></span>
                ${goal.deadline ? `<span class="detail-meta-item">📅 ${new Date(goal.deadline).toLocaleDateString('ru-RU')}</span>` : ''}
                ${goal.tags?.length ? `<span class="detail-meta-item">🏷️ ${goal.tags.join(', ')}</span>` : ''}
            </div>
            ${goal.description ? `<div class="detail-section"><p>${this.escapeHtml(goal.description)}</p></div>` : ''}
            <div class="detail-section goal-progress-section">
                <h4>Прогресс цели</h4>
                <div class="progress-bar" role="progressbar" aria-label="Общий прогресс цели" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${progress}"><div class="progress-fill ${progress>=100?'complete':progress>=60?'high':progress>=30?'medium':'low'}" style="width:${progress}%"></div></div>
                <div class="progress-text"><span>${steps.total ? "По выполненным подцелям" : "Выполнено"}</span><strong data-goal-progress>${progress}%</strong></div>
            </div>
            <section class="detail-section subgoals-section" aria-labelledby="subgoalsHeading">
                <div class="subgoals-header">
                    <h4 id="subgoalsHeading">Подцели</h4>
                    ${steps.total ? `<span class="subgoals-count" aria-live="polite">${steps.completed} из ${steps.total} выполнено</span>` : ''}
                </div>
                ${subgoals.length ? `<div class="subgoals-list" role="list">
                    ${subgoals.map(step => `
                        <div class="subgoal-item ${step.completed ? 'is-complete' : ''}" role="listitem">
                            <div class="subgoal-body"><label class="subgoal-main">
                                <input type="checkbox" class="subgoal-checkbox" data-sid="${step.id}" ${step.completed ? 'checked' : ''}>
                                <span class="subgoal-title ${step.completed ? 'completed' : ''}">${this.escapeHtml(step.title)}</span>
                            </label>
                            <div class="subgoal-files">${(step.files || []).map((file, index) => `<span class="subgoal-file"><button type="button" class="attachment-open" data-sid="${step.id}" data-index="${index}">📄 ${this.escapeHtml(file.name)}</button><button type="button" class="attachment-delete" data-sid="${step.id}" data-index="${index}" aria-label="Удалить файл ${this.escapeHtml(file.name)}">×</button></span>`).join('')}</div></div>
                            <div class="subgoal-actions">
                                <button type="button" class="btn-icon attachment-add" data-sid="${step.id}" aria-label="Прикрепить файл" title="Прикрепить файл">📎</button>
                                <button type="button" class="btn-icon btn-edit-subgoal" data-sid="${step.id}" aria-label="Редактировать подцель" title="Редактировать подцель">✏️</button>
                                <button type="button" class="btn-icon btn-delete-subgoal" data-sid="${step.id}" aria-label="Удалить подцель" title="Удалить подцель">🗑️</button>
                            </div>
                        </div>
                    `).join('')}
                </div>` : `<div class="subgoals-empty"><p>Разбей цель на шаги — добавь первую подцель</p><button type="button" class="btn btn-secondary" data-add-subgoal>+ Подцель</button></div>`}
            </section>
            <div class="detail-section goal-achievements-section">
                <h4>Достижения (${achievements.length})</h4>
                <div class="achievements-list">
                    ${achievements.length ? achievements.map(a => `
                        <div class="achievement-item">
                            <span class="achievement-icon">🏆</span>
                            <div class="achievement-info">
                                <div class="achievement-title">${a.protected?'🔒':''} ${this.escapeHtml(a.title)}</div>
                                <div class="achievement-date">${new Date(a.date).toLocaleDateString('ru-RU')}</div>
                            </div>
                            <div class="achievement-actions">
                                ${!a.protected ? `<button class="btn-icon btn-edit-achievement" data-id="${a.id}">✏️</button><button class="btn-icon btn-delete-achievement" data-id="${a.id}">🗑️</button>` : ''}
                            </div>
                        </div>
                    `).join('') : '<p style="color:var(--text-secondary)">Нет достижений</p>'}
                </div>
            </div>
            <div class="modal-actions">
                <button class="btn btn-danger" id="deleteGoalBtn">🗑️ Удалить</button>
                <button class="btn btn-secondary" id="editGoalBtn">✏️ Редактировать</button>
                <button class="btn btn-primary" id="addSubgoalBtn">+ Подцель</button>
                <button class="btn btn-primary" id="completeGoalBtn">${goal.status==='completed'?'↩️ Вернуть':'✅ Завершить'}</button>
            </div>
        `;

        document.getElementById('editGoalBtn').addEventListener('click', () => { this.closeModal('goalDetailModal'); this.openGoalModal(goalId); });
        document.getElementById('addSubgoalBtn').addEventListener('click', () => this.addSubgoal(goalId));
        content.querySelectorAll('[data-add-subgoal]').forEach(button => button.addEventListener('click', () => this.addSubgoal(goalId)));
        document.getElementById('completeGoalBtn').addEventListener('click', () => this.toggleGoalStatus(goalId));
        document.getElementById('deleteGoalBtn').addEventListener('click', () => this.deleteGoal(goalId));

        content.querySelectorAll('.attachment-add').forEach(button => button.addEventListener('click', () => {
            const input = document.createElement('input');
            input.type = 'file';
            input.addEventListener('change', () => { if (input.files[0]) this.changeSubgoalAttachment(goalId, button.dataset.sid, input.files[0]); });
            input.click();
        }));
        content.querySelectorAll('.attachment-delete').forEach(button => button.addEventListener('click', () => this.changeSubgoalAttachment(goalId, button.dataset.sid, null, Number(button.dataset.index))));
        content.querySelectorAll('.attachment-open').forEach(button => button.addEventListener('click', () => {
            const file = this.goals.find(item => item.id === goalId)?.subgoals?.find(item => item.id === button.dataset.sid)?.files?.[Number(button.dataset.index)];
            if (file) this.openGoalAttachment(file);
        }));
        content.querySelectorAll('.subgoal-checkbox').forEach(cb => cb.addEventListener('change', (e) => this.toggleSubgoal(goalId, e.target.dataset.sid, e.target.checked)));
        content.querySelectorAll('.btn-edit-subgoal').forEach(b => b.addEventListener('click', (e) => { e.stopPropagation(); this.editSubgoal(goalId, b.dataset.sid); }));
        content.querySelectorAll('.btn-delete-subgoal').forEach(b => b.addEventListener('click', (e) => { e.stopPropagation(); this.deleteSubgoal(goalId, b.dataset.sid); }));
        content.querySelectorAll('.btn-edit-achievement').forEach(b => b.addEventListener('click', (e) => { e.stopPropagation(); this.editAchievement(b.dataset.id); }));
        content.querySelectorAll('.btn-delete-achievement').forEach(b => b.addEventListener('click', (e) => { e.stopPropagation(); this.deleteAchievement(b.dataset.id); }));

        document.getElementById('goalDetailModal').classList.add('active');
    }

    openGoalAttachment(file) {
        let url;
        try { url = new URL(file.url); if (url.protocol !== 'https:') return; } catch { return; }
        if (!/\.(png|jpe?g|gif|webp|avif|bmp|svg)$/i.test(file.name)) {
            window.open(url.href, '_blank', 'noopener,noreferrer');
            return;
        }
        const dialog = document.createElement('dialog');
        dialog.className = 'attachment-preview';
        const close = document.createElement('button');
        close.textContent = 'Закрыть'; close.className = 'btn btn-secondary';
        const image = document.createElement('img'); image.src = url.href; image.alt = file.name;
        dialog.append(close, image); document.body.append(dialog);
        close.onclick = () => dialog.close();
        dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
        dialog.addEventListener('close', () => dialog.remove());
        dialog.showModal(); close.focus();
    }

    async changeSubgoalAttachment(goalId, sid, file, index) {
        if (this._attachmentPending || this._goalActionPending || this._goalSaveInProgress) return false;
        const step = this.goals.find(goal => goal.id === goalId)?.subgoals?.find(item => item.id === sid);
        if (!step || (!file && !step.files?.[index])) return false;
        let context, uploadedPath, persisted = false;
        const buttons = [...document.querySelectorAll(`.attachment-add, .attachment-delete`)];
        const before = buttons.map(button => [button, button.disabled, button.textContent]);
        this._attachmentPending = true;
        buttons.forEach(button => { button.disabled = true; if (button.classList.contains('attachment-add') && button.dataset.sid === sid) { button.textContent = '⏳'; button.setAttribute('aria-busy', 'true'); } });
        try {
            context = window.CloudSync?.attachmentStorage();
            if (!context) throw new Error('Облачное хранилище недоступно.');
            const prefix = `${context.userId}/${goalId}/${sid}/`;
            let attachment;
            if (file) {
                // Unique basename avoids overwriting an existing attachment, including equal names.
                const safeName = file.name.normalize('NFKD').replace(/[^a-zA-Z0-9._-]/g, '_').slice(-140) || 'file';
                const path = `${prefix}${this.generateId()}-${safeName}`;
                const result = await context.storage.upload(path, file, { upsert: false });
                if (result.error) throw result.error;
                uploadedPath = path;
                attachment = { name: file.name, url: context.storage.getPublicUrl(path).data.publicUrl };
            } else {
                const url = new URL(step.files[index].url);
                const base = new URL(context.storage.getPublicUrl(prefix + 'check').data.publicUrl);
                const path = decodeURIComponent(url.pathname.split('/storage/v1/object/public/goal-attachments/')[1] || '');
                if (url.origin !== base.origin || !path.startsWith(prefix) || path.slice(prefix.length).includes('/')) throw new Error('Некорректный путь вложения.');
                const result = await context.storage.remove([path]);
                if (result.error) throw result.error;
            }
            context.assertOwner();
            const goal = this.goals.find(item => item.id === goalId);
            const current = goal?.subgoals?.find(item => item.id === sid);
            if (!current) throw new Error('Подцель больше не существует.');
            const files = file ? [...(current.files || []), attachment] : (current.files || []).filter(item => item.url !== step.files[index].url);
            const next = { ...goal, subgoals: goal.subgoals.map(item => item === current ? { ...item, files } : item) };
            if (!await this.persistGoalAction(this.goals.map(item => item === goal ? next : item))) throw new Error('Не удалось сохранить список файлов. Повторите операцию.');
            persisted = true;
        } catch (error) {
            if (uploadedPath && !persisted) {
                try { const result = await context.storage.remove([uploadedPath]); if (result.error) throw result.error; }
                catch { this.showToast('Не удалось убрать незавершённую загрузку из Storage.', 'error'); }
            }
            this.showToast(error.message || 'Не удалось изменить вложение.', 'error');
        } finally {
            this._attachmentPending = false;
            before.forEach(([button, disabled, text]) => { button.disabled = disabled; button.textContent = text; button.removeAttribute('aria-busy'); });
        }
        if (persisted) {
            if (document.getElementById('goalDetailModal').classList.contains('active')) this.openGoalDetail(goalId);
            this.render();
            const synced = await window.CloudSync.sync();
            this.showToast(synced ? 'Вложение сохранено в облаке.' : 'Изменение сохранено на устройстве. Синхронизацию с облаком нужно повторить.', synced ? 'success' : 'error');
        }
        return persisted;
    }

    addSubgoal(goalId) {
        if (this._goalSaveInProgress || this._goalActionPending || !this.goals.some(goal => goal.id === goalId)) return;
        this.closeModal('goalDetailModal');
        this.openGoalModal(null, goalId);
    }

    editSubgoal(goalId, sid) {
        if (this._goalSaveInProgress || this._goalActionPending) return;
        if (!this.goals.find(goal => goal.id === goalId)?.subgoals?.some(step => step.id === sid)) return;
        this.closeModal('goalDetailModal');
        this.openGoalModal(null, goalId, sid);
    }

    async persistGoalAction(nextGoals, nextAchievements = this.achievements) {
        if (this._goalActionPending || this._goalSaveInProgress) return false;
        const previousGoals = this.goals;
        const previousAchievements = this.achievements;
        const previousDirty = this._dirty;
        const content = document.getElementById('goalDetailContent');
        const controls = [...content.querySelectorAll('input, button'), document.getElementById('closeDetailModal')];
        const disabledBefore = controls.map(control => control.disabled);
        this._goalActionPending = true;
        controls.forEach(control => { control.disabled = true; });
        content.setAttribute('aria-busy', 'true');
        this.goals = nextGoals;
        this.achievements = nextAchievements;
        try {
            if (await this.saveData({ deferAutoSync: true }) !== true) throw new Error('Goal action not persisted');
        } catch (error) {
            if (this.goals === nextGoals) this.goals = previousGoals;
            if (this.achievements === nextAchievements) this.achievements = previousAchievements;
            this._dirty = previousDirty;
            this.showToast('Изменения не сохранены. Проверьте хранилище и повторите попытку.', 'error');
            return false;
        } finally {
            this._goalActionPending = false;
            controls.forEach((control, index) => { control.disabled = disabledBefore[index]; });
            content.removeAttribute('aria-busy');
        }
        try { this.scheduleAutoSync(); } catch (error) { console.warn('[goals] Sync deferred:', error); }
        return true;
    }

    async deleteSubgoal(goalId, sid) {
        if (this._goalActionPending || this._goalSaveInProgress) return false;
        const goal = this.goals.find(item => item.id === goalId);
        if (!goal?.subgoals?.some(step => step.id === sid) || !confirm('Удалить подцель?')) return false;
        const next = { ...goal, subgoals: goal.subgoals.filter(step => step.id !== sid) };
        const saved = await this.persistGoalAction(this.goals.map(item => item === goal ? next : item));
        this.openGoalDetail(goalId); this.render();
        return saved;
    }

    async toggleSubgoal(goalId, sid, completed) {
        if (this._goalActionPending || this._goalSaveInProgress) return false;
        const goal = this.goals.find(item => item.id === goalId);
        const subgoal = goal?.subgoals?.find(step => step.id === sid);
        if (!subgoal || Boolean(subgoal.completed) === Boolean(completed)) return false;
        const next = { ...goal, subgoals: goal.subgoals.map(step => step === subgoal ? { ...step, completed: Boolean(completed) } : step) };
        const saved = await this.persistGoalAction(this.goals.map(item => item === goal ? next : item));
        // Refresh the open modal as well as the underlying card/dashboard.
        this.openGoalDetail(goalId); this.render();
        if (saved && completed) {
            try { this.onSubgoalComplete(); } catch (error) { console.warn('[goals] Optional subgoal reward failed:', error); }
        }
        return saved;
    }

    async toggleGoalStatus(goalId) {
        if (this._goalActionPending || this._goalSaveInProgress) return false;
        const goal = this.goals.find(item => item.id === goalId);
        if (!goal) return false;
        const next = { ...goal, status: goal.status === 'completed' ? 'active' : 'completed' };
        const achievements = next.status === 'completed' ? [...this.achievements, {
            id: this.generateId(), goalId: goal.id,
            title: `Завершена цель: ${goal.title}`, description: goal.description || '',
            date: new Date().toISOString().split('T')[0], progress: 100,
            protected: true, autoCreated: true, createdAt: new Date().toISOString()
        }] : this.achievements;
        if (!await this.persistGoalAction(this.goals.map(item => item === goal ? next : item), achievements)) return false;
        this.closeModal('goalDetailModal'); this.render();
        if (next.status === 'completed') {
            try { this.onGoalComplete(next); this.onAchievementCreated(); } catch (error) { console.warn('[goals] Optional completion reward failed:', error); }
        }
        this.showToast(next.status === 'completed' ? 'Цель завершена! 🎉' : 'Цель возвращена', 'success');
        return true;
    }

    deleteGoal(goalId) {
        if (this._goalActionPending || this._goalSaveInProgress) return;
        if (!confirm('Удалить цель? Подцели и достижения тоже.')) return;
        this.onGoalDeleted(goalId);
        this.goals = this.goals.filter(g => g.id !== goalId);
        this.achievements = this.achievements.filter(a => a.goalId !== goalId);
        this.goals.forEach(g => { if (g.parentId === goalId) g.parentId = null; });
        this.saveData(); this.closeModal('goalDetailModal'); this.render(); this.showToast('Цель удалена', 'success');
    }

    // ===== Achievement Modal =====
    openAchievementModal(achievementId = null) {
        const goalSel = document.getElementById('achievementGoal');
        goalSel.innerHTML = this.goals.map(g => `<option value="${g.id}">${this.escapeHtml(g.title)}</option>`).join('');

        if (achievementId) {
            const a = this.achievements.find(x => x.id === achievementId);
            if (a) {
                document.getElementById('achievementId').value = a.id;
                document.getElementById('achievementGoal').value = a.goalId;
                document.getElementById('achievementTitle').value = a.title;
                document.getElementById('achievementDescription').value = a.description || '';
                document.getElementById('achievementDate').value = a.date;
                document.getElementById('achievementProgress').value = a.progress || 0;
                document.getElementById('achievementProtected').checked = a.protected || false;
            }
        } else {
            document.getElementById('achievementForm').reset();
            document.getElementById('achievementId').value = '';
            document.getElementById('achievementDate').value = new Date().toISOString().split('T')[0];
        }
        document.getElementById('achievementModal').classList.add('active');
    }

    saveAchievement(e) {
        e.preventDefault();
        const id = document.getElementById('achievementId').value;
        const data = {
            goalId: document.getElementById('achievementGoal').value,
            title: document.getElementById('achievementTitle').value.trim(),
            description: document.getElementById('achievementDescription').value.trim(),
            date: document.getElementById('achievementDate').value,
            progress: parseInt(document.getElementById('achievementProgress').value) || 0,
            protected: document.getElementById('achievementProtected').checked
        };
        if (id) { const i = this.achievements.findIndex(a => a.id === id); if (i !== -1) this.achievements[i] = { ...this.achievements[i], ...data }; }
        else {
            data.id = this.generateId(); data.createdAt = new Date().toISOString();
            this.achievements.push(data); this.onAchievementCreated();
        }
        this.saveData(); this.closeModal('achievementModal'); this.render(); this.showToast('Сохранено! 🏆', 'success');
    }

    editAchievement(id) { this.closeModal('goalDetailModal'); this.openAchievementModal(id); }

    deleteAchievement(id) {
        const a = this.achievements.find(x => x.id === id);
        if (!a) return;
        if (a.protected) { this.showToast('Защищённое достижение!', 'error'); return; }
        if (!confirm('Удалить достижение?')) return;
        this.achievements = this.achievements.filter(x => x.id !== id);
        this.saveData(); this.render(); this.showToast('Удалено', 'success');
    }

    // ===== Settings =====
    openSettingsModal() {
        document.getElementById('notificationsEnabled').checked = this.settings.notifications;
        document.getElementById('deadlineWarningsEnabled').checked = this.settings.deadlineWarnings;
        document.getElementById('calendarRemindersEnabled').checked = this.settings.calendarReminders;
        document.getElementById('streakAlertsEnabled').checked = this.settings.streakAlerts;
        document.getElementById('notificationSoundEnabled').checked = this.settings.notificationSound;
        document.getElementById('notificationVibrationEnabled').checked = this.settings.notificationVibration;
        document.getElementById('reminderDays').value = this.settings.reminderDays;
        document.getElementById('autoSyncEnabled').checked = !!this.settings.autoSync;
        
        const group = document.getElementById('notificationSettingsGroup');
        if (group) group.style.display = this.settings.notifications ? 'block' : 'none';
        
        const hasSyncUrl = !!this.settings.syncUrl;
        document.getElementById('syncUrlInput').value = this.settings.syncUrl || '';
        document.getElementById('syncUrlGroup').style.display = hasSyncUrl ? 'block' : 'none';
        document.getElementById('syncStatusText').textContent = this.updatedAt
            ? 'Последняя синхронизация: ' + new Date(this.updatedAt).toLocaleString('ru-RU')
            : (hasSyncUrl ? 'Пока только локально' : 'Автономный режим (без сервера)');
        
        document.querySelectorAll('.theme-btn').forEach(b => b.classList.toggle('active', b.dataset.theme === this.settings.theme));
        document.getElementById('settingsModal').classList.add('active');
    }

    // ===== Theme =====
    initTheme() {
        // Тёмная тема по умолчанию, если в localStorage ничего нет
        let saved = null;
        try { saved = localStorage.getItem('theme'); } catch {}
        const theme = saved || this.settings.theme || 'dark';
        this.setTheme(theme);
    }

    setTheme(theme) {
        this.settings.theme = theme;
        let effective = theme;
        if (theme === 'auto') {
            effective = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        }
        document.documentElement.setAttribute('data-theme', effective);
        try { localStorage.setItem('theme', theme); } catch {}
        const themeBtn = document.getElementById('themeBtn');
        if (themeBtn) themeBtn.textContent = effective === 'dark' ? '🌙' : '☀️';
        const mobileThemeBtn = document.getElementById('mobileThemeBtn');
        if (mobileThemeBtn) mobileThemeBtn.textContent = effective === 'dark' ? '🌙' : '☀️';
        document.querySelectorAll('.theme-btn').forEach(b => b.classList.toggle('active', b.dataset.theme === theme));
        this.saveData();
    }

    toggleTheme() {
        const cur = document.documentElement.getAttribute('data-theme') || this.settings.theme;
        this.setTheme(cur === 'dark' ? 'light' : 'dark');
    }

    // ===== Gamification Engine Delegation =====
    addXP(amount, source = '') {
        if (!this.gamificationEngine) return;
        const oldLevel = this.gamificationEngine.state.level;
        const result = this.gamificationEngine.addXp(amount, source);
        const newLevel = this.gamificationEngine.state.level;
        if (newLevel > oldLevel) {
            this.showLevelUpModal(oldLevel, newLevel);
        }
        return result;
    }



    updateStreak() {
        if (!this.gamificationEngine) return;
        this.gamificationEngine.updateStreak();
    }

    checkBadges() {
        if (!this.gamificationEngine) return;
        this.gamificationEngine.checkBadges();
    }

    hasBadge(id) {
        if (!this.gamificationEngine) return false;
        return this.gamificationEngine.hasBadge(id);
    }

    // Goal integration
    onGoalComplete(goal) {
        if (!this.gamificationEngine) return;
        this.gamificationEngine.onGoalComplete?.(goal);
    }

    onSubgoalComplete() {
        if (!this.gamificationEngine) return;
        this.gamificationEngine.onSubgoalComplete?.();
    }

    onNewGoal() {
        if (!this.gamificationEngine) return;
        this.gamificationEngine.onNewGoal?.();
    }

    onAchievementCreated() {
        if (!this.gamificationEngine) return;
        this.gamificationEngine.onAchievementCreated?.();
    }

    // ===== New Gamification UI =====
    // Level Up Modal
    showLevelUpModal() {
        // Legacy rewards remain in saved data, without RPG interface overlays.
    }

    getLevelUpMessage(level) {
        const messages = {
            2: 'Первые шаги пройдены! 🎯',
            3: 'Ты набираешь обороты! 🚀',
            5: 'Рядовой → Офицер! ⭐⭐',
            10: 'Десятый уровень — уважение! 🏆',
            15: 'Половина пути до 30! 💪',
            20: 'Командир отряда! ⭐⭐⭐',
            25: 'Четверть века уровней! 🌟',
            30: 'Тридцатилетие! 🎂',
            50: 'Генерал армии! 👑',
        };
        return messages[level] || 'Продолжай в том же духе! 💪';
    }

    // Confetti Animation
    triggerConfetti() {
        const canvas = document.getElementById('confetti-canvas');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        
        const particles = [];
        const colors = ['#6366f1', '#8b5cf6', '#22c55e', '#f59e0b', '#ef4444', '#ec4899', '#06b6d4'];
        const particleCount = 150;
        
        for (let i = 0; i < particleCount; i++) {
            particles.push({
                x: canvas.width / 2,
                y: canvas.height / 2,
                vx: (Math.random() - 0.5) * 20,
                vy: -Math.random() * 15 - 5,
                size: Math.random() * 8 + 4,
                color: colors[Math.floor(Math.random() * colors.length)],
                rotation: Math.random() * 360,
                rotationSpeed: (Math.random() - 0.5) * 10,
                gravity: 0.3,
                life: 1,
                decay: Math.random() * 0.01 + 0.005,
            });
        }
        
        let animationId;
        const animate = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            let alive = 0;
            
            for (const p of particles) {
                if (p.life <= 0) continue;
                alive++;
                
                p.x += p.vx;
                p.y += p.vy;
                p.vy += p.gravity;
                p.rotation += p.rotationSpeed;
                p.life -= p.decay;
                
                ctx.save();
                ctx.translate(p.x, p.y);
                ctx.rotate(p.rotation * Math.PI / 180);
                ctx.globalAlpha = p.life;
                ctx.fillStyle = p.color;
                ctx.fillRect(-p.size/2, -p.size/2, p.size, p.size);
                ctx.restore();
            }
            
            if (alive > 0) {
                animationId = requestAnimationFrame(animate);
            } else {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
            }
        };
        
        animate();
        
        // Cleanup after 5 seconds max
        setTimeout(() => {
            cancelAnimationFrame(animationId);
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        }, 5000);
    }

    // Sound Effects
    playSound(type) {
        if (!this.settings.notificationSound) return;
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = ctx.createOscillator();
            const gainNode = ctx.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(ctx.destination);
            
            switch (type) {
                case 'levelup':
                    oscillator.type = 'sine';
                    oscillator.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
                    oscillator.frequency.exponentialRampToValueAtTime(1046.50, ctx.currentTime + 0.3); // C6
                    oscillator.frequency.exponentialRampToValueAtTime(1567.98, ctx.currentTime + 0.5); // G6
                    gainNode.gain.setValueAtTime(0.3, ctx.currentTime);
                    gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.8);
                    oscillator.start(ctx.currentTime);
                    oscillator.stop(ctx.currentTime + 0.8);
                    break;
                case 'damage':
                    oscillator.type = 'sawtooth';
                    oscillator.frequency.setValueAtTime(200, ctx.currentTime);
                    oscillator.frequency.exponentialRampToValueAtTime(80, ctx.currentTime + 0.3);
                    gainNode.gain.setValueAtTime(0.2, ctx.currentTime);
                    gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.4);
                    oscillator.start(ctx.currentTime);
                    oscillator.stop(ctx.currentTime + 0.4);
                    break;
                case 'coin':
                    oscillator.type = 'sine';
                    oscillator.frequency.setValueAtTime(880, ctx.currentTime); // A5
                    oscillator.frequency.exponentialRampToValueAtTime(1320, ctx.currentTime + 0.1); // E6
                    gainNode.gain.setValueAtTime(0.15, ctx.currentTime);
                    gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
                    oscillator.start(ctx.currentTime);
                    oscillator.stop(ctx.currentTime + 0.2);
                    break;
            }
        } catch (e) {
            // Audio not supported or blocked
        }
    }

    // ===== Stats (in Profile) =====
    renderCategoryStats() {
        const container = document.getElementById('categoryStats');
        if (!container) return;
        const cats = {};
        this.goals.forEach(g => {
            if (!cats[g.category]) cats[g.category] = { total: 0, completed: 0, progress: 0 };
            cats[g.category].total++;
            if (g.status === 'completed') cats[g.category].completed++;
            cats[g.category].progress += this.calculateProgress(g);
        });
        const colors = ['#6366f1','#22c55e','#f59e0b','#ef4444','#3b82f6','#8b5cf6','#ec4899'];
        let html = ''; let i = 0;
        for (const [cat, data] of Object.entries(cats)) {
            const avg = data.total > 0 ? Math.round(data.progress / data.total) : 0;
            html += `
                <div class="category-stat">
                    <div class="category-stat-header"><span>${this.getCategoryLabel(cat)}</span><span>${data.completed}/${data.total} • ${avg}%</span></div>
                    <div class="category-stat-bar"><div class="category-stat-fill" style="width:${avg}%;background:${colors[i%colors.length]}"></div></div>
                </div>`;
            i++;
        }
        container.innerHTML = html || '<p style="color:var(--text-secondary)">Нет данных</p>';
    }

    renderWeeklyActivity() {
        const container = document.getElementById('weeklyActivity');
        if (!container) return;
        const days = ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'];
        const today = new Date();
        const week = [];
        for (let i = 6; i >= 0; i--) {
            const d = new Date(today); d.setDate(d.getDate() - i);
            const ds = d.toISOString().split('T')[0];
            week.push({ day: days[d.getDay()], count: this.achievements.filter(a => a.date === ds).length });
        }
        const max = Math.max(...week.map(w => w.count), 1);
        container.innerHTML = week.map(w => `
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;">
                <span style="width:30px;font-size:0.85rem;color:var(--text-secondary)">${w.day}</span>
                <div style="flex:1;height:20px;background:var(--border);border-radius:4px;overflow:hidden;">
                    <div style="width:${(w.count/max)*100}%;height:100%;background:var(--primary);border-radius:4px;transition:width .3s;"></div>
                </div>
                <span style="width:20px;text-align:right;font-size:0.85rem">${w.count}</span>
            </div>
        `).join('');
    }

    // ===== Sync =====
    async syncData(silent = false) {
        if (window.CloudSync?.configured()) return window.CloudSync.sync();
        if (this._resetting) return false;
        const epoch = this._dataEpoch;
        const base = this.getSyncBase();
        
        // Автономный режим — синхронизация не настроена
        if (!base) {
            if (!silent) this.showToast('📴 Автономный режим: синхронизация отключена', 'info');
            return false;
        }

        if (!silent) this.showToast('Синхронизация...', 'info');

        try {
            // 1. Получаем данные сервера
            let remote = null;
            let r = null;
            try {
                r = await this.apiFetch(base, { cache: 'no-store' });
            } catch { r = null; }
            if (this._resetting || epoch !== this._dataEpoch) return false;
            if (r && r.status === 401) {
                this.showPinModal('Неверный код доступа — введите заново');
                return false;
            }
            if (r && r.ok) remote = await r.json();
            if (this._resetting || epoch !== this._dataEpoch) return false;

            // Нет профиля — можно только забрать данные (автовход на новом устройстве)
            if (!this.user) {
                if (remote && remote.updatedAt) {
                    this.applyRemote(remote);
                    this.afterRemoteUpdate();
                    if (!silent) this.showToast('📥 Профиль получен с сервера', 'success');
                } else if (!silent) {
                    this.showToast('ℹ️ Нет профиля для отправки', 'info');
                }
                return this.user;
            }

            const neverSynced = !this.updatedAt;
            const remoteNewer = !!(remote && remote.updatedAt && this.updatedAt && remote.updatedAt > this.updatedAt);

            // Сервер новее, а локально ничего не меняли — чистое обновление
            if (remoteNewer && !this._dirty) {
                this.applyRemote(remote);
                this.afterRemoteUpdate();
                if (!silent) this.showToast('📥 Данные обновлены с сервера', 'success');
                return true;
            }

            // Локальных изменений нет и сервер актуален — отправлять нечего
            if (!this._dirty && remote && remote.updatedAt && !neverSynced) {
                if (!silent) this.showToast('🔄 Данные уже актуальны', 'success');
                return true;
            }

            // 2. Отправляем локальные данные (merge при первом подключении или одновременных правках)
            let payload = this.serialize();
            payload.updatedAt = new Date().toISOString();
            payload.baseUpdatedAt = (remote && remote.updatedAt) || this.updatedAt || null;
            if (remote && remote.updatedAt && (neverSynced || (remoteNewer && this._dirty))) {
                payload = this.mergeData(remote, payload);
            }

            const doPush = () => this.apiFetch(base, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const resp = await doPush();
            if (this._resetting || epoch !== this._dataEpoch) return false;

            if (resp.status === 401) {
                this.showPinModal('Неверный код доступа — введите заново');
                return false;
            }
            if (resp.status === 409) {
                // Конфликт: сервер ушёл вперёд, пока мы правили — объединяем и повторяем
                const conflict = await resp.json();
                if (this._resetting || epoch !== this._dataEpoch) return false;
                if (conflict.server) {
                    if (this._dirty) {
                        payload = this.mergeData(conflict.server, payload);
                        payload.updatedAt = new Date().toISOString();
                        payload.baseUpdatedAt = conflict.server.updatedAt;
                        const retry = await doPush();
                        if (this._resetting || epoch !== this._dataEpoch) return false;
                        if (!retry.ok) throw new Error('HTTP ' + retry.status);
                    } else {
                        this.applyRemote(conflict.server);
                        this.afterRemoteUpdate();
                        if (!silent) this.showToast('📥 Данные обновлены с сервера', 'success');
                        return true;
                    }
                }
            } else if (!resp.ok) {
                throw new Error('HTTP ' + resp.status);
            }

            this.updatedAt = payload.updatedAt;
            this._dirty = false;
            delete payload.baseUpdatedAt;
            // Синхронизируем память с отправленным (важно после merge — иначе
            // следующий push затёрл бы чужие данные нашей старой копией)
            this.applyRemote(payload);
            this.render();
            if (!silent) this.showToast('📤 Данные синхронизированы', 'success');
            return true;
        } catch (e) {
            console.warn('Sync failed:', e);
            if (!silent) this.showToast('⚠️ Ошибка синхронизации — данные остаются локально', 'error');
            return false;
        }
    }

    // Объединение данных нового устройства с серверными (первое подключение)
    mergeData(remote, local) {
        const byId = arr => new Map(arr.map(x => [x.id, x]));
        const union = (a, b) => {
            const map = byId(a);
            b.forEach(x => { if (!map.has(x.id)) map.set(x.id, x); });
            return [...map.values()];
        };
        const merged = { ...local };
        merged.user = local.user || remote.user;
        merged.goals = union(remote.goals || [], local.goals || []);
        merged.achievements = union(remote.achievements || [], local.achievements || []);
        merged.habits = union(remote.habits || [], local.habits || []);
        merged.events = union(remote.events || [], local.events || []);
        // Записи календаря: по дням, объединение по id
        const rn = this.normalizeNotes(remote.notes || {});
        const ln = this.normalizeNotes(local.notes || {});
        merged.notes = {};
        for (const day of new Set([...Object.keys(rn), ...Object.keys(ln)])) {
            if (rn[day] && ln[day]) {
                const map = new Map(rn[day].map(n => [n.id, n]));
                ln[day].forEach(n => map.set(n.id, n));
                merged.notes[day] = [...map.values()];
            } else {
                merged.notes[day] = ln[day] || rn[day];
            }
        }
        // Геймификация — берём лучшие показатели
        const rg = remote.gamification || {};
        const lg = local.gamification || {};
        merged.gamification = {
            ...lg,
            xp: Math.max(lg.xp || 0, rg.xp || 0),
            level: Math.max(lg.level || 1, rg.level || 1),
            streak: Math.max(lg.streak || 0, rg.streak || 0),
            badges: union(rg.badges || [], lg.badges || [])
        };
        return merged;
    }

    // ===== Export/Import =====
    exportData() {
        const data = { user: this.user, goals: this.goals, achievements: this.achievements, habits: this.habits, events: this.events, notes: this.notes, settings: this.settings, gamification: this.gamification, exportDate: new Date().toISOString() };
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a'); a.href = url; a.download = `goaltracker-${new Date().toISOString().split('T')[0]}.json`; a.click();
        URL.revokeObjectURL(url);
        this.showToast('Экспортировано!', 'success');
    }

    exportCSV() {
        const headers = ['Цель','Категория','Приоритет','Статус','Прогресс','Дедлайн'];
        const rows = this.goals.map(g => [g.title, this.getCategoryLabel(g.category), this.getPriorityLabel(g.priority), g.status === 'completed' ? 'Готово' : 'Активна', this.calculateProgress(g)+'%', g.deadline || '']);
        const csv = [headers, ...rows].map(r => r.map(c => `"${c}"`).join(',')).join('\n');
        const blob = new Blob(['\ufeff'+csv], { type: 'text/csv;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a'); a.href = url; a.download = `goaltracker.csv`; a.click();
        URL.revokeObjectURL(url);
        this.showToast('CSV экспортирован!', 'success');
    }

    exportPDF() {
        const w = window.open('', '_blank');
        w.document.write(`<html><head><title>GoalTracker</title><style>body{font-family:Arial;padding:20px}h1{color:#6366f1}table{width:100%;border-collapse:collapse;margin-top:10px}th,td{border:1px solid #ddd;padding:8px;text-align:left}th{background:#6366f1;color:#fff}</style></head><body><h1>GoalTracker Pro — Отчёт</h1><p>${new Date().toLocaleDateString('ru-RU')}</p><h2>Цели (${this.goals.length})</h2><table><tr><th>Цель</th><th>Категория</th><th>Статус</th><th>Прогресс</th></tr>${this.goals.map(g => `<tr><td>${this.escapeHtml(g.title)}</td><td>${this.getCategoryLabel(g.category)}</td><td>${g.status==='completed'?'Готово':'Активна'}</td><td>${this.calculateProgress(g)}%</td></tr>`).join('')}</table></body></html>`);
        w.document.close(); w.print();
        this.showToast('PDF готов!', 'success');
    }

    importData() {
        const input = document.createElement('input'); input.type = 'file'; input.accept = '.json';
        input.onchange = (e) => {
            const file = e.target.files[0]; if (!file) return;
            const reader = new FileReader();
            reader.onload = (ev) => {
                try {
                    const data = JSON.parse(ev.target.result);
                    if (data.user) this.user = { ...data.user, id: this.user?.id || data.user.id || crypto.randomUUID() };
                    if (data.goals) this.goals = data.goals;
                    if (data.achievements) this.achievements = data.achievements;
                    if (data.habits) this.habits = data.habits;
                    if (data.events) this.events = data.events;
                    if (data.notes) this.notes = this.normalizeNotes(data.notes);
                    if (data.settings) this.settings = { ...this.settings, ...data.settings };
                    this.settings.habitReminders = false;
                    if (data.gamification) this.gamification = { ...this.gamification, ...data.gamification };
                    this.saveData(); this.render(); this.showToast('Импортировано!', 'success');
                } catch (err) { this.showToast('Ошибка файла', 'error'); }
            };
            reader.readAsText(file);
        };
        input.click();
    }

    // ===== Notifications =====
    checkDeadlines() {
        if (!this.settings.notifications) return;
        const now = new Date();
        const remind = new Date(); remind.setDate(remind.getDate() + this.settings.reminderDays);
        this.goals.forEach(g => {
            if (g.deadline && g.status === 'active') {
                const dl = new Date(g.deadline);
                if (dl <= remind && dl >= now) this.showNotification(`Дедлайн: "${g.title}" приближается!`);
            }
        });
    }

    showNotification(message) {
        if (window.electronAPI?.showNotification) {
            window.electronAPI.showNotification('GoalTracker Pro', message);
        } else if ('Notification' in window && Notification.permission === 'granted') {
            new Notification('GoalTracker Pro', { body: message });
        }
        this.showToast(message, 'info');
    }

    // ===== Notification Manager Integration =====
    async requestNotificationPermission() {
        if (this.notificationManager) {
            const granted = await this.notificationManager.requestPermissions();
            if (!granted) {
                this.showToast('Разрешение на уведомления не получено', 'warning');
                this.settings.notifications = false;
                this.saveData();
                document.getElementById('notificationsEnabled').checked = false;
                document.getElementById('notificationSettingsGroup').style.display = 'none';
            }
            return granted;
        }
        // Fallback для веб (не Capacitor)
        if ('Notification' in window) {
            const perm = await Notification.requestPermission();
            return perm === 'granted';
        }
        return false;
    }

    async rescheduleAllNotifications() {
        if (!this.notificationManager) return;
        if (!this.settings.notifications) return;
        
        const hasPerm = await this.notificationManager.checkPermissions();
        if (!hasPerm) {
            const granted = await this.requestNotificationPermission();
            if (!granted) return;
        }

        try {
            await this.notificationManager.rescheduleAll();
            this.showToast('Уведомления перепланированы', 'success');
        } catch (e) {
            console.error('[App] Ошибка перепланировки уведомлений:', e);
        }
    }

    async cancelAllNotifications() {
        if (this.notificationManager) {
            await this.notificationManager.cancelAll();
        }
    }

    async sendTestNotification() {
        if (this.notificationManager) {
            const ok = await this.notificationManager.sendTestNotification();
            this.showToast(ok ? 'Тестовое уведомление отправлено! Проверьте шторку' : 'Ошибка отправки', ok ? 'success' : 'error');
        } else {
            // Fallback для веб
            this.showNotification('🧪 Тестовое уведомление от GoalTracker Pro');
            this.showToast('Тестовое уведомление отправлено (веб-версия)', 'success');
        }
    }

    // Вызывается при изменении цели
    async onGoalChanged(goal) {
        if (this.notificationManager && this.settings.deadlineWarnings) {
            await this.notificationManager.scheduleGoalDeadline(goal);
        }
    }

    // Вызывается при удалении цели
    async onGoalDeleted(goalId) {
        if (this.notificationManager) {
            await this.notificationManager.cancelGoalDeadline(goalId);
        }
    }

    // Вызывается при изменении заметки календаря
    async onNoteChanged(note, dateStr) {
        if (this.notificationManager && this.settings.calendarReminders && note.time) {
            await this.notificationManager.scheduleCalendarEvent({ 
                id: note.id, 
                title: note.content, 
                date: dateStr, 
                time: note.time,
                location: note.location
            });
        }
    }

    // Вызывается при удалении заметки
    async onNoteDeleted(noteId) {
        if (this.notificationManager) {
            await this.notificationManager.cancelCalendarEvent(noteId);
        }
    }

    // ===== Utilities =====
    generateId() { return Date.now().toString(36) + Math.random().toString(36).substr(2); }

    getSubgoalProgress(goal) {
        const subgoals = Array.isArray(goal.subgoals) ? goal.subgoals : [];
        const total = subgoals.length;
        const completed = subgoals.filter(item => item?.completed).length;
        return { total, completed, percent: total ? Math.round(completed / total * 100) : 0 };
    }

    calculateProgress(goal) {
        const steps = this.getSubgoalProgress(goal);
        if (steps.total) return steps.percent;
        return goal.status === 'completed' ? 100 : 0;
    }

    getDaysLeft(deadline) {
        const now = new Date(); now.setHours(0,0,0,0);
        const dl = new Date(deadline); dl.setHours(0,0,0,0);
        return Math.ceil((dl - now) / 86400000);
    }

    getCategoryLabel(c) { return { personal:'Личное',career:'Карьера',health:'Здоровье',finance:'Финансы',education:'Образование',hobby:'Хобби',other:'Другое' }[c] || c; }
    getPriorityLabel(p) { return { low:'Низкий',medium:'Средний',high:'Высокий',critical:'Критический' }[p] || p; }
    getPriorityClass(p) { return { low:'priority-low',medium:'priority-medium',high:'priority-high',critical:'priority-critical' }[p] || 'priority-medium'; }

    escapeHtml(t) { if (!t) return ''; const d = document.createElement('div'); d.textContent = t; return d.innerHTML; }
    closeModal(id) {
        if (id === 'cloudAuthModal' && window.CloudSync) { window.CloudSync.closeAuth(); return; }
        if (id === 'profileEditModal' && this._profileSaving) return;
        if ((id === 'goalModal' && this._goalSaveInProgress) || (id === 'goalDetailModal' && this._goalActionPending)) return;
        document.getElementById(id)?.classList.remove('active');
    }

    // Доступность модалок на тач-устройствах и с клавиатурой:
    // Escape закрывает верхнюю активную модалку, Tab/фокус не покидают открытое окно.
    initModalA11y() {
        document.addEventListener('keydown', (e) => {
            const active = [...document.querySelectorAll('.modal.active')].pop();
            if (!active) return;
            if (e.key === 'Escape') {
                e.preventDefault();
                this.closeModal(active.id);
                return;
            }
            if (e.key !== 'Tab') return;
            const focusable = [...active.querySelectorAll('a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])')]
                .filter((el) => el.offsetParent !== null);
            if (!focusable.length) return;
            const first = focusable[0];
            const last = focusable[focusable.length - 1];
            if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
            else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
            else if (!active.contains(document.activeElement)) { e.preventDefault(); first.focus(); }
        });
        document.addEventListener('focusin', (e) => {
            const active = [...document.querySelectorAll('.modal.active')].pop();
            if (!active || active === e.target || active.contains(e.target)) return;
            const first = active.querySelector('button, input, select, textarea, [tabindex]:not([tabindex="-1"])');
            first?.focus();
        });
    }

    showToast(message, type = 'info') {
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;
        container.appendChild(toast);
        setTimeout(() => toast.remove(), 3000);
    }

    // ===== PWA Install =====
    showInstallButton() {
        // Кнопка установки появится в профиле или в настройках
        const existing = document.getElementById('installPwaBtn');
        if (existing) existing.style.display = 'inline-block';
    }

    hideInstallButton() {
        const existing = document.getElementById('installPwaBtn');
        if (existing) existing.style.display = 'none';
    }

    async installPWA() {
        if (!this.deferredPrompt) {
            this.showToast('Установка недоступна (уже установлено или браузер не поддерживает)', 'info');
            return;
        }
        this.deferredPrompt.prompt();
        const { outcome } = await this.deferredPrompt.userChoice;
        if (outcome === 'accepted') {
            this.showToast('Установка запущена...', 'success');
        }
        this.deferredPrompt = null;
        this.hideInstallButton();
    }

    // ===== OTA Updates (Live Updates) =====
    // Сравнение версий semver: 1 если a>b, -1 если a<b, 0 если равны
    compareVersions(a, b) {
        const pa = String(a || '0').split('.').map(x => parseInt(x, 10) || 0);
        const pb = String(b || '0').split('.').map(x => parseInt(x, 10) || 0);
        for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
            const x = pa[i] || 0, y = pb[i] || 0;
            if (x > y) return 1;
            if (x < y) return -1;
        }
        return 0;
    }

    // Жёсткая проверка обновлений при старте: работает ВЕЗДЕ (APK + браузер),
    // без зависимости от нативного плагина. Вызывается из DOMContentLoaded и showApp.
    async checkForWebUpdate() {
        if (this._updateCheckDone) return;
        this._updateCheckDone = true;
        try {
            const res = await fetch(UPDATE_BASE_URL + '/version.json?t=' + Date.now(), { cache: 'no-store' });
            if (!res.ok) return;
            const info = await res.json();
            if (!info || !info.version) return;
            if (this.compareVersions(info.version, APP_VERSION) > 0) {
                console.log('[OTA] Доступно обновление:', APP_VERSION, '->', info.version);
                this.pendingUpdate = info;
                // Android: тихо скачиваем веб-бандл и сразу применяем его.
                if (window.Capacitor?.isNativePlatform?.()) {
                    this.backgroundDownloadUpdate(info);
                } else {
                    this.showUpdateBanner(info);
                }
            } else {
                console.log('[OTA] Версия актуальна:', APP_VERSION);
                this.hideUpdateBanner();
            }
        } catch (err) {
            // Офлайн или сервер недоступен — тихо, приложение работает локально
            console.log('[OTA] Проверка версии пропущена (офлайн?):', err?.message);
        }
    }

    // Фоновая загрузка бандла через нативный плагин Capgo (без dynamic import —
    // через глобальный объект Capacitor, который всегда есть в WebView)
    async backgroundDownloadUpdate(info) {
        if (this._updateDownloadPromise) return this._updateDownloadPromise;
        this._updateDownloadPromise = this.installNativeUpdate(info);
        try {
            return await this._updateDownloadPromise;
        } finally {
            this._updateDownloadPromise = null;
        }
    }

    async installNativeUpdate(info) {
        try {
            const Updater = window.Capacitor?.Plugins?.CapacitorUpdater;
            if (!Updater || !info?.updateUrl) return false;
            this.showToast('Доступно обновление. Устанавливаем...', 'info');
            const downloadOptions = {
                url: info.updateUrl,
                version: info.version
            };
            if (info.checksum) downloadOptions.checksum = info.checksum;
            const bundle = await Updater.download(downloadOptions);
            if (bundle?.id) {
                console.log('[OTA] Бандл загружен, перезапускаем приложение:', bundle.id);
                await window.ProfileStorage?.flush?.();
                // set() активирует бандл и самостоятельно перезагружает WebView.
                await Updater.set({ id: bundle.id });
                return true;
            }
        } catch (err) {
            console.log('[OTA] Фоновая загрузка не удалась:', err?.message);
            this.showToast('Не удалось установить обновление. Повторим при следующем запуске.', 'error');
        }
        return false;
    }

    // Кнопка [Применить] на баннере: нативный путь → плагин, иначе → открыть URL
    async applyWebUpdate() {
        const info = this.pendingUpdate;
        if (!info) return;
        if (window.Capacitor?.isNativePlatform?.()) {
            const ok = await this.backgroundDownloadUpdate(info);
            if (ok) {
                this.hideUpdateBanner();
                return;
            }
            // Плагин недоступен — предлагаем перезапуск (вдруг бандл уже подтянут)
            this.showToast('⚠️ Не удалось скачать внутри приложения. Установите новый APK.', 'error');
        }
        const url = info.updateUrl || (UPDATE_BASE_URL + '/updates/latest.zip');
        try { window.open(url, '_blank'); } catch (e) {}
    }

    showUpdateBanner(info) {
        try {
            const dismissed = localStorage.getItem('goaltracker_update_dismissed');
            if (dismissed === info.version) return; // пользователь нажал «Позже» для этой версии
        } catch (e) {}
        let banner = document.getElementById('updateBanner');
        if (!banner) {
            banner = document.createElement('div');
            banner.id = 'updateBanner';
            banner.className = 'update-banner';
            document.body.prepend(banner);
        }
        banner.innerHTML =
            '<span class="update-banner-text">🚀 Доступно обновление <b>v' + this.escapeHtml(info.version) + '</b>' +
            (info.changelog ? ' — ' + this.escapeHtml(info.changelog) : '') + '</span>' +
            '<span class="update-banner-actions">' +
            '<button class="btn btn-primary btn-small" id="applyUpdateBtn">Применить</button>' +
            '<button class="btn btn-secondary btn-small" id="dismissUpdateBtn">Позже</button>' +
            '</span>';
        banner.style.display = 'flex';
        document.getElementById('applyUpdateBtn').onclick = () => this.applyWebUpdate();
        document.getElementById('dismissUpdateBtn').onclick = () => {
            try { localStorage.setItem('goaltracker_update_dismissed', info.version); } catch (e) {}
            this.hideUpdateBanner();
        };
    }

    hideUpdateBanner() {
        const banner = document.getElementById('updateBanner');
        if (banner) banner.style.display = 'none';
    }

    async checkForUpdates() {
        // Новый путь: проверка через version.json (работает везде)
        await this.checkForWebUpdate();
    }

    showRestartButton() {
        // Добавляем кнопку перезапуска в настройки или на дашборд
        const existing = document.getElementById('restartAppBtn');
        if (existing) {
            existing.style.display = 'inline-block';
            return;
        }
        
        // Создаем кнопку динамически
        const btn = document.createElement('button');
        btn.id = 'restartAppBtn';
        btn.className = 'btn btn-warning';
        btn.textContent = '🔄 Перезапустить для обновления';
        btn.style.marginTop = '8px';
        btn.onclick = () => this.restartApp();
        
        // Добавляем в настройки или на дашборд
        const container = document.getElementById('profileContent') || document.getElementById('view-dashboard');
        if (container) {
            container.insertBefore(btn, container.firstChild);
        }
    }

    async restartApp() {
        await window.ProfileStorage.flush();
        if (window.Capacitor?.isNativePlatform?.()) {
            try {
                const CapApp = window.Capacitor?.Plugins?.App;
                if (CapApp?.exitApp) { await CapApp.exitApp(); return; }
            } catch (e) {}
        }
        location.reload();
    }
}

// ===== Initialize =====
document.addEventListener('DOMContentLoaded', async () => {
    // Первое действие после готовности DOM: подтверждаем запуск OTA-бандла.
    // Вызов намеренно не await'ится и происходит до профиля, сети и синхронизации.
    if (nativeUpdater?.notifyAppReady) {
        try {
            nativeUpdater.notifyAppReady().catch(error => {
                console.warn('[OTA] Не удалось подтвердить запуск бандла:', error?.message || error);
            });
        } catch (error) {
            console.warn('[OTA] Плагин подтверждения запуска недоступен:', error?.message || error);
        }
    }

    // защита от двойной инициализации (window.app может быть DOM-элементом id="app")
    if (window.app instanceof GoalTracker) return;
    try {
        await window.ProfileStorage.open();
    } catch (firstError) {
        console.warn('[profile] startup read failed, retrying in 300ms:', firstError?.message || 'unknown');
        await new Promise(resolve => setTimeout(resolve, 300));
        try {
            await window.ProfileStorage.open();
        } catch (secondError) {
            // Последняя линия защиты: ошибка профиля больше не блокирует весь UI.
            console.warn('[profile] retry failed; opening local fallback:', secondError?.message || 'unknown');
            try { await window.ProfileStorage.openFallback?.(secondError); }
            catch (fallbackError) { console.warn('[profile] empty-session fallback:', fallbackError?.message || 'unknown'); }
        }
    }
    window.app = new GoalTracker();
    console.log('GoalTracker started successfully!');
    // OTA не участвует в запуске: проверяем только в фоне через 5 секунд.
    setTimeout(() => {
        try { window.app?.checkForWebUpdate(); } catch (e) {}
    }, 5000);
    if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
    }
});
