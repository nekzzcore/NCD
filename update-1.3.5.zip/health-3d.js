// Three.js 3D Health Avatar — бирюзовая голограмма (Fresnel + сканлайны + свечение краёв)
// ES-модуль. three + аддоны берутся из локального вендора (vendor/three) через import map
// в index.html — одна версия three (0.186) для core и addons, работает офлайн, без CDN.
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

(function() {
    'use strict';

    // Ждём загрузки DOM
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initHealth3D);
    } else {
        initHealth3D();
    }

    function initHealth3D() {
        const container = document.getElementById('health3DCanvasContainer');
        if (!container) return;

        // Точка входа сцены (импорты уже разрешены import map'ом)
        createScene();

        async function createScene() {
            // ===== КОНСТАНТЫ =====
            const HOLO_COLOR = new THREE.Color('#22d3ee');   // кибер-циан
            const HOLO_COLOR2 = new THREE.Color('#18d8d8');  // бирюзовый акцент
            const FLOOR_Y = -1.3;                            // уровень пола
            const TARGET_HEIGHT = 2.6;                       // целевая высота модели

            // ===== CANVAS =====
            const canvas = document.createElement('canvas');
            canvas.id = 'health3DCanvas';
            canvas.style.width = '100%';
            canvas.style.height = '100%';
            canvas.style.display = 'block';
            container.appendChild(canvas);

            // ===== RENDERER =====
            const renderer = new THREE.WebGLRenderer({
                canvas,
                antialias: true,
                alpha: true
            });
            renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
            renderer.setClearColor(0x05060f, 1); // почти чёрный — чтобы голограмма «светилась»
            renderer.outputColorSpace = THREE.SRGBColorSpace;

            function currentSize() {
                const w = container.clientWidth || 640;
                const h = container.clientHeight || 500;
                return { w, h };
            }
            let { w: W, h: H } = currentSize();
            renderer.setSize(W, H, false);

            // ===== SCENE =====
            const scene = new THREE.Scene();

            // ===== CAMERA =====
            const camera = new THREE.PerspectiveCamera(50, W / H, 0.1, 1000);
            // Крупный план «от пояса до лица»: ближе к модели (z 5.2 → 1.9) и чуть ниже
            // (y 0.6 → 0.55), чтобы камера смотрела ВВЕРХ на лицо, а не вниз на макушку.
            camera.position.set(0, 0.55, 1.9);

            // ===== СВЕТ (нужен для тёмного пола — сама голограмма unlit) =====
            scene.add(new THREE.AmbientLight(0x223a55, 0.6));
            const keyLight = new THREE.DirectionalLight(0x33e0ff, 0.8);
            keyLight.position.set(2, 4, 3);
            scene.add(keyLight);
            const underGlow = new THREE.PointLight(0x22d3ee, 2.0, 8);
            underGlow.position.set(0, FLOOR_Y + 0.2, 0);
            scene.add(underGlow);

            // ===== ГОЛОГРАФИЧЕСКИЙ SHADER =====
            const holoUniforms = {
                uTime: { value: 0 },
                uColor: { value: HOLO_COLOR.clone() },
                uColor2: { value: HOLO_COLOR2.clone() },
                uOpacity: { value: 0.65 },
                uFresnelPower: { value: 2.4 },
                uScanDensity: { value: 220.0 },
                uScanSpeed: { value: 6.0 },
                uSweepSpeed: { value: 0.18 },
                uMinY: { value: FLOOR_Y },
                uMaxY: { value: FLOOR_Y + TARGET_HEIGHT }
            };

            const holoVertex = `
                varying vec3 vWorldPos;
                varying vec3 vViewDir;
                varying vec3 vNormal;
                void main() {
                    vec4 worldPos = modelMatrix * vec4(position, 1.0);
                    vWorldPos = worldPos.xyz;
                    vNormal = normalize(mat3(modelMatrix) * normal);
                    vViewDir = normalize(cameraPosition - worldPos.xyz);
                    gl_Position = projectionMatrix * viewMatrix * worldPos;
                }
            `;

            const holoFragment = `
                uniform float uTime;
                uniform vec3  uColor;
                uniform vec3  uColor2;
                uniform float uOpacity;
                uniform float uFresnelPower;
                uniform float uScanDensity;
                uniform float uScanSpeed;
                uniform float uSweepSpeed;
                uniform float uMinY;
                uniform float uMaxY;

                varying vec3 vWorldPos;
                varying vec3 vViewDir;
                varying vec3 vNormal;

                void main() {
                    vec3 N = normalize(vNormal);
                    vec3 V = normalize(vViewDir);

                    // --- Fresnel / Rim: края ярко светятся, центр прозрачный ---
                    float fres = pow(1.0 - abs(dot(N, V)), uFresnelPower);

                    // --- Статические горизонтальные сканлайны (как на рентгене) ---
                    float scan = sin(vWorldPos.y * uScanDensity - uTime * uScanSpeed) * 0.5 + 0.5;
                    scan = pow(scan, 2.0);

                    // --- Бегущая свип-полоса снизу вверх по телу ---
                    float yn = clamp((vWorldPos.y - uMinY) / (uMaxY - uMinY), 0.0, 1.0);
                    float sweepPos = fract(uTime * uSweepSpeed);
                    float sweep = 1.0 - smoothstep(0.0, 0.035, abs(yn - sweepPos));
                    // лёгкое свечение перед полосой
                    sweep += (1.0 - smoothstep(0.0, 0.12, abs(yn - sweepPos))) * 0.25;

                    // --- Итоговая яркость ---
                    float base = 0.12;                    // прозрачное «тело» в центре
                    float glow = fres * 1.4 + scan * 0.25 + sweep * 1.6;
                    float brightness = base + glow;

                    // Цвет: тело — голубой, края/свип — ближе к бирюзовому
                    vec3 col = mix(uColor2, uColor, clamp(fres + sweep, 0.0, 1.0)) * brightness;

                    float alpha = clamp(uOpacity * (base + fres + scan * 0.3 + sweep), 0.0, 1.0);
                    if (alpha < 0.01) discard;

                    gl_FragColor = vec4(col, alpha);
                }
            `;

            const holoMaterial = new THREE.ShaderMaterial({
                uniforms: holoUniforms,
                vertexShader: holoVertex,
                fragmentShader: holoFragment,
                transparent: true,
                depthWrite: false,
                side: THREE.DoubleSide,
                blending: THREE.AdditiveBlending
            });

            // Тонкая wireframe-окантовка (опционально) — полупрозрачная сетка поверх тела
            const wireMaterial = new THREE.MeshBasicMaterial({
                color: HOLO_COLOR,
                wireframe: true,
                transparent: true,
                opacity: 0.12,
                depthWrite: false,
                blending: THREE.AdditiveBlending
            });

            function applyHologram(model) {
                // ВАЖНО: собираем меши ОТДЕЛЬНО от добавления оверлеев.
                // Если добавлять wireframe-ребёнка прямо внутри traverse(), он сам является
                // isMesh и будет снова обойдён → бесконечная рекурсия
                // (RangeError: Maximum call stack size exceeded).
                const meshes = [];
                model.traverse((child) => {
                    if (child.isMesh) meshes.push(child);
                });

                for (const child of meshes) {
                    child.material = holoMaterial;
                    child.castShadow = false;
                    child.receiveShadow = false;
                    child.frustumCulled = false;
                    child.renderOrder = 2;

                    // Дублирующая wireframe-сетка (поверх тела)
                    const wire = new THREE.Mesh(child.geometry, wireMaterial);
                    wire.renderOrder = 3;
                    wire.frustumCulled = false;
                    child.add(wire);
                }
            }

            // ===== ТЁМНЫЙ ПОЛ + КРУГОВАЯ НЕОНОВАЯ ПЛАТФОРМА =====
            const floorGeo = new THREE.CircleGeometry(9, 64);
            const floorMat = new THREE.MeshStandardMaterial({
                color: 0x05060f,
                roughness: 0.9,
                metalness: 0.1
            });
            const floor = new THREE.Mesh(floorGeo, floorMat);
            floor.rotation.x = -Math.PI / 2;
            floor.position.y = FLOOR_Y;
            scene.add(floor);

            // Светящийся бирюзовый диск-платформа (радиальный градиент + пульсация)
            const platformUniforms = {
                uTime: { value: 0 },
                uColor: { value: HOLO_COLOR.clone() }
            };
            const platformMat = new THREE.ShaderMaterial({
                uniforms: platformUniforms,
                transparent: true,
                depthWrite: false,
                side: THREE.DoubleSide,
                blending: THREE.AdditiveBlending,
                vertexShader: `
                    varying vec2 vUv;
                    void main() {
                        vUv = uv;
                        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
                    }
                `,
                fragmentShader: `
                    uniform float uTime;
                    uniform vec3 uColor;
                    varying vec2 vUv;
                    void main() {
                        float d = length(vUv - 0.5) * 2.0;   // 0 в центре, 1 у края
                        float glow = smoothstep(1.0, 0.0, d) * 0.5;
                        // расходящиеся кольца
                        float rings = sin(d * 28.0 - uTime * 2.4) * 0.5 + 0.5;
                        rings *= smoothstep(1.0, 0.2, d) * 0.35;
                        float a = glow + rings;
                        if (a < 0.01) discard;
                        gl_FragColor = vec4(uColor * (glow + rings) * 1.6, a);
                    }
                `
            });
            const platform = new THREE.Mesh(new THREE.CircleGeometry(1.7, 64), platformMat);
            platform.rotation.x = -Math.PI / 2;
            platform.position.y = FLOOR_Y + 0.01;
            scene.add(platform);

            // Яркая неоновая окантовка платформы
            const ringMat = new THREE.MeshBasicMaterial({
                color: HOLO_COLOR,
                transparent: true,
                opacity: 0.9,
                side: THREE.DoubleSide,
                blending: THREE.AdditiveBlending,
                depthWrite: false
            });
            const ring = new THREE.Mesh(new THREE.TorusGeometry(1.7, 0.02, 12, 96), ringMat);
            ring.rotation.x = -Math.PI / 2;
            ring.position.y = FLOOR_Y + 0.02;
            scene.add(ring);

            const innerRing = new THREE.Mesh(new THREE.TorusGeometry(1.15, 0.012, 12, 96), ringMat);
            innerRing.rotation.x = -Math.PI / 2;
            innerRing.position.y = FLOOR_Y + 0.02;
            scene.add(innerRing);

            // ===== ORBITCONTROLS (вращение пальцем/курсором + автовращение 360°) =====
            const controls = new OrbitControls(camera, renderer.domElement);
            // Мобильный UX: вертикальный жест пальцем прокручивает страницу,
            // горизонтальное перетаскивание вращает сцену, щипок — приблизить/отдалить.
            renderer.domElement.style.touchAction = 'pan-y';
            controls.touches.ONE = THREE.TOUCH.ROTATE;
            controls.touches.TWO = THREE.TOUCH.DOLLY_ROTATE;
            controls.enableDamping = true;
            controls.dampingFactor = 0.06;
            controls.autoRotate = true;
            controls.autoRotateSpeed = 1.1;   // ~360° за минуту
            controls.enablePan = false;
            // Зум: не даём залететь сквозь модель и не отдаляться до «муравья»
            controls.minDistance = 1.2;
            controls.maxDistance = 6;
            // Запрет верхнего ракурса «на макушку» — не даём смотреть сильно сверху вниз
            controls.minPolarAngle = Math.PI / 3;       // 60° от вертикали
            controls.maxPolarAngle = Math.PI / 1.7;     // ~106° — лёгкий взгляд снизу разрешён
            // Точка прицела поднята на уровень груди/лица: +27% высоты модели от центра
            controls.target.set(0, FLOOR_Y + TARGET_HEIGHT * 0.77, 0);
            camera.lookAt(controls.target);

            controls.addEventListener('start', () => { controls.autoRotate = false; });
            let resumeTimer = null;
            controls.addEventListener('end', () => {
                clearTimeout(resumeTimer);
                resumeTimer = setTimeout(() => { controls.autoRotate = true; }, 1800);
            });

            // ===== ЗАГРУЗКА МОДЕЛИ (GLB) ИЛИ ЗАГЛУШКА =====
            const loader = new GLTFLoader();
            const characterGroup = new THREE.Group();
            scene.add(characterGroup);
            let mixer = null;

            loader.load(
                './assets/avatar/character.glb',
                (gltf) => {
                    const model = gltf.scene;

                    // Масштабируем и ставим модель на платформу
                    const preBox = new THREE.Box3().setFromObject(model);
                    const preSize = preBox.getSize(new THREE.Vector3());
                    const scale = preSize.y > 0.0001 ? TARGET_HEIGHT / preSize.y : 1;
                    model.scale.setScalar(scale);

                    const box = new THREE.Box3().setFromObject(model);
                    const center = box.getCenter(new THREE.Vector3());
                    model.position.x -= center.x;
                    model.position.z -= center.z;
                    model.position.y += FLOOR_Y - box.min.y;

                    applyHologram(model);
                    characterGroup.add(model);

                    // Обновляем границы для свип-полосы
                    const finBox = new THREE.Box3().setFromObject(model);
                    holoUniforms.uMinY.value = finBox.min.y;
                    holoUniforms.uMaxY.value = finBox.max.y;

                    // Проигрываем анимацию (idle), если есть
                    if (gltf.animations && gltf.animations.length > 0) {
                        mixer = new THREE.AnimationMixer(model);
                        mixer.clipAction(gltf.animations[0]).play();
                    }

                    updateStatus('3D-модель загружена ✓');
                    finishLoading();
                },
                (xhr) => {
                    if (xhr.total) {
                        const pct = Math.round((xhr.loaded / xhr.total) * 100);
                        updateStatus('Загрузка скана… ' + pct + '%');
                    } else {
                        updateStatus('Загрузка скана…');
                    }
                },
                (error) => {
                    // Диагностика: почему не загрузился GLB (сеть уже отдала 200)
                    console.error('[GLTFLoader] Ошибка загрузки character.glb:', error && (error.stack || error.message || String(error)));
                    console.log('GLB не найден, создаю процедурный голограмм-манекен...');
                    createHoloMannequin(THREE, characterGroup);
                    // Границы манекена известны заранее
                    holoUniforms.uMinY.value = FLOOR_Y;
                    holoUniforms.uMaxY.value = FLOOR_Y + TARGET_HEIGHT;
                    updateStatus('Процедурный манекен создан ✓');
                    finishLoading();
                }
            );

            // ===== ЗАПАСНОЙ МАНЕКЕН (если GLB недоступен) =====
            function createHoloMannequin(THREE, group) {
                const addPart = (geo, x, y, z) => {
                    const m = new THREE.Mesh(geo, holoMaterial);
                    m.position.set(x, y, z);
                    m.frustumCulled = false;
                    group.add(m);
                    const wire = new THREE.Mesh(geo, wireMaterial);
                    wire.position.copy(m.position);
                    wire.frustumCulled = false;
                    group.add(wire);
                };
                // Торс
                addPart(new THREE.CylinderGeometry(0.4, 0.32, 1.1, 20), 0, 0.45, 0);
                // Голова
                addPart(new THREE.SphereGeometry(0.26, 24, 24), 0, 1.35, 0);
                // Руки
                addPart(new THREE.CylinderGeometry(0.075, 0.075, 0.8, 14), -0.52, 0.55, 0);
                addPart(new THREE.CylinderGeometry(0.075, 0.075, 0.8, 14), 0.52, 0.55, 0);
                // Ноги
                addPart(new THREE.CylinderGeometry(0.1, 0.1, 1.0, 14), -0.18, -0.55, 0);
                addPart(new THREE.CylinderGeometry(0.1, 0.1, 1.0, 14), 0.18, -0.55, 0);
                group.position.y = FLOOR_Y + 1.3; // центрируем по платформе
            }

            // ===== ОБНОВЛЕНИЕ СТАТУСА =====
            function updateStatus(text) {
                const status = document.getElementById('bodyScanStatus');
                if (status) status.textContent = 'Статус: ' + text;
                const loaderText = document.getElementById('health3DLoaderText');
                if (loaderText && text.startsWith('Загрузка скана')) {
                    loaderText.textContent = text.replace('Загрузка скана', 'Скан загружается');
                }
            }

            function finishLoading() {
                const loaderElement = document.getElementById('health3DLoader');
                if (loaderElement) loaderElement.hidden = true;
            }

            // ===== RESIZE (ResizeObserver — вкладка может быть скрыта при старте) =====
            function onResize() {
                const { w, h } = currentSize();
                if (w === W && h === H) return;
                W = w; H = h;
                camera.aspect = W / H;
                camera.updateProjectionMatrix();
                renderer.setSize(W, H, false);
            }
            window.addEventListener('resize', onResize);
            if (typeof ResizeObserver !== 'undefined') {
                new ResizeObserver(onResize).observe(container);
            }

            // ===== АНИМАЦИОННЫЙ ЦИКЛ =====
            const clock = new THREE.Clock();
            let animationFrame = null;
            let running = false;
            function animate() {
                if (!running) return;
                animationFrame = requestAnimationFrame(animate);
                const dt = clock.getDelta();
                const t = clock.elapsedTime;

                holoUniforms.uTime.value = t;
                platformUniforms.uTime.value = t;

                if (mixer) mixer.update(dt);

                // Лёгкое «парение» модели над платформой
                characterGroup.position.y = Math.sin(t * 1.1) * 0.04;

                controls.update();
                renderer.render(scene, camera);
            }

            function setActive(active) {
                if (active && !running) {
                    running = true;
                    clock.start();
                    animate();
                } else if (!active && running) {
                    running = false;
                    if (animationFrame !== null) cancelAnimationFrame(animationFrame);
                    animationFrame = null;
                    clock.stop();
                }
            }

            window.health3D = { setActive };
            setActive(document.getElementById('view-health')?.classList.contains('active') === true);
        }
    }
})();
