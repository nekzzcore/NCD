/* Offline-first Supabase sync. Auth tokens belong exclusively to the official SDK. */
(function () {
    'use strict';
    const CONFIG = 'gt-supabase-config-v1', OWNER = 'gt-supabase-owner-v1';
    const clone = value => JSON.parse(JSON.stringify(value));
    const stable = value => Array.isArray(value) ? value.map(stable) : value && typeof value === 'object' ? Object.fromEntries(Object.keys(value).sort().map(key => [key, stable(value[key])])) : value;
    const same = (a, b) => JSON.stringify(stable(a)) === JSON.stringify(stable(b));
    const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
    const empty = () => ({ goals: [], transactions: [], safetyFund: {}, profile: {}, financeOther: {}, calendar: {} });
    const normalize = value => ({ ...empty(), ...(value || {}) });
    function validateState(value) {
        const state = normalize(value);
        if (!Array.isArray(state.goals) || !Array.isArray(state.transactions) ||
            !['safetyFund','profile','financeOther','calendar'].every(key => object(state[key])) ||
            state.goals.some(goal => !object(goal) || typeof goal.id !== 'string' || typeof goal.title !== 'string') ||
            ['nickname','status','createdAt','customAvatarData'].some(key => state.profile[key] !== undefined && typeof state.profile[key] !== 'string')) throw new Error('Unsupported cloud data');
        return state;
    }
    function merge(base, local, remote, prefer, path = '', conflicts = []) {
        if (same(local, base)) return { value: remote, conflicts };
        if (same(remote, base) || same(local, remote)) return { value: local, conflicts };
        if (path === '/safetyFund') {
            if (!prefer) conflicts.push(path);
            return { value: prefer === 'remote' ? remote : local, conflicts };
        }
        if (object(local) && object(remote) && (object(base) || base === undefined)) {
            const value = {};
            for (const key of new Set([...Object.keys(base || {}), ...Object.keys(remote), ...Object.keys(local)])) {
                if (['__proto__','constructor','prototype'].includes(key)) continue;
                const next = merge(base?.[key], local[key], remote[key], prefer, `${path}/${key}`, conflicts).value;
                if (next !== undefined) value[key] = next;
            }
            return { value, conflicts };
        }
        const keyed = array => Array.isArray(array) && array.every(item => object(item) && typeof item.id === 'string') && new Set(array.map(item => item.id)).size === array.length;
        if (keyed(local) && keyed(remote) && (keyed(base) || base === undefined)) {
            const maps = [base || [], local, remote].map(items => new Map(items.map(item => [item.id, item])));
            const value = [];
            for (const id of new Set([...remote.map(item => item.id), ...local.map(item => item.id), ...(base || []).map(item => item.id)])) {
                const item = merge(maps[0].get(id), maps[1].get(id), maps[2].get(id), prefer, `${path}/${id}`, conflicts).value;
                if (item !== undefined) value.push(item);
            }
            return { value, conflicts };
        }
        if (!prefer) conflicts.push(path || '/');
        return { value: prefer === 'remote' ? remote : local, conflicts };
    }
    function validateConfig(url, key) {
        const parsed = new URL(url);
        if (parsed.protocol !== 'https:' || parsed.username || parsed.password || parsed.search || parsed.hash || !['','/'].includes(parsed.pathname)) throw new Error('Укажите HTTPS URL проекта без пути, пароля и параметров.');
        if (!/^sb_publishable_[A-Za-z0-9_-]+$/.test(key)) {
            let role;
            try { role = JSON.parse(atob(key.split('.')[1].replace(/-/g,'+').replace(/_/g,'/'))).role; } catch {}
            if (role !== 'anon') throw new Error('Допустим только публичный anon/publishable key. Секретные ключи запрещены.');
        }
        return { url: parsed.origin, key };
    }
    window.CloudSyncCore = { merge, normalize, empty, validateConfig };
    let app, client, config, session, subscription, timer, polling, busy = false, applying = false;
    let syncDiagnostic = '';
    let message = 'Облако не подключено. Данные сохраняются на устройстве.', conflict = false, bindNeeded = false, previews = [];
    const read = (key, fallback) => { const value = localStorage.getItem(key); return value ? JSON.parse(value) : fallback; };
    const write = (key, value) => localStorage.setItem(key, JSON.stringify(value));
    const ownerId = () => session?.user?.id ? `${config.url}|${session.user.id}` : null;
    const metaKey = () => `gt-cloud-state-v1:${ownerId()}`;
    const backupKey = () => `gt-cloud-backup-v1:${ownerId()}`;
    function status(text) { message = text; refresh(); document.dispatchEvent(new Event('goaltracker:cloud-session')); }
    function capture() {
        const finance = window.finance?.getData?.() || read('goalTracker_finance', {});
        const { transactions = [], safetyFund = {}, ...financeOther } = finance;
        return clone({ goals: app.goals, transactions, safetyFund, financeOther,
            profile: { nickname: app.user?.nickname || '', status: app.user?.status || '', createdAt: app.user?.createdAt || '', customAvatarData: app.getCustomAvatar?.() || '' },
            calendar: { notes: app.notes || {}, events: app.events || [], achievements: app.achievements || [] } });
    }
    function localEmpty(state) {
        return !state.goals.length && !state.transactions.length && !state.safetyFund.balance && !(state.safetyFund.history || []).length &&
            !(state.financeOther.investments?.assets || []).length && !(state.financeOther.growth?.ideas || []).length &&
            !state.financeOther.growth?.baseIncome && !state.financeOther.growth?.currentIncome && !(state.financeOther.growth?.history || []).length &&
            (!state.safetyFund.targetMonths || state.safetyFund.targetMonths === 6) &&
            !Object.values(state.financeOther.budget?.categories || {}).some(item => item.limit) &&
            !Object.keys(state.calendar.notes || {}).length && !(state.calendar.events || []).length && !(state.calendar.achievements || []).length && !state.profile.customAvatarData && !state.profile.status;
    }
    function appBusy() { return app._attachmentPending || app._goalSaveInProgress || app._goalActionPending || app._profileSaving || app._avatarLoading || app._resetting; }
    function localChanged() {
        if (applying || !session || !config || localStorage.getItem(OWNER) !== ownerId()) return;
        if (app.settings.autoSync === false) { clearTimeout(timer); status('Изменения сохранены на устройстве. Автосинхронизация выключена.'); return; }
        // The saved baseline + current durable local data form the persistent outbox.
        status(navigator.onLine === false ? 'Офлайн: изменения сохранены, синхронизация ожидает сеть.' : 'Есть локальные изменения.');
        clearTimeout(timer); timer = setTimeout(() => sync(), 800);
    }
    async function applyState(compute) {
        if (appBusy()) return false;
        applying = true;
        const controls = [...document.querySelectorAll('button,input,textarea,select')].map(element => [element, element.disabled]);
        controls.forEach(([element]) => { element.disabled = true; });
        try {
            await window.ProfileStorage.flush?.();
            const before = capture(), next = normalize(compute(before));
            if (same(before, next) && app.user?.supabaseUserId === session.user.id) return true;
            const local = app.serialize();
            const financeBefore = window.finance?.getData?.() || read('goalTracker_finance', {});
            // Keep a reviewable local backup before any incoming cloud replacement.
            write(backupKey(), { savedAt: new Date().toISOString(), profile: local, finance: financeBefore, avatar: before.profile.customAvatarData });
            const data = { ...local, user: { ...(local.user || {}), nickname: next.profile.nickname || local.user?.nickname || session.user.email?.split('@')[0] || 'Профиль', status: next.profile.status || '', ...(next.profile.createdAt ? { createdAt: next.profile.createdAt } : {}) },
                goals: next.goals, notes: next.calendar.notes || {}, events: next.calendar.events || [], achievements: next.calendar.achievements || [] };
            if (!data.user.id) data.user.id = crypto.randomUUID();
            data.user.supabaseUserId = session.user.id;
            const finance = { ...next.financeOther, transactions: next.transactions, safetyFund: next.safetyFund };
            const avatarKey = `customAvatarData:${data.user.id || data.user.createdAt || 'local'}`;
            const avatar = next.profile.customAvatarData || '';
            if (avatar && (avatar.length > 200000 || !/^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(avatar))) throw new Error('Облачный аватар имеет неподдерживаемый формат.');
            try {
                localStorage.setItem('goalTracker_finance', JSON.stringify(finance));
                localStorage.setItem(avatarKey, avatar);
                await window.ProfileStorage.save(data);
            } catch (error) {
                localStorage.setItem('goalTracker_finance', JSON.stringify(financeBefore));
                localStorage.setItem(avatarKey, before.profile.customAvatarData || '');
                throw error;
            }
            app.loadData(); window.finance?.replaceData?.(finance); app.updateGreeting(); app.render();
            return true;
        } finally {
            applying = false; controls.forEach(([element, disabled]) => { if (element.isConnected) element.disabled = disabled; });
        }
    }
    async function settleReceipt(meta, prefer) {
        if (!meta.receipt) return true;
        let merged;
        const applied = await applyState(now => {
            merged = merge(meta.receipt.before, now, meta.receipt.accepted, prefer);
            if (merged.conflicts.length) { conflict = true; throw new Error('Локальные правки пересеклись с входящей синхронизацией. Повторите синхронизацию.'); }
            return merged.value;
        });
        if (applied) { delete meta.receipt; write(metaKey(), meta); }
        return applied;
    }
    async function sync(prefer) {
        if (!client || !session || !app || busy || applying) return false;
        const identity = ownerId();
        if (localStorage.getItem(OWNER) !== identity) { bindNeeded = !localStorage.getItem(OWNER); status(bindNeeded ? 'Подтвердите привязку данных устройства.' : 'Данные принадлежат другому аккаунту. Синхронизация заблокирована.'); return false; }
        if (navigator.onLine === false) { status('Офлайн: данные остаются на устройстве.'); return false; }
        if (appBusy()) { clearTimeout(timer); timer = setTimeout(() => sync(prefer), 1000); return false; }
        busy = true; conflict = false; syncDiagnostic = ''; status('Синхронизация…');
        let operation = 'goaltracker_read_state';
        try {
            let meta = read(metaKey(), { base: null, revision: 0 });
            if (!await settleReceipt(meta, prefer)) { status('Ожидание завершения локального сохранения.'); return false; }
            const response = await client.rpc('goaltracker_read_state');
            if (response.error) throw response.error;
            if (app._resetting || ownerId() !== identity || localStorage.getItem(OWNER) !== identity) throw new Error('Аккаунт изменился. Синхронизация прервана.');
            const remote = validateState(response.data.state), local = validateState(capture());
            const base = meta.base || (response.data.revision > 0 && localEmpty(local) ? local : empty());
            const pending = merge(base, local, remote);
            previews = pending.conflicts.map(path => {
                const get = state => path.split('/').slice(1).reduce((value, key) => Array.isArray(value) ? value.find(item => item.id === key) : value?.[key], state);
                const describe = value => path.includes('customAvatarData') ? (value ? 'Фото профиля' : 'Без фото') : path === '/safetyFund' ? `Баланс: ${value?.balance || 0}, пополнений: ${value?.history?.length || 0}` : value === undefined ? 'Удалено' : JSON.stringify(value).slice(0, 250);
                return `${path.split('/').at(-1)} · На устройстве: ${describe(get(local))} · В облаке: ${describe(get(remote))}`;
            });
            if (prefer && pending.conflicts.length) write(`gt-cloud-conflict-backup-v1:${identity}`, { savedAt: new Date().toISOString(), base, local, remote });
            const merged = prefer ? merge(base, local, remote, prefer) : pending;
            if (merged.conflicts.length) { conflict = true; status(`Обнаружены пересекающиеся изменения (${merged.conflicts.length}). Выберите версию спорных полей.`); return false; }
            let revision = response.data.revision;
            if (!same(merged.value, remote)) {
                operation = 'goaltracker_write_state';
                const result = await client.rpc('goaltracker_write_state', { expected_revision: revision, next_state: merged.value, request_id: crypto.randomUUID() });
                if (result.error) {
                    if (result.error.code === '40001') { status('Другое устройство сохранило изменения. Повторяем объединение.'); clearTimeout(timer); timer = setTimeout(() => sync(prefer), 500); return false; }
                    throw result.error;
                }
                revision = result.data.revision;
            }
            if (app._resetting || ownerId() !== identity || localStorage.getItem(OWNER) !== identity) throw new Error('Аккаунт изменился. Данные сохранены в прежнем аккаунте; локальный профиль не заменён.');
            // Receipt is durable before applying: edits made while the request was in flight survive.
            meta = { base: merged.value, revision, receipt: { before: local, accepted: merged.value } };
            write(metaKey(), meta);
            if (!await settleReceipt(meta, prefer)) { status('Облако сохранено. Ожидание локального сохранения.'); timer = setTimeout(() => sync(prefer), 1000); return false; }
            status('Синхронизировано · ' + new Date().toLocaleTimeString('ru-RU'));
            if (!same(capture(), meta.base)) localChanged();
            return true;
        } catch (error) {
            // Do not log responses, tokens, profile content or credentials.
            const code = /^(?:PGRST\d{3}|[0-9A-Z]{5})$/.test(error?.code || '') ? error.code : '';
            syncDiagnostic = code ? `Код: ${code} · Операция: ${operation}` : '';
            // A failed RPC is not evidence that the whole SQL schema was never applied.
            status(conflict ? 'Локальные и облачные правки пересеклись. Выберите версию спорных полей.' : 'Синхронизация не завершена. Локальные данные сохранены. Повторите попытку; если ошибка сохраняется, проверьте доступ к данным в Supabase.');
            return false;
        } finally { busy = false; refresh(); }
    }
    async function acceptSession(next) {
        const previousId = session?.user?.id;
        session = next; bindNeeded = false; conflict = false; syncDiagnostic = '';
        status(next ? 'Аккаунт подключён. Ожидание синхронизации.' : 'Вы не вошли. Локальная работа доступна.');
        if (!next) { status('Вы не вошли. Локальная работа доступна.'); return; }
        const identity = ownerId(), owner = localStorage.getItem(OWNER);
        if (owner && owner !== identity) { status('На устройстве данные другого аккаунта. Выход не удаляет их. Используйте отдельный профиль браузера для другого аккаунта.'); return; }
        if (!owner && !localEmpty(capture())) { bindNeeded = true; status('Подтвердите привязку данных устройства к аккаунту. Фото и финансовые данные будут переданы в ваш Supabase.'); return; }
        if (!owner) localStorage.setItem(OWNER, identity);
        if (previousId !== next.user.id || app.settings.autoSync !== false) sync();
    }
    async function boundedFetch(input, options = {}) {
        const controller = new AbortController();
        const abort = () => controller.abort();
        if (options.signal?.aborted) controller.abort();
        else options.signal?.addEventListener('abort', abort, { once: true });
        const timeout = setTimeout(abort, 15000);
        try { return await window.fetch(input, { ...options, signal: controller.signal }); }
        finally { clearTimeout(timeout); options.signal?.removeEventListener('abort', abort); }
    }
    async function initialize() {
        if (client || !app) return;
        try {
            const saved = read(CONFIG, window.SupabaseConfig || null);
            if (!saved) return;
            config = validateConfig(saved.url, saved.key);
            if (!window.supabase?.createClient) throw new Error('SDK unavailable');
            client = window.supabase.createClient(config.url, config.key, { global: { fetch: boundedFetch }, auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false, storageKey: `gt-supabase-auth:${config.url}` } });
            subscription = client.auth.onAuthStateChange((_event, next) => {
                // SDK auth callbacks must not await SDK operations (avoids auth lock deadlocks).
                setTimeout(() => acceptSession(next).catch(() => status('Облачная сессия недоступна. Локальная работа продолжается.')), 0);
            });
            const result = await client.auth.getSession();
            if (result.error) throw result.error;
            await acceptSession(result.data.session);
            clearInterval(polling); polling = setInterval(() => { if (app.settings.autoSync !== false) sync(); }, 60000);
        } catch { status('Подключение облака недоступно. Локальная работа продолжается.'); }
    }
    async function configure(url, key) {
        if (session || busy) throw new Error('Сначала выйдите из облачного аккаунта.');
        const value = validateConfig(url.trim(), key.trim());
        const owner = localStorage.getItem(OWNER);
        if (owner && !owner.startsWith(value.url + '|')) throw new Error('Устройство связано с другим проектом. Используйте отдельный профиль браузера.');
        write(CONFIG, value); subscription?.data?.subscription?.unsubscribe(); client = null; config = value;
        await initialize();
    }
    async function authenticate(email, password, signUp) {
        if (!client) await initialize();
        if (!client) throw new Error('Подключение к облаку временно недоступно. Повторите попытку.');
        const method = signUp ? 'signUp' : 'signInWithPassword';
        const result = await client.auth[method]({ email, password });
        if (result.error) throw new Error(signUp ? 'Не удалось зарегистрироваться. Проверьте Email, пароль и настройки Auth.' : 'Вход не выполнен. Проверьте Email, пароль и подтверждение почты.');
        if (result.data.session) await acceptSession(result.data.session);
        else status('Проверьте почту: подтвердите регистрацию, затем войдите с паролем.');
    }
    async function logout() {
        if (busy || applying) throw new Error('Дождитесь завершения синхронизации.');
        const result = await client.auth.signOut({ scope: 'local' });
        if (result.error) throw new Error('Выход не завершён. Проверьте сеть и повторите.');
        await acceptSession(null);
    }
    let authNotice = '', authSuccess = false;
    function setAuthMode(recovery) {
        const modal = document.getElementById('cloudAuthModal'), form = modal.querySelector('form');
        if (form.dataset.saving) return;
        form.dataset.recovery = recovery ? 'true' : 'false';
        authNotice = ''; authSuccess = false;
        const password = form.querySelector('[name="password"]');
        password.value = ''; password.required = !recovery; password.disabled = recovery;
        if (!recovery) { form.querySelector('[value="signin"]').checked = true; password.autocomplete = 'current-password'; }
        form.querySelector('[data-cloud-password]').hidden = recovery;
        form.querySelector('.cloud-auth-mode').hidden = recovery;
        form.querySelector('[data-cloud-forgot]').hidden = recovery;
        form.querySelector('[data-cloud-back]').hidden = !recovery;
        form.querySelector('[type="submit"]').textContent = recovery ? 'Сбросить пароль' : 'Продолжить';
        document.getElementById('cloudAuthTitle').textContent = recovery ? 'Восстановление пароля' : 'Вход / Регистрация';
        refresh(); form.querySelector('[name="email"]').focus();
    }
    async function requestPasswordReset(email) {
        if (!client) await initialize();
        if (!client) throw new Error('Подключение к облаку временно недоступно. Повторите попытку.');
        const { error } = await client.auth.resetPasswordForEmail(email.trim());
        if (error) throw new Error('Не удалось отправить инструкцию. Проверьте Email и сеть или повторите позже.');
        authNotice = 'Инструкция по сбросу отправлена на почту'; authSuccess = true;
        refresh(); app?.showToast?.(authNotice, 'success');
    }
    function closeAuth() {
        const modal = document.getElementById('cloudAuthModal');
        if (!modal) return;
        const wasOpen = modal.classList.contains('active');
        modal.classList.remove('active');
        modal.querySelector('[name="password"]').value = '';
        if (wasOpen && document.getElementById('settingsModal')?.classList.contains('active')) {
            document.querySelector(session ? '[data-cloud-logout]' : '[data-cloud-open-auth]')?.focus();
        }
    }
    function openAuth() {
        const modal = document.getElementById('cloudAuthModal');
        if (!modal || session || modal.querySelector('form').dataset.saving) return;
        modal.querySelector('[name="password"]').value = '';
        modal.classList.add('active');
        setAuthMode(false);
        refresh();
        modal.querySelector('[name="email"]').focus();
    }
    function refresh() {
        const container = document.getElementById('cloudSyncPanel');
        if (!container) return;
        const set = (selector, text) => { const node = container.querySelector(selector); if (node) node.textContent = text; };
        const synced = !!session && message.startsWith('Синхронизировано');
        set('[data-cloud-status]', synced ? 'Синхронизировано 🟢' : session ? 'Аккаунт подключён 🟢' : message);
        container.querySelector('[data-cloud-status]').classList.toggle('is-connected', !!session);
        set('[data-cloud-sync-status]', message);
        container.querySelector('[data-cloud-sync-status]').hidden = !session || synced;
        set('[data-cloud-diagnostic]', syncDiagnostic);
        container.querySelector('[data-cloud-diagnostic]').hidden = !syncDiagnostic;
        container.querySelector('[data-cloud-status]').classList.toggle('is-synced', synced);
        set('[data-cloud-detail-status]', message);
        set('[data-cloud-account]', session?.user?.email || session?.user?.id || '');
        container.querySelector('[data-cloud-account]').hidden = !session;
        set('[data-cloud-user-id]', session ? `user_id: ${session.user.id}` : '');
        container.querySelector('[data-cloud-open-auth]').hidden = !!session;
        container.querySelector('[data-cloud-actions]').hidden = !session;
        const details = container.querySelector('[data-cloud-details]');
        details.hidden = !session;
        if (bindNeeded || conflict) details.open = true;
        if (!session) details.open = false;
        container.querySelector('[data-cloud-bind]').hidden = !bindNeeded;
        container.querySelector('[data-cloud-conflicts]').hidden = !conflict;
        set('[data-cloud-conflict-preview]', previews.join('\n'));
        const form = document.querySelector('[data-cloud-auth]');
        if (form) form.hidden = !!session;
        const authStatus = document.querySelector('[data-cloud-auth-status]');
        if (authStatus) { authStatus.textContent = authNotice || message; authStatus.classList.toggle('is-success', authSuccess); }
        if (session) closeAuth();
        if (config) {
            const field = container.querySelector('[name="url"]'); if (!field.value) field.value = config.url;
        }
    }
    async function submitCloudForm(event) {
        event.preventDefault(); const form = event.target;
        if (form.dataset.saving) return;
        if (form.matches('[data-cloud-auth]')) { authNotice = ''; authSuccess = false; refresh(); }
        const fields = new FormData(form);
        const controls = [...form.querySelectorAll('input, button')].map(element => [element, element.disabled]);
        form.dataset.saving = 'true'; form.setAttribute('aria-busy', 'true');
        controls.forEach(([element]) => { element.disabled = true; });
        try {
            if (form.matches('[data-cloud-config]')) await configure(fields.get('url'), fields.get('key'));
            else if (form.dataset.recovery === 'true') await requestPasswordReset(fields.get('email'));
            else { authNotice = ''; authSuccess = false; await authenticate(fields.get('email'), fields.get('password'), fields.get('mode') === 'signup'); }
        } catch (error) {
            const text = error.message || 'Операция не выполнена. Локальные данные сохранены.';
            if (form.matches('[data-cloud-auth]')) { authNotice = text; authSuccess = false; refresh(); }
            else status(text);
        }
        finally {
            form.querySelectorAll('[type="password"]').forEach(field => { field.value = ''; });
            delete form.dataset.saving; form.removeAttribute('aria-busy');
            controls.forEach(([element, disabled]) => { element.disabled = disabled; });
        }
    }
    function bindUI() {
        const container = document.getElementById('cloudSyncPanel');
        if (!container || container.dataset.bound) { refresh(); return; }
        container.dataset.bound = 'true';
        container.querySelector('[data-cloud-config]').addEventListener('submit', submitCloudForm);
        container.querySelector('[data-cloud-open-auth]').addEventListener('click', openAuth);
        const modal = document.getElementById('cloudAuthModal');
        modal.querySelector('[data-cloud-auth]').addEventListener('submit', submitCloudForm);
        modal.querySelector('#closeCloudAuthBtn').addEventListener('click', closeAuth);
        modal.querySelector('[data-cloud-forgot]').addEventListener('click', () => setAuthMode(true));
        modal.querySelector('[data-cloud-back]').addEventListener('click', () => setAuthMode(false));
        modal.querySelectorAll('[name="mode"]').forEach(input => input.addEventListener('change', () => {
            authNotice = ''; authSuccess = false; refresh();
            modal.querySelector('[name="password"]').autocomplete = input.value === 'signup' ? 'new-password' : 'current-password';
        }));
        document.addEventListener('keydown', event => {
            if (!modal.classList.contains('active')) return;
            if (event.key === 'Escape') { event.preventDefault(); closeAuth(); }
            if (event.key === 'Tab') {
                const controls = [...modal.querySelectorAll('button,input')].filter(element => !element.disabled && !element.closest('[hidden]'));
                const first = controls[0], last = controls[controls.length - 1];
                if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
                else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
            }
        });
        container.querySelector('[data-cloud-sync]').addEventListener('click', () => sync());
        container.querySelector('[data-cloud-logout]').addEventListener('click', () => logout().catch(error => status(error.message)));
        container.querySelector('[data-cloud-bind]').addEventListener('click', () => {
            if (!session || (localStorage.getItem(OWNER) && localStorage.getItem(OWNER) !== ownerId())) return;
            localStorage.setItem(OWNER, ownerId()); bindNeeded = false; sync();
        });
        container.querySelectorAll('[data-cloud-resolve]').forEach(button => button.addEventListener('click', () => sync(button.dataset.cloudResolve)));
        refresh();
    }
    function prepareLocalReset() {
        clearTimeout(timer); clearInterval(polling);
        const owner = localStorage.getItem(OWNER);
        // Local reset must not become a bulk deletion in the cloud on next login.
        if (owner) write(`gt-cloud-state-v1:${owner}`, { base: null, revision: 0 });
    }
    function attachmentStorage() {
        if (!client || !session || busy || applying || localStorage.getItem(OWNER) !== ownerId())
            throw new Error('Войдите в облачный аккаунт, привяжите профиль и дождитесь синхронизации.');
        const identity = ownerId(), storage = client.storage.from('goal-attachments');
        return { userId: session.user.id, storage, assertOwner() {
            if (identity !== ownerId() || localStorage.getItem(OWNER) !== identity) throw new Error('Облачный аккаунт изменился.');
        } };
    }
    window.CloudSync = { socialConnection() {
        if (!client || !session || localStorage.getItem(OWNER) !== ownerId()) return null;
        return { client, userId: session.user.id, identity: ownerId() };
    }, attachmentStorage, openAuth, closeAuth, prepareLocalReset, attach(instance) { app = instance; bindUI(); initialize(); }, bindUI, localChanged, sync, configured: () => !!client, isApplying: () => applying, isSyncing: () => busy,
        configure, authenticate, logout, capture, localEmpty };
    window.addEventListener('online', () => { if (app?.settings.autoSync === false) return; if (client && session) sync(); else if (client) client.auth.getSession().then(result => acceptSession(result.data.session)).catch(() => status('Восстановление облачной сессии ожидает сеть.')); else initialize(); });
    window.addEventListener('focus', () => { if (app?.settings.autoSync !== false) sync(); });
    document.addEventListener('goaltracker:storage-saved', localChanged);
    document.addEventListener('goaltracker:finance-changed', localChanged);
    document.addEventListener('goaltracker:profile-rendered', bindUI);
})();
