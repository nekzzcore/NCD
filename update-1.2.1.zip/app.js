// ===== GoalTracker Pro - Main Application =====

// ☁️ Облачный сервер (настраивается в Настройки → Синхронизация, пусто = локально)
const CLOUD_URL = '';

class GoalTracker {
    constructor() {
        this.user = null;
        this.goals = [];
        this.achievements = [];
        this.habits = [];
        this.events = [];
        this.notes = {};
        this.settings = {
            theme: 'light',
            notifications: true,
            reminderDays: 3,
            gamification: true,
            autoSync: true
        };
        this.updatedAt = null;      // время последней успешной синхронизации
        this._dirty = false;        // были локальные изменения после синхронизации
        this._syncTimer = null;
        this.gamification = {
            xp: 0,
            level: 1,
            streak: 0,
            lastActiveDate: null,
            badges: []
        };
        this.currentView = 'dashboard';
        this.currentMonth = new Date();
        this.selectedDate = null;
        this.init();
    }

    init() {
        this.loadData();
        this.bindEvents();
        this.initTheme();

        if (this.user) {
            this.showApp();
        } else {
            this.showAuth();
            // Новое устройство: пробуем подтянуть профиль с сервера (автовход)
            if (this.settings.autoSync) {
                setTimeout(() => { if (!this.user) this.syncData(true); }, 500);
            }
        }
    }

    // ===== Auth =====
    showAuth() {
        document.getElementById('authScreen').style.display = 'flex';
        document.getElementById('app').style.display = 'none';

        if (this.authBound) return;
        this.authBound = true;

        // Avatar selector
        document.querySelectorAll('.avatar-option').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.avatar-option').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
            });
        });

        document.getElementById('authForm').addEventListener('submit', (e) => {
            e.preventDefault();
            const nickname = document.getElementById('authNickname').value.trim();
            const avatar = document.querySelector('.avatar-option.active')?.dataset.avatar || '😊';

            if (nickname.length < 2) {
                this.showToast('Никнейм должен быть от 2 символов', 'error');
                return;
            }

            this.user = {
                nickname: nickname,
                avatar: avatar,
                createdAt: new Date().toISOString()
            };
            this.saveData();
            this.showApp();
            this.showToast(`Добро пожаловать, ${nickname}! 🎉`, 'success');
        });
    }

    updateGreeting() {
        const hour = new Date().getHours();
        let greeting = 'Добрый день';
        if (hour < 6) greeting = 'Доброй ночи';
        else if (hour < 12) greeting = 'Доброе утро';
        else if (hour < 18) greeting = 'Добрый день';
        else greeting = 'Добрый вечер';
        document.getElementById('dashboardGreeting').textContent = `${greeting}, ${this.user?.nickname || ''}! 👋`;
    }

    showApp() {
        document.getElementById('authScreen').style.display = 'none';
        document.getElementById('app').style.display = 'flex';

        this.updateGreeting();

        this.render();
        this.checkDeadlines();
        this.checkTodayNotes();

        // Register service worker for PWA
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/sw.js').catch(() => {});
        }

        // PWA Install Prompt
        let deferredPrompt = null;
        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            deferredPrompt = e;
            this.showInstallButton();
        });
        window.addEventListener('appinstalled', () => {
            deferredPrompt = null;
            this.hideInstallButton();
            this.showToast('Приложение установлено! 🎉', 'success');
        });
        // Сохраняем ссылку на prompt для использования в UI
        this.deferredPrompt = deferredPrompt;

        // 🔄 OTA Update Check (Capacitor Updater)
        this.checkForUpdates();

        // Тихая синхронизация при запуске (подтянуть данные с сервера)
        if (this.settings.autoSync) {
            setTimeout(() => this.syncData(true), 800);
        }
    }

    logout() {
        if (!confirm('Выйти из профиля? Данные сохранятся на этом устройстве.')) return;
        this.user = null;
        this.saveData();
        this.closeModal('settingsModal');
        document.getElementById('app').style.display = 'none';
        document.getElementById('authScreen').style.display = 'flex';
    }

    // ===== Data Management =====
    loadData() {
        try {
            const saved = localStorage.getItem('goalTracker_data');
            if (saved) {
                const data = JSON.parse(saved);
                this.user = data.user || null;
                this.goals = data.goals || [];
                this.achievements = data.achievements || [];
                this.habits = data.habits || [];
                this.events = data.events || [];
                this.notes = data.notes || {};
                this.settings = { ...this.settings, ...(data.settings || {}) };
                this.gamification = { ...this.gamification, ...(data.gamification || {}) };
                this.updatedAt = data.updatedAt || null;
                this.notes = this.normalizeNotes(this.notes);
            }
        } catch (e) {
            console.error('Error loading data:', e);
        }
    }

    serialize() {
        return {
            user: this.user,
            goals: this.goals,
            achievements: this.achievements,
            habits: this.habits,
            events: this.events,
            notes: this.notes,
            settings: this.settings,
            gamification: this.gamification,
            updatedAt: this.updatedAt
        };
    }

    saveData() {
        const data = this.serialize();
        this._dirty = true;
        localStorage.setItem('goalTracker_data', JSON.stringify(data));
        this.scheduleAutoSync();
    }

    scheduleAutoSync() {
        if (!this.settings.autoSync || !this.user) return;
        clearTimeout(this._syncTimer);
        this._syncTimer = setTimeout(() => this.syncData(true), 2000);
    }

    getSyncBase() {
        // Синхронизация только если явно задан URL в настройках
        if (this.settings.syncUrl) return this.settings.syncUrl.replace(/\/$/, '');
        // По умолчанию — никакого сервера (автономный режим)
        return '';
    }

    // ===== Код доступа (PIN) =====
    // В автономном режиме не нужен. Оставлен для совместимости при включении синхронизации.
    getPin() {
        try { return localStorage.getItem('goalTracker_pin') || ''; }
        catch { return ''; }
    }

    setPin(pin) {
        try { localStorage.setItem('goalTracker_pin', pin); } catch {}
    }

    // В Electron код берётся из pin.txt автоматически — вводить не нужно
    async ensurePin() {
        if (this.getPin()) return;
        if (window.electronAPI?.getSyncPin) {
            try {
                const pin = await window.electronAPI.getSyncPin();
                if (pin) this.setPin(pin);
            } catch {}
        }
    }

    async apiFetch(base, init = {}) {
        await this.ensurePin();
        const headers = { ...(init.headers || {}) };
        const pin = this.getPin();
        if (pin) headers['X-Goal-PIN'] = pin;
        return fetch(base + '/api/data', { ...init, headers });
    }

    showPinModal(message) {
        const modal = document.getElementById('pinModal');
        if (modal.classList.contains('active')) return;
        document.getElementById('pinForm').reset();
        const err = document.getElementById('pinError');
        err.textContent = message || 'Введите код доступа, показанный на ноутбуке';
        err.className = message ? 'pin-error show error' : 'pin-error show';
        modal.classList.add('active');
        setTimeout(() => document.getElementById('pinInput').focus(), 60);
    }

    applyRemote(data) {
        this.user = data.user || this.user;
        this.goals = data.goals || [];
        this.achievements = data.achievements || [];
        this.habits = data.habits || [];
        this.events = data.events || [];
        this.notes = data.notes || {};
        this.settings = { ...this.settings, ...(data.settings || {}) };
        this.gamification = { ...this.gamification, ...(data.gamification || {}) };
        this.updatedAt = data.updatedAt || null;
        this._dirty = false;
        this.notes = this.normalizeNotes(this.notes);
        localStorage.setItem('goalTracker_data', JSON.stringify({ ...data, updatedAt: this.updatedAt, notes: this.notes }));
        if (data.user && !this.user) this.user = data.user;
    }

    afterRemoteUpdate() {
        if (this.user && document.getElementById('authScreen').style.display !== 'none') {
            // Данные пришли с сервера на новом устройстве — сразу показываем приложение
            this.showApp();
            return;
        }
        this.updateGreeting();
        this.render();
    }

    // ===== Event Binding =====
    bindEvents() {
        // Navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', () => this.switchView(item.dataset.view));
        });

        document.getElementById('toggleSidebar').addEventListener('click', () => {
            document.getElementById('sidebar').classList.toggle('collapsed');
        });

        // Goals
        document.getElementById('addGoalBtn').addEventListener('click', () => this.openGoalModal());
        document.getElementById('addGoalBtn2').addEventListener('click', () => this.openGoalModal());
        document.getElementById('goalForm').addEventListener('submit', (e) => this.saveGoal(e));
        document.getElementById('closeGoalModal').addEventListener('click', () => this.closeModal('goalModal'));
        document.getElementById('cancelGoalBtn').addEventListener('click', () => this.closeModal('goalModal'));
        document.getElementById('closeDetailModal').addEventListener('click', () => this.closeModal('goalDetailModal'));

        // Achievements
        document.getElementById('addAchievementBtn').addEventListener('click', () => this.openAchievementModal());
        document.getElementById('achievementForm').addEventListener('submit', (e) => this.saveAchievement(e));
        document.getElementById('closeAchievementModal').addEventListener('click', () => this.closeModal('achievementModal'));
        document.getElementById('cancelAchievementBtn').addEventListener('click', () => this.closeModal('achievementModal'));

        // Habits
        document.getElementById('addHabitBtn').addEventListener('click', () => this.openHabitModal());
        document.getElementById('habitForm').addEventListener('submit', (e) => this.saveHabit(e));
        document.getElementById('closeHabitModal').addEventListener('click', () => this.closeModal('habitModal'));
        document.getElementById('cancelHabitBtn').addEventListener('click', () => this.closeModal('habitModal'));

        // Notes
        document.getElementById('noteForm').addEventListener('submit', (e) => this.saveNote(e));
        document.getElementById('closeNoteModal').addEventListener('click', () => this.closeModal('noteModal'));
        document.getElementById('cancelNoteBtn').addEventListener('click', () => this.closeModal('noteModal'));
        document.getElementById('deleteNoteBtn').addEventListener('click', () => this.deleteNote());

        // Settings
        document.getElementById('settingsBtn').addEventListener('click', () => this.openSettingsModal());
        document.getElementById('closeSettingsModal').addEventListener('click', () => this.closeModal('settingsModal'));
        document.getElementById('logoutBtn').addEventListener('click', () => this.logout());

        // Код доступа
        document.getElementById('pinForm').addEventListener('submit', (e) => {
            e.preventDefault();
            const pin = document.getElementById('pinInput').value.replace(/\D/g, '');
            if (pin.length < 4) {
                document.getElementById('pinError').textContent = 'Код — минимум 4 цифры';
                document.getElementById('pinError').className = 'pin-error show error';
                return;
            }
            this.setPin(pin);
            this.closeModal('pinModal');
            this.showToast('Код сохранён — синхронизируемся...', 'success');
            setTimeout(() => this.syncData(false), 200);
        });
        document.getElementById('closePinModal').addEventListener('click', () => this.closeModal('pinModal'));
        document.getElementById('cancelPinBtn').addEventListener('click', () => this.closeModal('pinModal'));
        document.getElementById('gamificationEnabled').addEventListener('change', (e) => {
            this.settings.gamification = e.target.checked;
            this.saveData();
        });

        // Theme
        document.getElementById('themeBtn').addEventListener('click', () => this.toggleTheme());
        document.querySelectorAll('.theme-btn').forEach(btn => {
            btn.addEventListener('click', () => this.setTheme(btn.dataset.theme));
        });

        // Filters
        document.getElementById('filterStatus').addEventListener('change', () => this.renderGoals());
        document.getElementById('sortBy').addEventListener('change', () => this.renderGoals());

        // Calendar
        document.getElementById('prevMonth').addEventListener('click', () => this.changeMonth(-1));
        document.getElementById('nextMonth').addEventListener('click', () => this.changeMonth(1));

        // Sync
        document.getElementById('syncBtn').addEventListener('click', () => this.syncData());
        document.getElementById('syncNowBtn').addEventListener('click', () => this.syncData());
        document.getElementById('autoSyncEnabled').addEventListener('change', (e) => {
            this.settings.autoSync = e.target.checked;
            this.saveData();
            this.showToast(e.target.checked ? 'Автосинхронизация включена' : 'Автосинхронизация выключена', 'info');
        });
        document.getElementById('syncUrlInput').addEventListener('change', (e) => {
            this.settings.syncUrl = e.target.value.trim() || '';
            this.saveData();
            this.showToast(this.settings.syncUrl ? 'Сервер синхронизации задан' : 'Автономный режим включён', 'success');
            this.openSettingsModal(); // переоткрыть для обновления UI
        });

        // Export/Import
        document.getElementById('exportDataBtn').addEventListener('click', () => this.exportData());
        document.getElementById('exportCSVBtn').addEventListener('click', () => this.exportCSV());
        document.getElementById('exportPDFBtn').addEventListener('click', () => this.exportPDF());
        document.getElementById('importDataBtn').addEventListener('click', () => this.importData());
        document.getElementById('installPwaBtn').addEventListener('click', () => this.installPWA());

        // Modal overlays
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', () => overlay.parentElement.classList.remove('active'));
        });
    }

    // ===== View Management =====
    switchView(viewName) {
        this.currentView = viewName;
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.toggle('active', item.dataset.view === viewName);
        });
        document.querySelectorAll('.view').forEach(view => {
            view.classList.toggle('active', view.id === `view-${viewName}`);
        });
        this.render();
    }

    render() {
        switch (this.currentView) {
            case 'dashboard': this.renderDashboard(); break;
            case 'goals': this.renderGoals(); break;
            case 'habits': this.renderHabits(); break;
            case 'achievements': this.renderAchievements(); break;
            case 'calendar': this.renderCalendar(); break;
            case 'profile': this.renderProfile(); break;
        }
    }

    // ===== Dashboard =====
    renderDashboard() {
        const total = this.goals.length;
        const active = this.goals.filter(g => g.status === 'active').length;
        const completed = this.goals.filter(g => g.status === 'completed').length;
        const overallProgress = total > 0
            ? Math.round(this.goals.reduce((s, g) => s + this.calculateProgress(g), 0) / total)
            : 0;

        document.getElementById('totalGoals').textContent = total;
        document.getElementById('activeGoals').textContent = active;
        document.getElementById('completedGoals').textContent = completed;
        document.getElementById('overallProgress').textContent = overallProgress + '%';

        const recent = [...this.achievements].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 5);
        document.getElementById('recentAchievements').innerHTML = recent.length
            ? recent.map(a => this.renderAchievementItem(a)).join('')
            : this.renderEmptyState('🏆', 'Пока нет достижений');

        const deadlines = this.goals.filter(g => g.deadline && g.status === 'active')
            .sort((a, b) => new Date(a.deadline) - new Date(b.deadline)).slice(0, 5);
        document.getElementById('upcomingDeadlines').innerHTML = deadlines.length
            ? deadlines.map(g => this.renderDeadlineItem(g)).join('')
            : this.renderEmptyState('📅', 'Нет активных дедлайнов');

        this.renderGamificationWidget();
        this.renderProductivityWidget();
        this.renderGoalHealthWidget();

        // 3D-аватар: обновить HUD (уровень, XP, серия, значки)
        if (window.avatarWidget) {
            window.avatarWidget.update({
                nickname: this.user?.nickname,
                level: this.gamification.level,
                xp: this.gamification.xp,
                streak: this.gamification.streak,
                badges: this.gamification.badges.length
            });
        }
    }

    // ===== Profile (includes Stats) =====
    renderProfile() {
        const container = document.getElementById('profileContent');
        if (!container) return;

        const total = this.goals.length;
        const active = this.goals.filter(g => g.status === 'active').length;
        const completed = this.goals.filter(g => g.status === 'completed').length;
        const totalAchievements = this.achievements.length;
        const totalHabits = this.habits.length;
        const overallProgress = total > 0
            ? Math.round(this.goals.reduce((s, g) => s + this.calculateProgress(g), 0) / total)
            : 0;

        container.innerHTML = `
            <div class="profile-header card">
                <div class="profile-avatar">${this.user?.avatar || '😊'}</div>
                <div class="profile-info">
                    <h2>${this.escapeHtml(this.user?.nickname || 'Гость')}</h2>
                    <p>Уровень ${this.gamification.level} • ${this.gamification.xp} XP • ${this.gamification.badges.length} значков</p>
                    <p>С нами с ${new Date(this.user?.createdAt || Date.now()).toLocaleDateString('ru-RU')}</p>
                </div>
            </div>

            <div class="dashboard-grid">
                <div class="card stat-card">
                    <div class="stat-value">${total}</div>
                    <div class="stat-label">Всего целей</div>
                </div>
                <div class="card stat-card">
                    <div class="stat-value">${active}</div>
                    <div class="stat-label">Активных</div>
                </div>
                <div class="card stat-card">
                    <div class="stat-value">${completed}</div>
                    <div class="stat-label">Завершённых</div>
                </div>
                <div class="card stat-card">
                    <div class="stat-value">${overallProgress}%</div>
                    <div class="stat-label">Общий прогресс</div>
                </div>
                <div class="card stat-card">
                    <div class="stat-value">${totalAchievements}</div>
                    <div class="stat-label">Достижений</div>
                </div>
                <div class="card stat-card">
                    <div class="stat-value">${totalHabits}</div>
                    <div class="stat-label">Привычек</div>
                </div>
            </div>

            <div class="stats-grid">
                <div class="card">
                    <h3>📊 Прогресс по категориям</h3>
                    <div id="categoryStats"></div>
                </div>
                <div class="card">
                    <h3>📈 Активность за неделю</h3>
                    <div id="weeklyActivity"></div>
                </div>
                <div class="card">
                    <h3>🏅 Значки (${this.gamification.badges.length})</h3>
                    <div class="badges-grid">
                        ${this.gamification.badges.length
                            ? this.gamification.badges.map(b => `
                                <div class="badge-item" title="${this.escapeHtml(b.description)}">
                                    <span class="badge-icon">🏅</span>
                                    <span class="badge-name">${this.escapeHtml(b.title)}</span>
                                </div>
                            `).join('')
                            : '<p style="color: var(--text-secondary);">Нет значков пока</p>'}
                    </div>
                </div>
            </div>

            <div class="card">
                <h3>🏆 Последние достижения</h3>
                <div class="achievements-list">
                    ${[...this.achievements].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 5)
                        .map(a => this.renderAchievementItem(a)).join('') || this.renderEmptyState('🏆', 'Нет достижений')}
                </div>
            </div>
        `;

        this.renderCategoryStats();
        this.renderWeeklyActivity();
    }

    renderAchievementItem(a) {
        const goal = this.goals.find(g => g.id === a.goalId);
        return `
            <div class="achievement-item">
                <span class="achievement-icon">🏆</span>
                <div class="achievement-info">
                    <div class="achievement-title">${a.protected ? '🔒' : ''} ${this.escapeHtml(a.title)}</div>
                    <div class="achievement-goal">${goal ? this.escapeHtml(goal.title) : 'Общее'}</div>
                </div>
                <span class="achievement-date">${new Date(a.date).toLocaleDateString('ru-RU')}</span>
            </div>
        `;
    }

    renderDeadlineItem(goal) {
        const daysLeft = this.getDaysLeft(goal.deadline);
        let cls = 'normal';
        if (daysLeft < 0) cls = 'urgent';
        else if (daysLeft <= 3) cls = 'warning';
        return `
            <div class="deadline-item ${cls}">
                <div class="deadline-info">
                    <div class="deadline-title">${this.escapeHtml(goal.title)}</div>
                    <div class="deadline-date">${new Date(goal.deadline).toLocaleDateString('ru-RU')}</div>
                </div>
                <span class="deadline-days ${cls}">${daysLeft >= 0 ? daysLeft + ' дн.' : 'Просрочено'}</span>
            </div>
        `;
    }

    renderEmptyState(icon, text) {
        return `<div class="empty-state"><div class="empty-state-icon">${icon}</div><div class="empty-state-text">${text}</div></div>`;
    }

    // ===== Widgets =====
    renderGamificationWidget() {
        const el = document.getElementById('gamificationWidget');
        if (!el) return;
        const xpProgress = (this.gamification.xp % 100);
        el.innerHTML = `
            <div class="widget-header">
                <span class="widget-icon">⭐</span>
                <div>
                    <div class="widget-title">Уровень ${this.gamification.level}</div>
                    <div class="widget-subtitle">${this.gamification.xp} XP</div>
                </div>
            </div>
            <div class="xp-bar"><div class="xp-fill" style="width:${xpProgress}%"></div></div>
            <div class="widget-stats">
                <div class="widget-stat"><span class="widget-stat-value">${this.gamification.streak}</span><span class="widget-stat-label">дней подряд</span></div>
                <div class="widget-stat"><span class="widget-stat-value">${this.gamification.badges.length}</span><span class="widget-stat-label">значков</span></div>
            </div>
        `;
    }

    renderProductivityWidget() {
        const el = document.getElementById('productivityWidget');
        if (!el) return;
        const today = new Date().toISOString().split('T')[0];
        const todayCount = this.achievements.filter(a => a.date === today).length;
        const weekAgo = new Date(); weekAgo.setDate(weekAgo.getDate() - 7);
        const weekCount = this.achievements.filter(a => new Date(a.date) >= weekAgo).length;
        el.innerHTML = `
            <div class="widget-header">
                <span class="widget-icon">📈</span>
                <div><div class="widget-title">Продуктивность</div><div class="widget-subtitle">за 7 дней</div></div>
            </div>
            <div class="widget-stats">
                <div class="widget-stat"><span class="widget-stat-value">${todayCount}</span><span class="widget-stat-label">сегодня</span></div>
                <div class="widget-stat"><span class="widget-stat-value">${weekCount}</span><span class="widget-stat-label">за неделю</span></div>
                <div class="widget-stat"><span class="widget-stat-value">${(weekCount/7).toFixed(1)}</span><span class="widget-stat-label">в среднем</span></div>
            </div>
        `;
    }

    renderGoalHealthWidget() {
        const el = document.getElementById('goalHealthWidget');
        if (!el) return;
        const active = this.goals.filter(g => g.status === 'active');
        const onTrack = active.filter(g => {
            if (!g.deadline) return true;
            return this.calculateProgress(g) >= 50 || this.getDaysLeft(g.deadline) > 7;
        }).length;
        el.innerHTML = `
            <div class="widget-header">
                <span class="widget-icon">💚</span>
                <div><div class="widget-title">Здоровье целей</div><div class="widget-subtitle">${active.length} активных</div></div>
            </div>
            <div class="health-indicators">
                <div class="health-item"><span class="health-dot good"></span><span>В графике: ${onTrack}</span></div>
                <div class="health-item"><span class="health-dot bad"></span><span>Под угрозой: ${active.length - onTrack}</span></div>
            </div>
        `;
    }

    // ===== Goals =====
    renderGoals() {
        const container = document.getElementById('goalsList');
        const filter = document.getElementById('filterStatus').value;
        const sort = document.getElementById('sortBy').value;

        let items = [...this.goals];
        if (filter !== 'all') items = items.filter(g => g.status === filter);
        items.sort((a, b) => {
            switch (sort) {
                case 'deadline': return (a.deadline || '9999').localeCompare(b.deadline || '9999');
                case 'progress': return this.calculateProgress(b) - this.calculateProgress(a);
                case 'name': return a.title.localeCompare(b.title);
                default: return new Date(b.createdAt) - new Date(a.createdAt);
            }
        });

        if (!items.length) { container.innerHTML = this.renderEmptyState('🎯', 'Нет целей. Создайте первую!'); return; }
        container.innerHTML = items.map(g => this.renderGoalItem(g)).join('');
        container.querySelectorAll('.goal-item').forEach(item => {
            item.addEventListener('click', () => this.openGoalDetail(item.dataset.id));
        });
    }

    renderGoalItem(goal) {
        const progress = this.calculateProgress(goal);
        const pClass = progress >= 100 ? 'complete' : progress >= 60 ? 'high' : progress >= 30 ? 'medium' : 'low';
        const daysLeft = goal.deadline ? this.getDaysLeft(goal.deadline) : null;
        const dClass = daysLeft !== null ? (daysLeft < 0 ? 'urgent' : daysLeft <= 3 ? 'warning' : '') : '';
        return `
            <div class="goal-item" data-id="${goal.id}">
                <div class="goal-item-header">
                    <span class="goal-item-title">${goal.status === 'completed' ? '✅' : '🎯'} ${this.escapeHtml(goal.title)}</span>
                    <span class="goal-item-category">${this.getCategoryLabel(goal.category)}</span>
                </div>
                ${goal.description ? `<div class="goal-item-description">${this.escapeHtml(goal.description)}</div>` : ''}
                <div class="goal-item-meta">
                    <span class="priority-badge ${this.getPriorityClass(goal.priority)}">${this.getPriorityLabel(goal.priority)}</span>
                    ${goal.deadline ? `<span class="goal-item-deadline ${dClass}">📅 ${new Date(goal.deadline).toLocaleDateString('ru-RU')}</span>` : ''}
                    <span>📝 ${goal.subgoals?.length || 0} подцелей</span>
                </div>
                <div class="progress-bar"><div class="progress-fill ${pClass}" style="width:${progress}%"></div></div>
                <div class="progress-text"><span>Прогресс</span><span>${progress}%</span></div>
            </div>
        `;
    }

    // ===== Habits =====
    renderHabits() {
        const container = document.getElementById('habitsList');
        if (!this.habits.length) { container.innerHTML = this.renderEmptyState('📅', 'Нет привычек. Создайте первую!'); return; }

        container.innerHTML = this.habits.map(habit => {
            const today = new Date();
            const daysInMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();
            let daysHtml = '';
            for (let d = 1; d <= daysInMonth; d++) {
                const ds = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
                const done = habit.completedDays?.includes(ds);
                daysHtml += `<button class="habit-day ${done?'completed':''} ${today.getDate()===d?'today':''}" data-habit-id="${habit.id}" data-date="${ds}"></button>`;
            }
            const count = habit.completedDays?.length || 0;
            const total = habit.frequency === 'daily' ? daysInMonth : 1;
            const prog = Math.min(Math.round((count/total)*100), 100);
            return `
                <div class="habit-item" style="border-left:4px solid ${habit.color};">
                    <div class="habit-header">
                        <div class="habit-info"><h4>${this.escapeHtml(habit.title)}</h4><p>${habit.description||''}</p></div>
                        <div class="habit-actions">
                            <button class="btn-icon habit-edit" data-habit-id="${habit.id}">✏️</button>
                            <button class="btn-icon habit-delete" data-habit-id="${habit.id}">🗑️</button>
                        </div>
                    </div>
                    <div class="habit-progress">
                        <div class="progress-bar"><div class="progress-fill high" style="width:${prog}%"></div></div>
                        <span>${count}/${total} дней</span>
                    </div>
                    <div class="habit-days">${daysHtml}</div>
                </div>
            `;
        }).join('');

        container.querySelectorAll('.habit-day').forEach(btn => {
            btn.addEventListener('click', (e) => { e.stopPropagation(); this.toggleHabitDay(btn.dataset.habitId, btn.dataset.date); });
        });
        container.querySelectorAll('.habit-edit').forEach(btn => {
            btn.addEventListener('click', (e) => { e.stopPropagation(); this.openHabitModal(btn.dataset.habitId); });
        });
        container.querySelectorAll('.habit-delete').forEach(btn => {
            btn.addEventListener('click', (e) => { e.stopPropagation(); this.deleteHabit(btn.dataset.habitId); });
        });
    }

    toggleHabitDay(habitId, dateStr) {
        const habit = this.habits.find(h => h.id === habitId);
        if (!habit) return;
        if (!habit.completedDays) habit.completedDays = [];
        const idx = habit.completedDays.indexOf(dateStr);
        if (idx === -1) { habit.completedDays.push(dateStr); this.addXP(2, 'Привычка'); }
        else habit.completedDays.splice(idx, 1);
        this.saveData();
        this.renderHabits();
    }

    openHabitModal(habitId = null) {
        const form = document.getElementById('habitForm');
        if (habitId) {
            const h = this.habits.find(x => x.id === habitId);
            if (h) {
                document.getElementById('habitId').value = h.id;
                document.getElementById('habitTitle').value = h.title;
                document.getElementById('habitDescription').value = h.description || '';
                document.getElementById('habitFrequency').value = h.frequency;
                document.getElementById('habitColor').value = h.color;
            }
        } else { form.reset(); document.getElementById('habitId').value = ''; document.getElementById('habitColor').value = '#6366f1'; }
        document.getElementById('habitModal').classList.add('active');
    }

    saveHabit(e) {
        e.preventDefault();
        const id = document.getElementById('habitId').value;
        const data = {
            title: document.getElementById('habitTitle').value.trim(),
            description: document.getElementById('habitDescription').value.trim(),
            frequency: document.getElementById('habitFrequency').value,
            color: document.getElementById('habitColor').value
        };
        if (id) { const i = this.habits.findIndex(h => h.id === id); if (i !== -1) this.habits[i] = { ...this.habits[i], ...data }; }
        else { data.id = this.generateId(); data.completedDays = []; this.habits.push(data); }
        this.saveData(); this.closeModal('habitModal'); this.renderHabits(); this.showToast('Привычка сохранена!', 'success');
    }

    deleteHabit(id) {
        if (!confirm('Удалить привычку?')) return;
        this.habits = this.habits.filter(h => h.id !== id);
        this.saveData(); this.renderHabits(); this.showToast('Удалено', 'success');
    }

    // ===== Achievements =====
    renderAchievements() {
        const container = document.getElementById('achievementsList');
        const sorted = [...this.achievements].sort((a, b) => new Date(b.date) - new Date(a.date));
        if (!sorted.length) { container.innerHTML = this.renderEmptyState('🏆', 'Пока нет достижений'); return; }

        container.innerHTML = sorted.map(a => {
            const goal = this.goals.find(g => g.id === a.goalId);
            return `
                <div class="achievement-item-full">
                    <span class="achievement-icon">🏆</span>
                    <div class="achievement-info">
                        <div class="achievement-title">${a.protected ? '🔒' : ''} ${this.escapeHtml(a.title)}</div>
                        <div class="achievement-goal">${goal ? this.escapeHtml(goal.title) : 'Общее'}</div>
                        <div class="achievement-date">${new Date(a.date).toLocaleDateString('ru-RU')}</div>
                    </div>
                    <div class="achievement-actions">
                        ${!a.protected ? `
                            <button class="btn-icon btn-edit-achievement" data-id="${a.id}">✏️</button>
                            <button class="btn-icon btn-delete-achievement" data-id="${a.id}">🗑️</button>
                        ` : '<span class="protected-label">🔒 Защищено</span>'}
                    </div>
                </div>
            `;
        }).join('');

        container.querySelectorAll('.btn-edit-achievement').forEach(b => b.addEventListener('click', () => this.openAchievementModal(b.dataset.id)));
        container.querySelectorAll('.btn-delete-achievement').forEach(b => b.addEventListener('click', () => this.deleteAchievement(b.dataset.id)));
    }

    // ===== Calendar =====
    renderCalendar() {
        const grid = document.getElementById('calendarGrid');
        const monthLabel = document.getElementById('currentMonth');
        const year = this.currentMonth.getFullYear();
        const month = this.currentMonth.getMonth();

        monthLabel.textContent = new Date(year, month).toLocaleDateString('ru-RU', { month: 'long', year: 'numeric' });

        const firstDay = new Date(year, month, 1);
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const startDay = (firstDay.getDay() + 6) % 7;
        const today = new Date();

        let html = ['Пн','Вт','Ср','Чт','Пт','Сб','Вс'].map(d => `<div class="calendar-day-header">${d}</div>`).join('');

        const prevLast = new Date(year, month, 0).getDate();
        for (let i = startDay - 1; i >= 0; i--) {
            html += `<div class="calendar-day other-month calendar-day-large"><span class="calendar-day-number">${prevLast - i}</span></div>`;
        }

        for (let d = 1; d <= daysInMonth; d++) {
            const ds = `${year}-${String(month+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
            const hasGoals = this.goals.some(g => g.deadline === ds);
            const hasEvents = this.events.some(e => e.date === ds);
            const dayNotes = this.getNotes(ds);
            const isToday = today.getFullYear() === year && today.getMonth() === month && today.getDate() === d;

            let indicators = '';
            if (hasGoals) indicators += '<span class="calendar-indicator goal-indicator"></span>';
            if (hasEvents) indicators += '<span class="calendar-indicator event-indicator"></span>';

            let notesHtml = '';
            if (dayNotes.length) {
                const maxVisible = window.innerWidth < 768 ? 2 : 3;
                const visible = dayNotes.slice(0, maxVisible);
                const rest = dayNotes.length - visible.length;
                notesHtml = `<div class="calendar-day-notes">${visible.map(n => `
                    <div class="calendar-note-chip" data-date="${ds}" data-note-id="${n.id}" title="${this.escapeHtml(n.content)}">
                        ${n.time ? `<span class="chip-time">${n.time}</span>` : '<span class="chip-dot"></span>'}
                        <span class="chip-text">${this.escapeHtml(n.content)}</span>
                    </div>`).join('')}
                    ${rest > 0 ? `<div class="calendar-note-more">+${rest} ещё</div>` : ''}
                </div>`;
            }

            html += `<div class="calendar-day calendar-day-large ${isToday?'today':''} ${dayNotes.length?'has-note':''}" data-date="${ds}">
                <span class="calendar-day-number">${d}</span>${indicators}${notesHtml}
            </div>`;
        }

        const remaining = 42 - (startDay + daysInMonth);
        for (let i = 1; i <= remaining; i++) {
            html += `<div class="calendar-day other-month calendar-day-large"><span class="calendar-day-number">${i}</span></div>`;
        }

        grid.innerHTML = html;
        // клик по чипу — редактирование записи
        grid.querySelectorAll('.calendar-note-chip').forEach(chip => {
            chip.addEventListener('click', (e) => {
                e.stopPropagation();
                this.openNoteModal(chip.dataset.date, chip.dataset.noteId);
            });
        });
        // клик по дню — новая запись
        grid.querySelectorAll('.calendar-day[data-date]').forEach(day => {
            day.addEventListener('click', () => this.openNoteModal(day.dataset.date));
        });
    }

    changeMonth(delta) { this.currentMonth.setMonth(this.currentMonth.getMonth() + delta); this.renderCalendar(); }

    // ===== Notes =====
    // Нормализация: старый формат (одна заметка на день) → массив записей
    normalizeNotes(notes) {
        const out = {};
        for (const [ds, val] of Object.entries(notes || {})) {
            if (Array.isArray(val)) {
                const list = val.filter(n => n && typeof n.content === 'string' && n.content.trim())
                    .map(n => ({ id: n.id || this.generateId(), content: n.content.trim(), time: n.time || null, createdAt: n.createdAt || new Date().toISOString(), updatedAt: n.updatedAt || n.createdAt || new Date().toISOString() }));
                if (list.length) out[ds] = list;
            } else if (val && typeof val === 'object' && typeof val.content === 'string' && val.content.trim()) {
                out[ds] = [{
                    id: this.generateId(),
                    content: val.content.trim(),
                    time: val.time || null,
                    createdAt: val.updatedAt || new Date().toISOString(),
                    updatedAt: val.updatedAt || new Date().toISOString()
                }];
            } else if (typeof val === 'string' && val.trim()) {
                out[ds] = [{ id: this.generateId(), content: val.trim(), time: null, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }];
            }
        }
        return out;
    }

    // Записи дня: без времени сверху (в порядке добавления), встречи по времени ниже
    getNotes(dateStr) {
        const list = this.notes[dateStr];
        if (!Array.isArray(list) || !list.length) return [];
        const untimed = list.filter(n => !n.time);
        const timed = list.filter(n => n.time).sort((a, b) => a.time.localeCompare(b.time));
        return [...untimed, ...timed];
    }

    openNoteModal(dateStr, noteId = null) {
        const form = document.getElementById('noteForm');
        const del = document.getElementById('deleteNoteBtn');
        const list = Array.isArray(this.notes[dateStr]) ? this.notes[dateStr] : [];
        const note = noteId ? list.find(n => n.id === noteId) : null;

        document.getElementById('noteDate').value = dateStr;
        document.getElementById('noteDateLabel').textContent =
            new Date(dateStr + 'T00:00:00').toLocaleDateString('ru-RU', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

        if (note) {
            document.getElementById('noteModalTitle').textContent = 'Редактировать запись';
            document.getElementById('noteId').value = note.id;
            document.getElementById('noteContent').value = note.content;
            document.getElementById('noteTime').value = note.time || '';
            del.style.display = 'inline-block';
        } else {
            document.getElementById('noteModalTitle').textContent = 'Новая запись';
            form.reset();
            document.getElementById('noteDate').value = dateStr;
            document.getElementById('noteId').value = '';
            del.style.display = 'none';
        }
        document.getElementById('noteModal').classList.add('active');
        setTimeout(() => document.getElementById('noteContent').focus(), 50);
    }

    saveNote(e) {
        e.preventDefault();
        const ds = document.getElementById('noteDate').value;
        const noteId = document.getElementById('noteId').value;
        const content = document.getElementById('noteContent').value.trim();
        const time = document.getElementById('noteTime').value || null;
        if (!content || !ds) return;

        if (!Array.isArray(this.notes[ds])) this.notes[ds] = [];
        const now = new Date().toISOString();

        if (noteId) {
            const note = this.notes[ds].find(n => n.id === noteId);
            if (note) { note.content = content; note.time = time; note.updatedAt = now; }
        } else {
            this.notes[ds].push({ id: this.generateId(), content, time, createdAt: now, updatedAt: now });
        }
        // чистим пустые дни
        this.notes[ds] = this.notes[ds].filter(n => n.content);
        if (!this.notes[ds].length) delete this.notes[ds];

        this.saveData(); this.closeModal('noteModal'); this.renderCalendar();
        this.showToast(noteId ? 'Запись обновлена!' : 'Запись добавлена!', 'success');
    }

    deleteNote() {
        const ds = document.getElementById('noteDate').value;
        const noteId = document.getElementById('noteId').value;
        if (!ds || !noteId || !Array.isArray(this.notes[ds])) return;
        if (!confirm('Удалить запись?')) return;
        this.notes[ds] = this.notes[ds].filter(n => n.id !== noteId);
        if (!this.notes[ds].length) delete this.notes[ds];
        this.saveData(); this.closeModal('noteModal'); this.renderCalendar(); this.showToast('Удалено', 'success');
    }

    // Напоминание о встречах сегодня (при запуске)
    checkTodayNotes() {
        if (!this.settings.notifications) return;
        const ds = new Date().toISOString().split('T')[0];
        const nowHm = `${String(new Date().getHours()).padStart(2, '0')}:${String(new Date().getMinutes()).padStart(2, '0')}`;
        const upcoming = (Array.isArray(this.notes[ds]) ? this.notes[ds] : [])
            .filter(n => n.time && n.time >= nowHm)
            .sort((a, b) => a.time.localeCompare(b.time));
        if (!upcoming.length) return;
        const list = upcoming.slice(0, 3).map(n => `${n.time} — ${n.content}`).join('; ');
        const more = upcoming.length > 3 ? ` и ещё ${upcoming.length - 3}` : '';
        this.showNotification(`Сегодня ${upcoming.length} запис(и): ${list}${more}`);
    }

    // ===== Goal Modal =====
    openGoalModal(goalId = null) {
        const parent = document.getElementById('goalParent');
        parent.innerHTML = '<option value="">Нет (корневая)</option>' +
            this.goals.filter(g => g.id !== goalId).map(g => `<option value="${g.id}">${this.escapeHtml(g.title)}</option>`).join('');

        if (goalId) {
            const g = this.goals.find(x => x.id === goalId);
            if (g) {
                document.getElementById('goalModalTitle').textContent = 'Редактировать цель';
                document.getElementById('goalId').value = g.id;
                document.getElementById('goalTitle').value = g.title;
                document.getElementById('goalDescription').value = g.description || '';
                document.getElementById('goalCategory').value = g.category;
                document.getElementById('goalPriority').value = g.priority;
                document.getElementById('goalDeadline').value = g.deadline || '';
                document.getElementById('goalParent').value = g.parentId || '';
                document.getElementById('goalTags').value = (g.tags || []).join(', ');
            }
        } else {
            document.getElementById('goalModalTitle').textContent = 'Новая цель';
            document.getElementById('goalForm').reset();
            document.getElementById('goalId').value = '';
        }
        document.getElementById('goalModal').classList.add('active');
    }

    saveGoal(e) {
        e.preventDefault();
        const id = document.getElementById('goalId').value;
        const data = {
            title: document.getElementById('goalTitle').value.trim(),
            description: document.getElementById('goalDescription').value.trim(),
            category: document.getElementById('goalCategory').value,
            priority: document.getElementById('goalPriority').value,
            deadline: document.getElementById('goalDeadline').value || null,
            parentId: document.getElementById('goalParent').value || null,
            tags: document.getElementById('goalTags').value.split(',').map(t => t.trim()).filter(Boolean),
            status: 'active', createdAt: new Date().toISOString(), subgoals: []
        };
        if (id) { const i = this.goals.findIndex(g => g.id === id); if (i !== -1) this.goals[i] = { ...this.goals[i], ...data }; }
        else { data.id = this.generateId(); this.goals.push(data); this.addXP(10, 'Новая цель'); }
        this.saveData(); this.closeModal('goalModal'); this.render(); this.showToast('Цель сохранена!', 'success');
    }

    // ===== Goal Detail =====
    openGoalDetail(goalId) {
        const goal = this.goals.find(g => g.id === goalId);
        if (!goal) return;
        const content = document.getElementById('goalDetailContent');
        document.getElementById('detailGoalTitle').textContent = goal.title;

        const progress = this.calculateProgress(goal);
        const subgoals = goal.subgoals || [];
        const achievements = this.achievements.filter(a => a.goalId === goalId);

        content.innerHTML = `
            <div class="detail-meta">
                <span class="detail-meta-item">📂 ${this.getCategoryLabel(goal.category)}</span>
                <span class="detail-meta-item"><span class="priority-badge ${this.getPriorityClass(goal.priority)}">${this.getPriorityLabel(goal.priority)}</span></span>
                ${goal.deadline ? `<span class="detail-meta-item">📅 ${new Date(goal.deadline).toLocaleDateString('ru-RU')}</span>` : ''}
                ${goal.tags?.length ? `<span class="detail-meta-item">🏷️ ${goal.tags.join(', ')}</span>` : ''}
            </div>
            ${goal.description ? `<div class="detail-section"><p>${this.escapeHtml(goal.description)}</p></div>` : ''}
            <div class="detail-section">
                <h4>Прогресс</h4>
                <div class="progress-bar"><div class="progress-fill ${progress>=100?'complete':progress>=60?'high':progress>=30?'medium':'low'}" style="width:${progress}%"></div></div>
                <div class="progress-text"><span>Выполнено</span><span>${progress}%</span></div>
            </div>
            <div class="detail-section">
                <h4>Подцели (${subgoals.length})</h4>
                <div class="subgoals-list">
                    ${subgoals.length ? subgoals.map(s => `
                        <div class="subgoal-item">
                            <input type="checkbox" class="subgoal-checkbox" data-sid="${s.id}" ${s.completed?'checked':''}>
                            <span class="subgoal-title ${s.completed?'completed':''}">${this.escapeHtml(s.title)}</span>
                            <div class="subgoal-actions">
                                <button class="btn-icon btn-edit-subgoal" data-sid="${s.id}">✏️</button>
                                <button class="btn-icon btn-delete-subgoal" data-sid="${s.id}">🗑️</button>
                            </div>
                        </div>
                    `).join('') : '<p style="color:var(--text-secondary)">Нет подцелей</p>'}
                </div>
            </div>
            <div class="detail-section">
                <h4>Достижения (${achievements.length})</h4>
                <div class="achievements-list">
                    ${achievements.length ? achievements.map(a => `
                        <div class="achievement-item">
                            <span class="achievement-icon">🏆</span>
                            <div class="achievement-info">
                                <div class="achievement-title">${a.protected?'🔒':''} ${this.escapeHtml(a.title)}</div>
                                <div class="achievement-date">${new Date(a.date).toLocaleDateString('ru-RU')}</div>
                            </div>
                            <div class="achievement-actions">
                                ${!a.protected ? `<button class="btn-icon btn-edit-achievement" data-id="${a.id}">✏️</button><button class="btn-icon btn-delete-achievement" data-id="${a.id}">🗑️</button>` : ''}
                            </div>
                        </div>
                    `).join('') : '<p style="color:var(--text-secondary)">Нет достижений</p>'}
                </div>
            </div>
            <div class="modal-actions">
                <button class="btn btn-danger" id="deleteGoalBtn">🗑️ Удалить</button>
                <button class="btn btn-secondary" id="editGoalBtn">✏️ Редактировать</button>
                <button class="btn btn-primary" id="addSubgoalBtn">+ Подцель</button>
                <button class="btn btn-primary" id="completeGoalBtn">${goal.status==='completed'?'↩️ Вернуть':'✅ Завершить'}</button>
            </div>
        `;

        document.getElementById('editGoalBtn').addEventListener('click', () => { this.closeModal('goalDetailModal'); this.openGoalModal(goalId); });
        document.getElementById('addSubgoalBtn').addEventListener('click', () => this.addSubgoal(goalId));
        document.getElementById('completeGoalBtn').addEventListener('click', () => this.toggleGoalStatus(goalId));
        document.getElementById('deleteGoalBtn').addEventListener('click', () => this.deleteGoal(goalId));

        content.querySelectorAll('.subgoal-checkbox').forEach(cb => cb.addEventListener('change', (e) => this.toggleSubgoal(goalId, e.target.dataset.sid, e.target.checked)));
        content.querySelectorAll('.btn-edit-subgoal').forEach(b => b.addEventListener('click', (e) => { e.stopPropagation(); this.editSubgoal(goalId, b.dataset.sid); }));
        content.querySelectorAll('.btn-delete-subgoal').forEach(b => b.addEventListener('click', (e) => { e.stopPropagation(); this.deleteSubgoal(goalId, b.dataset.sid); }));
        content.querySelectorAll('.btn-edit-achievement').forEach(b => b.addEventListener('click', (e) => { e.stopPropagation(); this.editAchievement(b.dataset.id); }));
        content.querySelectorAll('.btn-delete-achievement').forEach(b => b.addEventListener('click', (e) => { e.stopPropagation(); this.deleteAchievement(b.dataset.id); }));

        document.getElementById('goalDetailModal').classList.add('active');
    }

    addSubgoal(goalId) {
        const title = prompt('Название подцели:');
        if (!title?.trim()) return;
        const goal = this.goals.find(g => g.id === goalId);
        if (!goal) return;
        if (!goal.subgoals) goal.subgoals = [];
        goal.subgoals.push({ id: this.generateId(), title: title.trim(), completed: false });
        this.saveData(); this.openGoalDetail(goalId); this.render(); this.showToast('Подцель добавлена!', 'success');
    }

    editSubgoal(goalId, sid) {
        const goal = this.goals.find(g => g.id === goalId);
        const sub = goal?.subgoals?.find(s => s.id === sid);
        if (!sub) return;
        const t = prompt('Редактировать:', sub.title);
        if (!t?.trim()) return;
        sub.title = t.trim();
        this.saveData(); this.openGoalDetail(goalId); this.render();
    }

    deleteSubgoal(goalId, sid) {
        if (!confirm('Удалить подцель?')) return;
        const goal = this.goals.find(g => g.id === goalId);
        if (!goal?.subgoals) return;
        goal.subgoals = goal.subgoals.filter(s => s.id !== sid);
        this.saveData(); this.openGoalDetail(goalId); this.render();
    }

    toggleSubgoal(goalId, sid, completed) {
        const goal = this.goals.find(g => g.id === goalId);
        const sub = goal?.subgoals?.find(s => s.id === sid);
        if (sub) { sub.completed = completed; if (completed) this.addXP(5, 'Подцель'); this.saveData(); this.render(); }
    }

    toggleGoalStatus(goalId) {
        const goal = this.goals.find(g => g.id === goalId);
        if (!goal) return;
        goal.status = goal.status === 'completed' ? 'active' : 'completed';
        if (goal.status === 'completed') {
            this.addXP(50, `Цель "${goal.title}"`);
            this.checkBadges();
            this.achievements.push({
                id: this.generateId(), goalId: goal.id,
                title: `Завершена цель: ${goal.title}`, description: goal.description || '',
                date: new Date().toISOString().split('T')[0], progress: 100,
                protected: true, autoCreated: true, createdAt: new Date().toISOString()
            });
            this.showToast('🏆 Цель стала достижением!', 'success');
        }
        this.saveData(); this.closeModal('goalDetailModal'); this.render();
        this.showToast(goal.status === 'completed' ? 'Цель завершена! 🎉' : 'Цель возвращена', 'success');
    }

    deleteGoal(goalId) {
        if (!confirm('Удалить цель? Подцели и достижения тоже.')) return;
        this.goals = this.goals.filter(g => g.id !== goalId);
        this.achievements = this.achievements.filter(a => a.goalId !== goalId);
        this.goals.forEach(g => { if (g.parentId === goalId) g.parentId = null; });
        this.saveData(); this.closeModal('goalDetailModal'); this.render(); this.showToast('Цель удалена', 'success');
    }

    // ===== Achievement Modal =====
    openAchievementModal(achievementId = null) {
        const goalSel = document.getElementById('achievementGoal');
        goalSel.innerHTML = this.goals.map(g => `<option value="${g.id}">${this.escapeHtml(g.title)}</option>`).join('');

        if (achievementId) {
            const a = this.achievements.find(x => x.id === achievementId);
            if (a) {
                document.getElementById('achievementId').value = a.id;
                document.getElementById('achievementGoal').value = a.goalId;
                document.getElementById('achievementTitle').value = a.title;
                document.getElementById('achievementDescription').value = a.description || '';
                document.getElementById('achievementDate').value = a.date;
                document.getElementById('achievementProgress').value = a.progress || 0;
                document.getElementById('achievementProtected').checked = a.protected || false;
            }
        } else {
            document.getElementById('achievementForm').reset();
            document.getElementById('achievementId').value = '';
            document.getElementById('achievementDate').value = new Date().toISOString().split('T')[0];
        }
        document.getElementById('achievementModal').classList.add('active');
    }

    saveAchievement(e) {
        e.preventDefault();
        const id = document.getElementById('achievementId').value;
        const data = {
            goalId: document.getElementById('achievementGoal').value,
            title: document.getElementById('achievementTitle').value.trim(),
            description: document.getElementById('achievementDescription').value.trim(),
            date: document.getElementById('achievementDate').value,
            progress: parseInt(document.getElementById('achievementProgress').value) || 0,
            protected: document.getElementById('achievementProtected').checked
        };
        if (id) { const i = this.achievements.findIndex(a => a.id === id); if (i !== -1) this.achievements[i] = { ...this.achievements[i], ...data }; }
        else {
            data.id = this.generateId(); data.createdAt = new Date().toISOString();
            this.achievements.push(data); this.addXP(20, 'Достижение'); this.updateStreak(); this.checkBadges();
        }
        this.saveData(); this.closeModal('achievementModal'); this.render(); this.showToast('Сохранено! 🏆', 'success');
    }

    editAchievement(id) { this.closeModal('goalDetailModal'); this.openAchievementModal(id); }

    deleteAchievement(id) {
        const a = this.achievements.find(x => x.id === id);
        if (!a) return;
        if (a.protected) { this.showToast('Защищённое достижение!', 'error'); return; }
        if (!confirm('Удалить достижение?')) return;
        this.achievements = this.achievements.filter(x => x.id !== id);
        this.saveData(); this.render(); this.showToast('Удалено', 'success');
    }

    // ===== Settings =====
    openSettingsModal() {
        document.getElementById('notificationsEnabled').checked = this.settings.notifications;
        document.getElementById('reminderDays').value = this.settings.reminderDays;
        document.getElementById('gamificationEnabled').checked = this.settings.gamification;
        document.getElementById('autoSyncEnabled').checked = !!this.settings.autoSync;
        
        const hasSyncUrl = !!this.settings.syncUrl;
        document.getElementById('syncUrlInput').value = this.settings.syncUrl || '';
        document.getElementById('syncUrlGroup').style.display = hasSyncUrl ? 'block' : 'none';
        document.getElementById('syncStatusText').textContent = this.updatedAt
            ? 'Последняя синхронизация: ' + new Date(this.updatedAt).toLocaleString('ru-RU')
            : (hasSyncUrl ? 'Пока только локально' : 'Автономный режим (без сервера)');
        
        document.querySelectorAll('.theme-btn').forEach(b => b.classList.toggle('active', b.dataset.theme === this.settings.theme));
        document.getElementById('settingsModal').classList.add('active');
    }

    // ===== Theme =====
    initTheme() { this.setTheme(this.settings.theme); }

    setTheme(theme) {
        this.settings.theme = theme;
        if (theme === 'auto') {
            document.documentElement.setAttribute('data-theme', window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
        } else {
            document.documentElement.setAttribute('data-theme', theme);
        }
        document.querySelectorAll('.theme-btn').forEach(b => b.classList.toggle('active', b.dataset.theme === theme));
        this.saveData();
    }

    toggleTheme() {
        const cur = document.documentElement.getAttribute('data-theme');
        this.setTheme(cur === 'dark' ? 'light' : 'dark');
    }

    // ===== Gamification =====
    addXP(amount) {
        if (!this.settings.gamification) return;
        this.gamification.xp += amount;
        const newLevel = Math.floor(this.gamification.xp / 100) + 1;
        if (newLevel > this.gamification.level) {
            this.gamification.level = newLevel;
            this.showToast(`🎉 Новый уровень: ${newLevel}!`, 'success');
            this.addBadge('level_up', 'Повелитель уровней');
        }
        this.saveData();
    }

    updateStreak() {
        const today = new Date().toISOString().split('T')[0];
        const last = this.gamification.lastActiveDate;
        if (last === today) return;
        const yest = new Date(); yest.setDate(yest.getDate() - 1);
        if (last === yest.toISOString().split('T')[0]) this.gamification.streak++;
        else this.gamification.streak = 1;
        this.gamification.lastActiveDate = today;
        this.saveData();
    }

    checkBadges() {
        const done = this.goals.filter(g => g.status === 'completed').length;
        const ach = this.achievements.length;
        if (done >= 1 && !this.hasBadge('first')) this.addBadge('first', 'Первый шаг');
        if (done >= 5 && !this.hasBadge('five')) this.addBadge('five', 'На верном пути');
        if (done >= 10 && !this.hasBadge('ten')) this.addBadge('ten', 'Мастер целей');
        if (ach >= 10 && !this.hasBadge('ten_ach')) this.addBadge('ten_ach', 'Продуктивный');
        if (this.gamification.streak >= 7 && !this.hasBadge('week')) this.addBadge('week', 'Неделя огня');
    }

    hasBadge(id) { return this.gamification.badges.some(b => b.id === id); }

    addBadge(id, title) {
        this.gamification.badges.push({ id, title, earnedAt: new Date().toISOString() });
        this.showToast(`🏅 Значок: ${title}!`, 'success');
        this.saveData();
    }

    // ===== Stats (in Profile) =====
    renderCategoryStats() {
        const container = document.getElementById('categoryStats');
        if (!container) return;
        const cats = {};
        this.goals.forEach(g => {
            if (!cats[g.category]) cats[g.category] = { total: 0, completed: 0, progress: 0 };
            cats[g.category].total++;
            if (g.status === 'completed') cats[g.category].completed++;
            cats[g.category].progress += this.calculateProgress(g);
        });
        const colors = ['#6366f1','#22c55e','#f59e0b','#ef4444','#3b82f6','#8b5cf6','#ec4899'];
        let html = ''; let i = 0;
        for (const [cat, data] of Object.entries(cats)) {
            const avg = data.total > 0 ? Math.round(data.progress / data.total) : 0;
            html += `
                <div class="category-stat">
                    <div class="category-stat-header"><span>${this.getCategoryLabel(cat)}</span><span>${data.completed}/${data.total} • ${avg}%</span></div>
                    <div class="category-stat-bar"><div class="category-stat-fill" style="width:${avg}%;background:${colors[i%colors.length]}"></div></div>
                </div>`;
            i++;
        }
        container.innerHTML = html || '<p style="color:var(--text-secondary)">Нет данных</p>';
    }

    renderWeeklyActivity() {
        const container = document.getElementById('weeklyActivity');
        if (!container) return;
        const days = ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'];
        const today = new Date();
        const week = [];
        for (let i = 6; i >= 0; i--) {
            const d = new Date(today); d.setDate(d.getDate() - i);
            const ds = d.toISOString().split('T')[0];
            week.push({ day: days[d.getDay()], count: this.achievements.filter(a => a.date === ds).length });
        }
        const max = Math.max(...week.map(w => w.count), 1);
        container.innerHTML = week.map(w => `
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;">
                <span style="width:30px;font-size:0.85rem;color:var(--text-secondary)">${w.day}</span>
                <div style="flex:1;height:20px;background:var(--border);border-radius:4px;overflow:hidden;">
                    <div style="width:${(w.count/max)*100}%;height:100%;background:var(--primary);border-radius:4px;transition:width .3s;"></div>
                </div>
                <span style="width:20px;text-align:right;font-size:0.85rem">${w.count}</span>
            </div>
        `).join('');
    }

    // ===== Sync =====
    async syncData(silent = false) {
        const base = this.getSyncBase();
        
        // Автономный режим — синхронизация не настроена
        if (!base) {
            if (!silent) this.showToast('📴 Автономный режим: синхронизация отключена', 'info');
            return false;
        }

        if (!silent) this.showToast('Синхронизация...', 'info');

        try {
            // 1. Получаем данные сервера
            let remote = null;
            let r = null;
            try {
                r = await this.apiFetch(base, { cache: 'no-store' });
            } catch { r = null; }
            if (r && r.status === 401) {
                this.showPinModal('Неверный код доступа — введите заново');
                return false;
            }
            if (r && r.ok) remote = await r.json();

            // Нет профиля — можно только забрать данные (автовход на новом устройстве)
            if (!this.user) {
                if (remote && remote.updatedAt) {
                    this.applyRemote(remote);
                    this.afterRemoteUpdate();
                    if (!silent) this.showToast('📥 Профиль получен с сервера', 'success');
                } else if (!silent) {
                    this.showToast('ℹ️ Нет профиля для отправки', 'info');
                }
                return this.user;
            }

            const neverSynced = !this.updatedAt;
            const remoteNewer = !!(remote && remote.updatedAt && this.updatedAt && remote.updatedAt > this.updatedAt);

            // Сервер новее, а локально ничего не меняли — чистое обновление
            if (remoteNewer && !this._dirty) {
                this.applyRemote(remote);
                this.afterRemoteUpdate();
                if (!silent) this.showToast('📥 Данные обновлены с сервера', 'success');
                return true;
            }

            // Локальных изменений нет и сервер актуален — отправлять нечего
            if (!this._dirty && remote && remote.updatedAt && !neverSynced) {
                if (!silent) this.showToast('🔄 Данные уже актуальны', 'success');
                return true;
            }

            // 2. Отправляем локальные данные (merge при первом подключении или одновременных правках)
            let payload = this.serialize();
            payload.updatedAt = new Date().toISOString();
            payload.baseUpdatedAt = (remote && remote.updatedAt) || this.updatedAt || null;
            if (remote && remote.updatedAt && (neverSynced || (remoteNewer && this._dirty))) {
                payload = this.mergeData(remote, payload);
            }

            const doPush = () => this.apiFetch(base, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const resp = await doPush();

            if (resp.status === 401) {
                this.showPinModal('Неверный код доступа — введите заново');
                return false;
            }
            if (resp.status === 409) {
                // Конфликт: сервер ушёл вперёд, пока мы правили — объединяем и повторяем
                const conflict = await resp.json();
                if (conflict.server) {
                    if (this._dirty) {
                        payload = this.mergeData(conflict.server, payload);
                        payload.updatedAt = new Date().toISOString();
                        payload.baseUpdatedAt = conflict.server.updatedAt;
                        const retry = await doPush();
                        if (!retry.ok) throw new Error('HTTP ' + retry.status);
                    } else {
                        this.applyRemote(conflict.server);
                        this.afterRemoteUpdate();
                        if (!silent) this.showToast('📥 Данные обновлены с сервера', 'success');
                        return true;
                    }
                }
            } else if (!resp.ok) {
                throw new Error('HTTP ' + resp.status);
            }

            this.updatedAt = payload.updatedAt;
            this._dirty = false;
            delete payload.baseUpdatedAt;
            // Синхронизируем память с отправленным (важно после merge — иначе
            // следующий push затёрл бы чужие данные нашей старой копией)
            this.applyRemote(payload);
            this.render();
            if (!silent) this.showToast('📤 Данные синхронизированы', 'success');
            return true;
        } catch (e) {
            console.warn('Sync failed:', e);
            if (!silent) this.showToast('⚠️ Ошибка синхронизации — данные остаются локально', 'error');
            return false;
        }
    }

    // Объединение данных нового устройства с серверными (первое подключение)
    mergeData(remote, local) {
        const byId = arr => new Map(arr.map(x => [x.id, x]));
        const union = (a, b) => {
            const map = byId(a);
            b.forEach(x => { if (!map.has(x.id)) map.set(x.id, x); });
            return [...map.values()];
        };
        const merged = { ...local };
        merged.user = local.user || remote.user;
        merged.goals = union(remote.goals || [], local.goals || []);
        merged.achievements = union(remote.achievements || [], local.achievements || []);
        merged.habits = union(remote.habits || [], local.habits || []);
        merged.events = union(remote.events || [], local.events || []);
        // Записи календаря: по дням, объединение по id
        const rn = this.normalizeNotes(remote.notes || {});
        const ln = this.normalizeNotes(local.notes || {});
        merged.notes = {};
        for (const day of new Set([...Object.keys(rn), ...Object.keys(ln)])) {
            if (rn[day] && ln[day]) {
                const map = new Map(rn[day].map(n => [n.id, n]));
                ln[day].forEach(n => map.set(n.id, n));
                merged.notes[day] = [...map.values()];
            } else {
                merged.notes[day] = ln[day] || rn[day];
            }
        }
        // Геймификация — берём лучшие показатели
        const rg = remote.gamification || {};
        const lg = local.gamification || {};
        merged.gamification = {
            ...lg,
            xp: Math.max(lg.xp || 0, rg.xp || 0),
            level: Math.max(lg.level || 1, rg.level || 1),
            streak: Math.max(lg.streak || 0, rg.streak || 0),
            badges: union(rg.badges || [], lg.badges || [])
        };
        return merged;
    }

    // ===== Export/Import =====
    exportData() {
        const data = { user: this.user, goals: this.goals, achievements: this.achievements, habits: this.habits, events: this.events, notes: this.notes, settings: this.settings, gamification: this.gamification, exportDate: new Date().toISOString() };
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a'); a.href = url; a.download = `goaltracker-${new Date().toISOString().split('T')[0]}.json`; a.click();
        URL.revokeObjectURL(url);
        this.showToast('Экспортировано!', 'success');
    }

    exportCSV() {
        const headers = ['Цель','Категория','Приоритет','Статус','Прогресс','Дедлайн'];
        const rows = this.goals.map(g => [g.title, this.getCategoryLabel(g.category), this.getPriorityLabel(g.priority), g.status === 'completed' ? 'Готово' : 'Активна', this.calculateProgress(g)+'%', g.deadline || '']);
        const csv = [headers, ...rows].map(r => r.map(c => `"${c}"`).join(',')).join('\n');
        const blob = new Blob(['\ufeff'+csv], { type: 'text/csv;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a'); a.href = url; a.download = `goaltracker.csv`; a.click();
        URL.revokeObjectURL(url);
        this.showToast('CSV экспортирован!', 'success');
    }

    exportPDF() {
        const w = window.open('', '_blank');
        w.document.write(`<html><head><title>GoalTracker</title><style>body{font-family:Arial;padding:20px}h1{color:#6366f1}table{width:100%;border-collapse:collapse;margin-top:10px}th,td{border:1px solid #ddd;padding:8px;text-align:left}th{background:#6366f1;color:#fff}</style></head><body><h1>GoalTracker Pro — Отчёт</h1><p>${new Date().toLocaleDateString('ru-RU')}</p><h2>Цели (${this.goals.length})</h2><table><tr><th>Цель</th><th>Категория</th><th>Статус</th><th>Прогресс</th></tr>${this.goals.map(g => `<tr><td>${this.escapeHtml(g.title)}</td><td>${this.getCategoryLabel(g.category)}</td><td>${g.status==='completed'?'Готово':'Активна'}</td><td>${this.calculateProgress(g)}%</td></tr>`).join('')}</table></body></html>`);
        w.document.close(); w.print();
        this.showToast('PDF готов!', 'success');
    }

    importData() {
        const input = document.createElement('input'); input.type = 'file'; input.accept = '.json';
        input.onchange = (e) => {
            const file = e.target.files[0]; if (!file) return;
            const reader = new FileReader();
            reader.onload = (ev) => {
                try {
                    const data = JSON.parse(ev.target.result);
                    if (data.user) this.user = data.user;
                    if (data.goals) this.goals = data.goals;
                    if (data.achievements) this.achievements = data.achievements;
                    if (data.habits) this.habits = data.habits;
                    if (data.events) this.events = data.events;
                    if (data.notes) this.notes = this.normalizeNotes(data.notes);
                    if (data.settings) this.settings = { ...this.settings, ...data.settings };
                    if (data.gamification) this.gamification = { ...this.gamification, ...data.gamification };
                    this.saveData(); this.render(); this.showToast('Импортировано!', 'success');
                } catch (err) { this.showToast('Ошибка файла', 'error'); }
            };
            reader.readAsText(file);
        };
        input.click();
    }

    // ===== Notifications =====
    checkDeadlines() {
        if (!this.settings.notifications) return;
        const now = new Date();
        const remind = new Date(); remind.setDate(remind.getDate() + this.settings.reminderDays);
        this.goals.forEach(g => {
            if (g.deadline && g.status === 'active') {
                const dl = new Date(g.deadline);
                if (dl <= remind && dl >= now) this.showNotification(`Дедлайн: "${g.title}" приближается!`);
            }
        });
    }

    showNotification(message) {
        if (window.electronAPI?.showNotification) {
            window.electronAPI.showNotification('GoalTracker Pro', message);
        } else if ('Notification' in window && Notification.permission === 'granted') {
            new Notification('GoalTracker Pro', { body: message });
        }
        this.showToast(message, 'info');
    }

    // ===== Utilities =====
    generateId() { return Date.now().toString(36) + Math.random().toString(36).substr(2); }

    calculateProgress(goal) {
        if (goal.status === 'completed') return 100;
        const subs = goal.subgoals || [];
        if (!subs.length) return 0;
        return Math.round((subs.filter(s => s.completed).length / subs.length) * 100);
    }

    getDaysLeft(deadline) {
        const now = new Date(); now.setHours(0,0,0,0);
        const dl = new Date(deadline); dl.setHours(0,0,0,0);
        return Math.ceil((dl - now) / 86400000);
    }

    getCategoryLabel(c) { return { personal:'Личное',career:'Карьера',health:'Здоровье',finance:'Финансы',education:'Образование',hobby:'Хобби',other:'Другое' }[c] || c; }
    getPriorityLabel(p) { return { low:'Низкий',medium:'Средний',high:'Высокий',critical:'Критический' }[p] || p; }
    getPriorityClass(p) { return { low:'priority-low',medium:'priority-medium',high:'priority-high',critical:'priority-critical' }[p] || 'priority-medium'; }

    escapeHtml(t) { if (!t) return ''; const d = document.createElement('div'); d.textContent = t; return d.innerHTML; }
    closeModal(id) { document.getElementById(id).classList.remove('active'); }

    showToast(message, type = 'info') {
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;
        container.appendChild(toast);
        setTimeout(() => toast.remove(), 3000);
    }

    // ===== PWA Install =====
    showInstallButton() {
        // Кнопка установки появится в профиле или в настройках
        const existing = document.getElementById('installPwaBtn');
        if (existing) existing.style.display = 'inline-block';
    }

    hideInstallButton() {
        const existing = document.getElementById('installPwaBtn');
        if (existing) existing.style.display = 'none';
    }

    async installPWA() {
        if (!this.deferredPrompt) {
            this.showToast('Установка недоступна (уже установлено или браузер не поддерживает)', 'info');
            return;
        }
        this.deferredPrompt.prompt();
        const { outcome } = await this.deferredPrompt.userChoice;
        if (outcome === 'accepted') {
            this.showToast('Установка запущена...', 'success');
        }
        this.deferredPrompt = null;
        this.hideInstallButton();
    }

    // ===== OTA Updates (Live Updates) =====
    async checkForUpdates() {
        // Только в нативном Capacitor приложении
        if (!window.Capacitor?.isNativePlatform()) return;

        try {
            const { Updater } = await import('@capgo/capacitor-updater');
            
            // Настройка URL обновлений (из конфигурации или дефолтный)
            const updateUrl = 'https://goaltracker-pro.sayonara778.workers.dev';
            
            // Проверяем наличие обновлений
            const update = await Updater.checkForUpdate({
                url: updateUrl
            });

            if (update?.available) {
                this.showToast('🔄 Найдено обновление, загружаем...', 'info');
                
                // Скачиваем обновление в фоне
                await Updater.downloadUpdate({
                    url: updateUrl,
                    progress: (prog) => {
                        console.log('[OTA] Download progress:', prog);
                    }
                });

                // Устанавливаем обновление (применяется при следующем запуске)
                await Updater.setUpdate();
                
                this.showToast('✅ Обновление загружено! Перезапустите приложение.', 'success');
                
                // Показываем кнопку перезапуска
                this.showRestartButton();
            } else {
                console.log('[OTA] No updates available');
            }
        } catch (err) {
            // Офлайн или ошибка — тихо игнорируем, приложение работает с текущей версией
            console.log('[OTA] Update check skipped (offline or error):', err?.message);
        }
    }

    showRestartButton() {
        // Добавляем кнопку перезапуска в настройки или на дашборд
        const existing = document.getElementById('restartAppBtn');
        if (existing) {
            existing.style.display = 'inline-block';
            return;
        }
        
        // Создаем кнопку динамически
        const btn = document.createElement('button');
        btn.id = 'restartAppBtn';
        btn.className = 'btn btn-warning';
        btn.textContent = '🔄 Перезапустить для обновления';
        btn.style.marginTop = '8px';
        btn.onclick = () => this.restartApp();
        
        // Добавляем в настройки или на дашборд
        const container = document.getElementById('profileContent') || document.getElementById('view-dashboard');
        if (container) {
            container.insertBefore(btn, container.firstChild);
        }
    }

    async restartApp() {
        if (window.Capacitor?.isNativePlatform()) {
            try {
                const { App } = await import('@capacitor/app');
                await App.exitApp();
            } catch (e) {
                location.reload();
            }
        } else {
            location.reload();
        }
    }
}

// ===== Initialize =====
document.addEventListener('DOMContentLoaded', () => {
    // защита от двойной инициализации (window.app может быть DOM-элементом id="app")
    if (window.app instanceof GoalTracker) return;
    window.app = new GoalTracker();
    if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
    }
});
