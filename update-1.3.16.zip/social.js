/* Friends and private conversations use the existing SDK session, never copied tokens. */
(() => {
    'use strict';
    const $ = id => document.getElementById(id);
    const escape = value => String(value ?? '').replace(/[&<>"']/g, char => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[char]));
    const messages = {
        invalid_input:'Введите Player Tag: # и 6–8 латинских букв или цифр.',
        rate_limited:'Слишком много попыток. Подождите минуту и повторите.',
        request_sent:'Заявка отправлена.', request_exists:'Заявка уже существует. Дождитесь ответа или откройте входящие заявки.',
        already_friends:'Вы уже друзья.', self_request:'Нельзя отправить заявку самому себе.',
        request_cooldown:'Заявка отклонена. Повторная заявка доступна через 24 часа.', not_found:'Пользователь не найден. Проверьте Player Tag.'
    };
    function errorMessage(error, feature = 'friends') {
        if (feature === 'search') return navigator.onLine === false ? 'Нет сети. Повторите после подключения.' : 'Не удалось выполнить поиск. Проверьте соединение и повторите попытку.';
        if (['PGRST202','PGRST204','42883','42703','42P01'].includes(error?.code)) return 'Серверные функции списка друзей или чата ещё не настроены в Supabase.';
        if (['42501','PGRST301','PGRST302'].includes(error?.code)) return 'Нет доступа к друзьям. Войдите в аккаунт; если ошибка повторится, проверьте права Supabase.';
        return navigator.onLine === false ? 'Нет сети. Повторите после подключения.' : 'Сервис друзей недоступен. Проверьте подключение Supabase и повторите попытку.';
    }
    const playerTag = value => { const tag = '#' + String(value || '').trim().replace(/^#/, '').toUpperCase(); return /^#[A-Z0-9]{6,8}$/.test(tag) ? tag : ''; };
    const schemaFailure = error => [400,404].includes(error?.httpStatus) || ['42703','42P01','PGRST100','PGRST200','PGRST202','PGRST204','PGRST205','42883','22P02'].includes(error?.code);
    const messageTime = row => {
        const date=new Date(row.created_at);
        if(Number.isNaN(date.getTime()))return '';
        const fraction=String(row.created_at).match(/\.(\d+)(?:Z|[+-]\d{2}:?\d{2})$/)?.[1] || '';
        return date.toISOString().slice(0,19)+'.'+fraction.padEnd(9,'0');
    };
    const compareMessages = (a,b) => {
        const left=messageTime(a),right=messageTime(b);
        return left<right?-1:left>right?1:String(a.id||'')<String(b.id||'')?-1:String(a.id||'')>String(b.id||'')?1:0;
    };
    const uuid = value => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);
    class SocialView {
        constructor() {
            this.connection = null; this.generation = 0; this.chatVersion = 0; this.refreshVersion = 0;
            this.friends = []; this.latest = new Map(); this.messages = new Map(); this.drafts = new Map();
            this.requestStates = new Map(); this.retries = new Map(); this.sending = new Set(); this.peer = null; this.tab = 'friends'; this.opened = false;
            this.people = new Map(); this.refreshBlocked=false; this.messagesBlocked=false;
            this.bind();
        }
        clearAccount() {
            this.generation++; this.authSubscription?.unsubscribe(); this.authSubscription = null; this.authClient = null; clearInterval(this.poll); clearTimeout(this.friendTimer);
            if (this.channel && this.connection?.client) Promise.resolve(this.connection.client.removeChannel(this.channel)).catch(() => {});
            this.channel = null; this.connection = null; this.peer = null; this.profileVersion = (this.profileVersion || 0) + 1; this.searchVersion = (this.searchVersion || 0) + 1;
            this.friends = []; this.searchResults = null; this.searchCursor = null;
            for (const map of [this.latest,this.messages,this.drafts,this.retries,this.sending,this.requestStates]) map.clear();
            for (const id of ['socialRequests','socialFriends','socialOutgoing','socialSearchResults','socialDialogs','socialMessages','socialProfileContent']) $(id)?.replaceChildren();
            for (const id of ['socialMessage','socialNickname']) if ($(id)) $(id).value = '';
            $('socialProfile').close?.(); $('socialChatLayout').classList.remove('has-chat'); $('socialChatTitle').textContent = 'Выберите друга';
            $('socialContent').hidden = true; $('socialLogin').hidden = false;
            $('socialMyPlayerTag').textContent = 'Войдите в аккаунт';
            $('socialCopyPlayerTag').disabled = true;
            this.verifiedTag = null; this.tagBusy = false; this.tagReadFailed=false; this.awaitingFreshTag=false; this.people.clear(); this.refreshBlocked=false; this.messagesBlocked=false; this.paintPlayerTag(null);
        }
        status(text) { $('socialStatus').textContent = text; }
        current(generation) { return generation === this.generation && !!this.connection; }
        async result(query, generation = this.generation) {
            const response = await query;
            if (!this.current(generation)) throw new Error('session_changed');
            if (response.error) throw Object.assign(new Error(response.error.message || 'Request failed'),response.error,{httpStatus:response.status});
            return response.data;
        }
        fail(error, generation = this.generation, feature = 'friends') {
            if (!this.current(generation) || error?.message === 'session_changed') return;
            this.status(errorMessage(error, feature));
        }
        render() { this.opened = true; this.connect(); this.loadPlayerTag(); }
        watchAuth() {
            const client = window.CloudSync?.authClient?.();
            if (!client || this.authClient === client) return;
            this.authSubscription?.unsubscribe();
            this.authClient = client;
            // Keep SDK callbacks synchronous: cloud ownership is accepted outside
            // the SDK auth lock before the deferred view refresh runs.
            this.authSubscription = client.auth.onAuthStateChange(() => {
                setTimeout(() => this.connect(), 0);
            }).data.subscription;
        }
        connect() {
            this.watchAuth();
            const state = window.CloudSync?.connectionState?.();
            const next = window.CloudSync?.socialConnection();
            this.paintPlayerTag(next);
            if ($('socialSessionState')) $('socialSessionState').textContent = next ? '' : state?.text || '';
            if ($('socialBindProfile')) $('socialBindProfile').hidden = !!next || !state?.needsBinding;
            $('socialContent').hidden = !next; $('socialLogin').hidden = !!next;
            if (next && this.connection?.identity === next.identity && this.connection.client === next.client) { this.connection = next; return; }
            if (!next && !this.connection) {
                $('socialContent').hidden = true; $('socialLogin').hidden = false;
                this.status(state?.text || (window.CloudSync?.configured?.() ? 'Войдите в облачный аккаунт и привяжите профиль, чтобы добавлять друзей и общаться.' : 'Supabase не подключён. Откройте настройки облачного аккаунта.')); return;
            }
            const old = this.connection;
            this.generation++; this.chatVersion++; this.refreshVersion++;
            clearInterval(this.poll); clearTimeout(this.friendTimer);
            if (old && this.channel) Promise.resolve(old.client.removeChannel(this.channel)).catch(() => {});
            this.verifiedTag = null; this.tagBusy = false; this.tagReadFailed=false; this.awaitingFreshTag=false; this.people.clear(); this.refreshBlocked=false; this.messagesBlocked=false;
            this.channel = null; this.connection = next; this.peer = null; this.profileVersion = (this.profileVersion || 0) + 1;
            this.requestStates.clear(); this.searchCursor = null; this.searchResults = null; this.searchVersion = (this.searchVersion || 0) + 1;
            this.friends = []; this.latest.clear(); this.messages.clear(); this.drafts.clear(); this.retries.clear(); this.sending.clear();
            for (const id of ['socialRequests','socialFriends','socialOutgoing','socialSearchResults','socialDialogs','socialMessages','socialProfileContent']) $(id).replaceChildren();
            $('socialMessage').value = ''; $('socialNickname').value = ''; $('socialProfile').close?.();
            $('socialChatLayout').classList.remove('has-chat'); $('socialChatTitle').textContent = 'Выберите друга';
            $('socialMessage').disabled = true; $('socialSend').disabled = true; $('socialOlder').hidden = true;
            $('socialContent').hidden = !next; $('socialLogin').hidden = !!next;
            if (!next) { this.status('Войдите в облачный аккаунт, чтобы открыть друзей.'); return; }
            const generation = this.generation, me = next.userId;
            this.status('Загрузка друзей…');
            const message = payload => { if (this.current(generation)) this.receive(payload.new); };
            const friendship = () => {
                clearTimeout(this.friendTimer);
                this.friendTimer = setTimeout(() => { if (this.current(generation)) this.refresh(); }, 80);
            };
            this.channel = next.client.channel('messages')
                .on('postgres_changes', { event:'INSERT', schema:'public', table:'messages', filter:`recipient_id=eq.${me}` }, message)
                .on('postgres_changes', { event:'INSERT', schema:'public', table:'messages', filter:`sender_id=eq.${me}` }, message)
                .on('postgres_changes', { event:'*', schema:'public', table:'friendships', filter:`recipient_id=eq.${me}` }, friendship)
                .on('postgres_changes', { event:'*', schema:'public', table:'friendships', filter:`requester_id=eq.${me}` }, friendship)
                .on('postgres_changes', { event:'UPDATE', schema:'public', table:'profiles', filter:`id=eq.${me}` }, payload=>{
                    if(!this.current(generation))return;
                    const row=payload.new;
                    if(row?.id && row.id!==me)return;
                    if(row?.id===me && Object.prototype.hasOwnProperty.call(row,'short_id')) {
                        this.tagEpoch=(this.tagEpoch||0)+1;
                        const tag=playerTag(row.short_id)||null;
                        this.awaitingFreshTag=false;this.tagReadFailed=false;
                        this.verifiedTag={identity:this.connection.identity,client:this.connection.client,shortId:tag};
                        this.connection.shortId=tag;
                        window.CloudSync?.rememberPlayerTag?.(me,tag,this.connection.client);
                        this.paintPlayerTag();
                        $('socialPlayerTagStatus').textContent='';
                    } else this.loadPlayerTag();
                })
                .subscribe(state => {
                    if (!this.current(generation)) return;
                    if (state === 'SUBSCRIBED') { this.status('Друзья и сообщения обновляются в реальном времени.'); this.refresh(); if (this.peer) this.loadMessages(); }
                    else if (['CHANNEL_ERROR','TIMED_OUT','CLOSED'].includes(state)) this.status('Связь с чатом восстанавливается. Доступно ручное обновление.');
                });
            this.refresh();
            if (this.opened) this.loadPlayerTag();
            this.poll = setInterval(() => { if (this.current(generation) && $('view-social').classList.contains('active')) { this.refresh(); this.loadPlayerTag(); if (this.peer) this.loadMessages(); } }, 30000);
        }
        paintPlayerTag(connection = this.connection) {
            const fresh = this.awaitingFreshTag || this.tagReadFailed ? null : window.CloudSync?.currentPlayerTag?.() || this.verifiedTag;
            const tag = fresh && connection && fresh.identity === connection.identity && fresh.client === connection.client ? playerTag(fresh.shortId) : '';
            if (connection) connection.shortId=tag || null;
            $('socialMyPlayerTag').textContent = tag || (connection ? 'Не назначен' : 'Войдите в аккаунт');
            $('socialCopyPlayerTag').disabled = !tag;
            const button = $('socialGeneratePlayerTag');
            if (button) { button.hidden = !connection || !!tag; button.disabled = !!this.tagBusy; button.textContent = this.tagBusy ? 'Проверка ID…' : 'Генерировать ID'; }
            if (!connection && $('socialPlayerTagStatus')) $('socialPlayerTagStatus').textContent = '';
        }
        async tagQuery(query) {
            let timer;
            try { return await Promise.race([query, new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('ID_TIMEOUT')), 10000); })]); }
            finally { clearTimeout(timer); }
        }
        async loadPlayerTag(generate = false) {
            if (!this.connection) return;
            const generation = this.generation, connection = this.connection;
            if (this.tagRequest?.generation === generation) return this.tagRequest.promise;
            const request = { generation, epoch:this.tagEpoch=(this.tagEpoch||0)+1 };
            this.tagRequest = request; this.tagBusy = true; this.awaitingFreshTag=true; this.tagReadFailed=false; this.verifiedTag=null; this.paintPlayerTag();
            request.promise = (async () => {
                try {
                    let response;
                    if (generate) {
                        const saved = await this.tagQuery(Promise.resolve(window.CloudSync?.saveSocialProfile?.(undefined, {preserveExisting:true})));
                        if (!this.current(generation)) return;
                        if (!saved) throw new Error('ID_PROFILE_NOT_READY');
                    }
                    response = window.CloudSync?.fetchPlayerTag
                        ? {data:await this.tagQuery(window.CloudSync.fetchPlayerTag())}
                        : await this.tagQuery(connection.client.from('profiles').select('short_id').eq('id', connection.userId).single());
                    if (!this.current(generation) || request.epoch!==this.tagEpoch) return;
                    if (response.error) throw response.error;
                    if (response.data?.id && response.data.id !== connection.userId) throw new Error('ID_OWNER_MISMATCH');
                    const tag = playerTag(response.data?.short_id);
                    if (generate && !tag) throw new Error('ID_NOT_ASSIGNED');
                    this.awaitingFreshTag=false; this.tagReadFailed=false;
                    this.verifiedTag = {identity:connection.identity,client:connection.client,shortId:tag || null};
                    this.connection.shortId = tag || null;
                    if (!window.CloudSync?.fetchPlayerTag) window.CloudSync?.rememberPlayerTag?.(connection.userId, tag || null, connection.client);
                    $('socialPlayerTagStatus').textContent = tag ? '' : 'Создайте игровой ID, чтобы друзья могли вас найти.';
                } catch (error) {
                    if (!this.current(generation)) return;
                    this.tagReadFailed=true;
                    $('socialPlayerTagStatus').textContent = ['PGRST202','PGRST204','42883','42703'].includes(error?.code)
                        ? 'Назначение ID ещё не настроено на сервере. Требуется применить миграцию Player Tag.'
                        : generate ? 'Не удалось создать ID. Проверьте соединение и повторите попытку.' : 'Не удалось загрузить ID. Нажмите «Обновить», чтобы повторить.';
                } finally {
                    if (this.tagRequest === request) this.tagRequest = null;
                    if (this.current(generation)) { this.tagBusy = false; this.awaitingFreshTag=false; this.paintPlayerTag(); }
                }
            })();
            return request.promise;
        }
        async dialogPreviews(client,me,generation) {
            if(this.messagesBlocked)return [];
            try {
                return await this.result(client.from('messages').select('id,sender_id,recipient_id,body,created_at')
                    .or(`sender_id.eq.${me},recipient_id.eq.${me}`).order('created_at',{ascending:false}).order('id',{ascending:false}).limit(100),generation);
            } catch(error) {
                if(this.current(generation)) {
                    if(schemaFailure(error))this.messagesBlocked=true;
                    this.status('Не удалось обновить чат. Повторите вручную кнопкой «Обновить».');
                }
                return [];
            }
        }
        async refresh() {
            if (!this.connection || this.refreshBlocked) return;
            const generation = this.generation, version = ++this.refreshVersion;
            const client = this.connection.client;
            try {
                const me = this.connection.userId;
                const [relations, messages] = await Promise.all([
                    this.result(client.from('friendships').select('id,requester_id,recipient_id,status').or(`requester_id.eq.${me},recipient_id.eq.${me}`), generation),
                    this.dialogPreviews(client,me,generation)
                ]);
                if (version !== this.refreshVersion) return;
                const ids = [...new Set((relations || []).map(row => row.requester_id === me ? row.recipient_id : row.requester_id).filter(uuid))];
                if (ids.length) {
                    const profiles = await this.result(client.from('profiles').select('id,username,handle,short_id').in('id',ids), generation);
                    if (version !== this.refreshVersion) return;
                    for (const person of profiles || []) this.people.set(person.id,{...person,user_id:person.id,avatar:''});
                }
                this.friends = (relations || []).map(row => {
                    const user_id = row.requester_id === me ? row.recipient_id : row.requester_id;
                    const person = this.people.get(user_id) || {};
                    return {...person,...row,user_id,nickname:playerTag(person.short_id) || 'ID недоступен'};
                });
                const dialogs = (messages || []).map(row=>({...row,user_id:row.sender_id === me ? row.recipient_id : row.sender_id}));
                for (const item of dialogs || []) {
                    const previous = this.latest.get(item.user_id);
                    if (!previous || compareMessages(item,previous) >= 0) this.latest.set(item.user_id, item);
                }
                this.renderPeople(); this.renderDialogs();
                if (this.peer && !this.friends.some(friend => friend.user_id === this.peer && friend.status === 'accepted')) this.back(true);
            } catch (error) {
                if(this.current(generation) && schemaFailure(error))this.refreshBlocked=true;
                this.fail(error, generation);
            }
        }
        avatar(person) {
            const url = person.avatar || '';
            const safe = /^https:\/\//i.test(url) || /^data:image\/(png|jpe?g|gif|webp|avif);base64,/i.test(url);
            return safe ? `<img class="social-avatar" src="${escape(url)}" alt="" loading="lazy" referrerpolicy="no-referrer">` : '<span class="social-avatar social-avatar-fallback" aria-hidden="true">👤</span>';
        }
        person(person, action) {
            return `<article class="social-person">${this.avatar(person)}<div class="social-person-info">${person.status === 'accepted' ? `<button type="button" class="social-name" data-social-profile="${escape(person.user_id)}"><strong>${escape(person.nickname)}</strong></button>` : `<strong>${escape(person.nickname)}</strong>`}</div><div class="social-person-actions">${action}</div></article>`;
        }
        renderPeople() {
            if (!this.connection) return;
            const me = this.connection.userId;
            $('socialFriends').innerHTML = this.friends.filter(item => item.status === 'accepted').map(item => this.person(item, `<button type="button" class="btn btn-secondary" data-social-profile="${escape(item.user_id)}">Профиль</button><button type="button" class="btn btn-primary" data-social-chat="${escape(item.user_id)}">Написать</button>`)).join('') || '<p class="social-empty">Пока нет друзей. Найдите знакомого по Player Tag.</p>';
            $('socialRequests').innerHTML = this.friends.filter(item => item.status === 'pending' && item.recipient_id === me).map(item => this.person(item, `<button type="button" class="btn btn-primary" data-social-accept="${escape(item.id)}">Принять</button><button type="button" class="btn btn-secondary" data-social-reject="${escape(item.id)}">Отклонить</button>`)).join('') || '<p class="social-empty">Нет входящих заявок.</p>';
            $('socialOutgoing').innerHTML = this.friends.filter(item => item.status === 'pending' && item.requester_id === me).map(item => this.person(item, '<span class="social-hint">Ожидает ответа</span>')).join('') || '<p class="social-empty">Нет отправленных заявок.</p>';
            if (this.searchResults) this.renderSearch();
        }
        setTab(tab, focus = false) {
            if (!['friends','search','chats'].includes(tab)) return;
            this.tab = tab;
            document.querySelectorAll('[data-social-tab]').forEach(button => {
                const selected = button.dataset.socialTab === tab;
                button.setAttribute('aria-selected', String(selected)); button.tabIndex = selected ? 0 : -1;
                $(`socialPanel-${button.dataset.socialTab}`).hidden = !selected;
                if (focus && selected) button.focus();
            });
        }
        async search(event) {
            event.preventDefault();
            if (!this.connection || !$('socialSearchForm').reportValidity()) return;
            const raw = playerTag($('socialNickname').value);
            if (!raw) { $('socialSearchResults').textContent = messages.invalid_input; return; }
            const ownTag = playerTag(this.connection.shortId);
            if (ownTag && raw.localeCompare(ownTag, undefined, { sensitivity:'accent' }) === 0) {
                this.searchCursor = null; this.searchResults = [];
                $('socialSearchResults').textContent = 'Это ваш Player Tag. Найдите ID друга, чтобы отправить заявку.';
                return;
            }
            const generation = this.generation, version = this.searchVersion = (this.searchVersion || 0) + 1;
            const button = $('socialSearchForm').querySelector('button'); button.disabled = true;
            this.searchCursor = null; this.searchResults = [];
            $('socialSearchResults').textContent = 'Поиск…';
            try {
                const result = await this.result(this.connection.client.rpc('search_profile_by_tag', {search_tag:raw}), generation);
                if (version !== this.searchVersion) return;
                const profiles = Array.isArray(result) ? result : Array.isArray(result?.profiles) ? result.profiles : result?.id || result?.user_id ? [result] : [];
                const found = profiles.filter(person => uuid(person.id || person.user_id) && playerTag(person.short_id) === raw);
                this.searchCursor = null;
                this.searchResults = found.map(person => ({...person,user_id:person.id || person.user_id,nickname:playerTag(person.short_id),avatar:person.avatar_url || person.avatar || ''}));
                for (const person of this.searchResults) this.people.set(person.user_id,person);
                if (found.length) { this.renderSearch(); this.status('Поиск завершён.'); }
                else $('socialSearchResults').textContent = messages[result?.state] || messages.not_found;
            } catch (error) { this.fail(error, generation, 'search'); if (this.current(generation)) $('socialSearchResults').textContent = 'Поиск не завершён.'; }
            finally { button.disabled = false; }
        }
        renderSearch() {
            $('socialSearchResults').innerHTML = (this.searchResults || []).map(item => {
                const friendship = this.friends.find(friend => friend.user_id === item.user_id);
                const state = this.requestStates.get(item.user_id);
                const own = item.user_id === this.connection?.userId;
                const text = own ? 'Это ваш аккаунт. Нельзя отправить заявку самому себе.' : friendship ? (friendship.status === 'accepted' ? 'Уже друзья' : 'Заявка уже существует') : state ? messages[state] : '';
                return this.person(item, text ? `<span class="social-hint">${escape(text)}</span>` : `<button type="button" class="btn btn-primary" data-social-add="${escape(item.user_id)}">Добавить в друзья</button>`);
            }).join('') || '<p class="social-empty">Пользователь не найден. Проверьте Player Tag.</p>';
            if (this.searchCursor) $('socialSearchResults').insertAdjacentHTML('beforeend','<button type="button" class="btn btn-secondary" data-social-more>Показать ещё совпадения</button>');
        }
        async action(button, rpc, params) {
            if (!this.connection || button.disabled) return;
            if (rpc === 'social_request_nickname' && params.target_id === this.connection.userId) { this.status(messages.self_request); return; }
            const generation = this.generation; button.disabled = true;
            try {
                const result = await this.result(this.connection.client.rpc(rpc, params), generation);
                if (rpc === 'social_request_nickname') {
                    const state = result?.state;
                    if (['request_sent','request_exists','already_friends'].includes(state)) {
                        this.requestStates.set(params.target_id, state); await this.refresh();
                        if (this.current(generation)) this.renderSearch();
                    }
                    if (this.current(generation)) this.status(messages[state] || 'Заявка не отправлена. Повторите попытку.');
                } else {
                    await this.refresh();
                    if (this.current(generation)) this.status('Заявка обработана.');
                }
            } catch (error) { this.fail(error, generation); }
            finally { button.disabled = false; }
        }
        async profile(userId) {
            if (!uuid(userId) || !this.connection) return;
            const generation = this.generation, version = this.profileVersion = (this.profileVersion || 0) + 1;
            const dialog = $('socialProfile'); $('socialProfileContent').textContent = 'Загрузка…';
            if (!dialog.open) dialog.showModal();
            try {
                const data = await this.result(this.connection.client.rpc('social_friend_profile', { target_id:userId }), generation);
                const person = { ...data, nickname:playerTag(this.people.get(userId)?.short_id || data.short_id) || 'ID недоступен' };
                if (version !== this.profileVersion || !dialog.open) return;
                $('socialProfileContent').innerHTML = `<div class="social-profile-person">${this.avatar(person)}<div><h3>${escape(person.nickname)}</h3></div></div><h4>Прогресс целей</h4><div class="social-public-goals">${(person.goals || []).map(goal => {
                    const progress = Math.max(0,Math.min(100,Number(goal.progress) || 0));
                    return `<article><strong>${escape(goal.title)}</strong><div class="social-goal-progress"><progress value="${progress}" max="100" aria-label="Прогресс цели"></progress><span>${progress}%</span></div></article>`;
                }).join('') || '<p class="social-empty">Нет целей с прогрессом или публичным статусом.</p>'}</div><button type="button" class="btn btn-primary" data-social-chat="${escape(userId)}">Написать сообщение</button>`;
            } catch (error) { if (this.current(generation) && version === this.profileVersion) $('socialProfileContent').textContent = 'Не удалось открыть профиль. Повторите попытку.'; this.fail(error, generation); }
        }
        accepted() { return this.friends.filter(friend => friend.status === 'accepted'); }
        renderDialogs() {
            const sorted = this.accepted().sort((a,b) => {
                const latestA=this.latest.get(a.user_id),latestB=this.latest.get(b.user_id);
                if(!latestA || !latestB)return latestA?-1:latestB?1:a.nickname.localeCompare(b.nickname);
                return compareMessages(latestB,latestA) || a.nickname.localeCompare(b.nickname);
            });
            $('socialDialogs').innerHTML = sorted.map(person => `<button type="button" class="social-dialog ${this.peer === person.user_id ? 'is-selected' : ''}" data-social-chat="${escape(person.user_id)}" aria-pressed="${this.peer === person.user_id}">${this.avatar(person)}<span><strong>${escape(person.nickname)}</strong><small>${escape(this.latest.get(person.user_id)?.body || 'Начните разговор')}</small></span></button>`).join('') || '<p class="social-empty">Добавьте друга, чтобы начать переписку.</p>';
        }
        openChat(userId) {
            const friend = this.accepted().find(item => item.user_id === userId);
            if (!friend) return;
            if (this.peer) this.drafts.set(this.peer, $('socialMessage').value);
            this.peer = userId; this.messages.clear(); this.chatVersion++;
            $('socialProfile').close?.(); this.setTab('chats');
            $('socialChatLayout').classList.add('has-chat'); $('socialChatTitle').textContent = friend.nickname;
            $('socialMessage').value = this.drafts.get(userId) || ''; $('socialMessage').disabled = false;
            $('socialSend').disabled = this.sending.has(userId); $('socialSend').textContent = this.sending.has(userId) ? 'Отправка…' : 'Отправить';
            $('socialMessages').textContent = 'Загрузка сообщений…'; $('socialOlder').hidden = true;
            this.renderDialogs(); this.loadMessages();
        }
        back(clear = false) {
            $('socialChatLayout').classList.remove('has-chat');
            if (clear) {
                this.peer = null; this.chatVersion++; this.messages.clear(); $('socialMessages').replaceChildren();
                $('socialMessage').value = ''; $('socialMessage').disabled = true; $('socialSend').disabled = true;
                $('socialChatTitle').textContent = 'Выберите друга'; $('socialOlder').hidden = true;
            }
            this.renderDialogs();
        }
        async loadMessages(older = false) {
            if (!this.connection || !this.peer || this.messagesBlocked) return;
            const generation = this.generation, version = this.chatVersion, peer = this.peer, me = this.connection.userId;
            $('socialOlder').disabled = true;
            try {
                let cursor='';
                if(older && this.messages.size) {
                    const first=this.sortedMessages()[0];
                    if(!messageTime(first) || !uuid(first.id))throw new Error('Invalid history cursor');
                    cursor=`,or(created_at.lt.${first.created_at},and(created_at.eq.${first.created_at},id.lt.${first.id}))`;
                }
                const query=this.connection.client.from('messages').select('id,sender_id,recipient_id,body,created_at')
                    .or(`and(sender_id.eq.${me},recipient_id.eq.${peer}${cursor}),and(sender_id.eq.${peer},recipient_id.eq.${me}${cursor})`)
                    .order('created_at',{ascending:false}).order('id',{ascending:false}).limit(50);
                const rows = await this.result(query, generation);
                if (peer !== this.peer || version !== this.chatVersion) return;
                for (const row of rows || []) this.messages.set(row.id, row);
                if (older || this.messages.size <= 50) this.hasOlder = rows?.length === 50;
                const container = $('socialMessages'), height = container.scrollHeight, top = container.scrollTop;
                this.renderMessages(!older);
                if (older) container.scrollTop = top + container.scrollHeight - height;
                $('socialOlder').hidden = !this.hasOlder;
            } catch (error) {
                if(this.current(generation) && schemaFailure(error))this.messagesBlocked=true;
                this.fail(error, generation);
                if (this.current(generation) && version === this.chatVersion && !this.messages.size) $('socialMessages').textContent = 'Не удалось загрузить сообщения. Нажмите «Обновить».';
            } finally { if (this.current(generation) && version === this.chatVersion) $('socialOlder').disabled = false; }
        }
        sortedMessages() { return [...this.messages.values()].sort(compareMessages); }
        renderMessages(scroll = true) {
            const container = $('socialMessages'), me = this.connection.userId;
            const nearBottom = container.scrollHeight - container.scrollTop - container.clientHeight < 100;
            container.innerHTML = this.sortedMessages().map(row => {
                const date = new Date(row.created_at);
                return `<article class="social-bubble ${row.sender_id === me ? 'is-mine' : 'is-theirs'}"><p>${escape(row.body)}</p><time datetime="${escape(row.created_at)}">${Number.isNaN(date.getTime()) ? '' : escape(date.toLocaleString('ru-RU', { day:'numeric', month:'short', hour:'2-digit', minute:'2-digit' }))}</time></article>`;
            }).join('') || '<p class="social-empty">Сообщений пока нет. Начните разговор.</p>';
            if (scroll && nearBottom) container.scrollTop = container.scrollHeight;
        }
        receive(row) {
            if (!this.connection || !row?.id) return;
            const me = this.connection.userId;
            if (row.sender_id !== me && row.recipient_id !== me) return;
            const peer = row.sender_id === me ? row.recipient_id : row.sender_id;
            if (!this.accepted().some(friend => friend.user_id === peer)) return;
            const latest = this.latest.get(peer);
            if (!latest || compareMessages(row,latest) > 0) this.latest.set(peer, { ...row, user_id:peer });
            if (this.peer === peer) { this.messages.set(row.id, row); this.renderMessages(); }
            this.renderDialogs();
        }
        async send(event) {
            event.preventDefault();
            if (!this.connection || !this.peer || this.sending.has(this.peer)) return;
            const peer = this.peer, body = $('socialMessage').value.trim();
            if (!body || body.length > 4000) return;
            const generation = this.generation, client = this.connection.client;
            const pending = this.retries.get(peer);
            const id = pending?.body === body ? pending.id : crypto.randomUUID();
            this.retries.set(peer, { id, body }); this.sending.add(peer);
            $('socialSend').disabled = true; $('socialSend').textContent = 'Отправка…';
            try {
                let response = await client.from('messages').insert({ id, sender_id:this.connection.userId, recipient_id:peer, body }).select('id,sender_id,recipient_id,body,created_at').single();
                if (!this.current(generation)) return;
                // Retry of a committed request whose HTTP response was lost must not duplicate it.
                if (response.error?.code === '23505') response = await client.from('messages').select('id,sender_id,recipient_id,body,created_at').eq('id', id).single();
                if (!this.current(generation)) return;
                if (response.error) throw response.error;
                this.receive(response.data); this.retries.delete(peer);
                if ((this.drafts.get(peer) || '').trim() === body) this.drafts.delete(peer);
                if (this.peer === peer && $('socialMessage').value.trim() === body) $('socialMessage').value = '';
                this.status('Сообщение отправлено.');
            } catch (error) { this.fail(error, generation); }
            finally {
                if (this.current(generation)) {
                    this.sending.delete(peer);
                    if (this.peer === peer) { $('socialSend').disabled = false; $('socialSend').textContent = 'Отправить'; }
                }
            }
        }
        bind() {
            $('socialCopyPlayerTag')?.addEventListener('click', async () => {
                const tag = playerTag(this.connection?.shortId);
                if (!tag) return;
                try { await navigator.clipboard.writeText(tag); this.status('Ваш ID скопирован.'); }
                catch { this.status('Не удалось скопировать. Ваш ID: ' + tag); }
            });
            $('socialSearchForm').addEventListener('submit', event => this.search(event));
            $('socialMessageForm').addEventListener('submit', event => this.send(event));
            $('socialMessage').addEventListener('input', () => { if (this.peer) this.drafts.set(this.peer, $('socialMessage').value); });
            $('socialGeneratePlayerTag')?.addEventListener('click', () => this.loadPlayerTag(true));
            $('socialRefresh').addEventListener('click', () => {
                this.refreshBlocked=false; this.messagesBlocked=false;
                this.connect(); this.loadPlayerTag(); this.refresh(); if (this.peer) this.loadMessages();
                const check = window.OTASync?.refresh ? window.OTASync.refresh() : window.app?.checkForWebUpdate?.({force:true});
                Promise.resolve(check).catch(() => window.app?.showToast?.('Не удалось проверить обновления. Повторите попытку.', 'error'));
            });
            $('socialBindProfile')?.addEventListener('click', () => { window.app?.openSettingsModal(); document.querySelector('[data-cloud-bind]')?.focus(); });
            $('socialLogin').addEventListener('click', () => { window.app?.openSettingsModal(); window.CloudSync?.openAuth(); });
            $('socialChatBack').addEventListener('click', () => this.back());
            $('socialOlder').addEventListener('click', () => this.loadMessages(true));
            $('socialProfileClose').addEventListener('click', () => $('socialProfile').close());
            $('view-social').addEventListener('click', event => {
                const button = event.target.closest('button'); if (!button || button.disabled) return;
                const data = button.dataset;
                if (data.socialTab) this.setTab(data.socialTab);
                if (data.socialProfile) this.profile(data.socialProfile);
                if (data.socialChat) this.openChat(data.socialChat);
                if (data.socialAdd && uuid(data.socialAdd)) this.action(button, 'social_request_nickname', { target_id:data.socialAdd });
                if (data.socialAccept || data.socialReject) this.action(button, 'social_respond', { friendship_id:data.socialAccept || data.socialReject, accept_request:!!data.socialAccept });
            });
            document.querySelector('.social-tabs').addEventListener('keydown', event => {
                const tabs = ['friends','search','chats'];
                if (!['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) return;
                event.preventDefault();
                const index = tabs.indexOf(this.tab);
                this.setTab(event.key === 'Home' ? tabs[0] : event.key === 'End' ? tabs[2] : tabs[(index + (event.key === 'ArrowRight' ? 1 : 2)) % 3], true);
            });
            document.addEventListener('goaltracker:player-tag',event=>{
                const value=event.detail;
                if(value && this.connection && value.identity===this.connection.identity && value.client===this.connection.client) { this.awaitingFreshTag=false; this.tagReadFailed=false; this.verifiedTag=value; this.connection.shortId=value.shortId; this.paintPlayerTag(); }
            });
            document.addEventListener('goaltracker:cloud-session', () => { this.connect(); });
            const resume = () => { if (this.opened && $('view-social').classList.contains('active')) { this.connect(); this.loadPlayerTag(); this.refresh(); if (this.peer) this.loadMessages(); } };
            window.addEventListener('online', resume); window.addEventListener('focus', resume);
            document.addEventListener('visibilitychange', () => { if (!document.hidden) resume(); });
        }
    }
    window.SocialView = SocialView;
    if ($('view-social')) window.socialView = new SocialView();
})();
