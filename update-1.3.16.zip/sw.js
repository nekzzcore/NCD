const CACHE_NAME = 'goaltracker-v49-interface-polish';
const STATIC_ASSETS = [
    './',
    './index.html',
    './styles.css',
    './app.js',
    './ui-select.js',
    './social.js',
    './ota-sync.js',
    './supabase-config.js',
    './sync.js',
    './vendor/supabase/supabase.js',
    './finance.js',
    './assets/custodian.png',
    './health.js',
    './health-3d.js',
    './vendor/three/three.module.js',
    './vendor/three/three.core.js',
    './vendor/three/addons/controls/OrbitControls.js',
    './vendor/three/addons/loaders/GLTFLoader.js',
    './vendor/three/addons/utils/BufferGeometryUtils.js',
    './vendor/three/addons/utils/SkeletonUtils.js',
    './profile-storage.js',
    './gamification.js',
    './notifications.js',
    './auth_sync.js',
    './avatar.js',
    './manifest.json',
    './icon.png',
    './icon.ico',
    './favicon.ico',
    './icon-48.png',
    './icon-192.png',
    './icon-512.png',
    './icon-192-maskable.png',
    './icon-512-maskable.png',
    './icon.svg'
];

// Install — принудительно кэшируем ВСЕ статические файлы
self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('[SW] Caching all static assets for offline-first');
                return cache.addAll(STATIC_ASSETS);
            })
            .then(() => caches.open(CACHE_NAME).then(cache => Promise.all([
                './assets/logo.png',
                './assets/avatar/body_scan.mp4',
                './assets/avatar/body_preview.jpg'
            ].map(url => cache.add(url).catch(() => {})))))
            .then(() => {
                console.log('[SW] Install complete, skipping waiting');
                return self.skipWaiting();
            })
            .catch(err => {
                console.error('[SW] Install failed:', err);
            })
    );
});

// Activate — чистим старые кэши и берём контроль над клиентами
self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys().then(keys =>
            Promise.all(keys.filter(k => k !== CACHE_NAME && /^goaltracker-v\d+-/.test(k)).map(k => {
                console.log('[SW] Deleting old cache:', k);
                return caches.delete(k);
            }))
        ).then(() => {
            console.log('[SW] Activating, claiming clients');
            return self.clients.claim();
        })
    );
});

// Stale-While-Revalidate для ВСЕХ запросов (offline-first)
self.addEventListener('fetch', event => {
    if (event.request.method !== 'GET') return;

    const url = new URL(event.request.url);
    if (event.request.headers.has('authorization') || /^\/(?:auth|rest|storage)\/v1(?:\/|$)/.test(url.pathname)) return;
    const isNavigation = event.request.mode === 'navigate';
    const isSameOrigin = url.origin === self.location.origin;

    // Игнорируем cross-origin запросы (не кэшируем их)
    if (!isSameOrigin) {
        event.respondWith(fetch(event.request).catch(() => new Response('', { status: 504 })));
        return;
    }

    // MP4: полная копия в кэше, отдельные 206-ответы для видеоплеера.
    // Ошибка видео не должна мешать установке PWA или загрузке интерфейса.
    if (url.pathname.endsWith('.mp4')) {
        event.respondWith((async () => {
            const cache = await caches.open(CACHE_NAME);
            const cached = await cache.match(url.href);
            if (!cached) {
                return fetch(event.request).catch(() => new Response('', { status: 503 }));
            }
            const range = event.request.headers.get('Range');
            if (!range) return cached;
            const blob = await cached.blob();
            const match = /^bytes=(\d*)-(\d*)$/.exec(range);
            let start = 0;
            let end = blob.size - 1;
            if (match && (match[1] || match[2])) {
                start = match[1] ? Number(match[1]) : Math.max(0, blob.size - Number(match[2]));
                end = match[1] && match[2] ? Math.min(Number(match[2]), end) : end;
            }
            if (!match || !(match[1] || match[2]) || !Number.isSafeInteger(start) ||
                !Number.isSafeInteger(end) || start > end || start >= blob.size) {
                return new Response('', { status: 416, headers: { 'Content-Range': `bytes */${blob.size}` } });
            }
            return new Response(blob.slice(start, end + 1), {
                status: 206,
                headers: {
                    'Content-Type': 'video/mp4',
                    'Content-Length': String(end - start + 1),
                    'Content-Range': `bytes ${start}-${end}/${blob.size}`,
                    'Accept-Ranges': 'bytes'
                }
            });
        })());
        return;
    }

    // Стратегия: СНАЧАЛА кэш (мгновенный ответ), потом сеть (обновление кэша в фоне)
    event.respondWith(
        caches.open(CACHE_NAME).then(async cache => {
            // 1. СРАЗУ ищем в кэше
            const cachedResponse = await cache.match(event.request);

            // 2. Запускаем фоновое обновление (не блокируем ответ)
            const fetchPromise = fetch(event.request).then(networkResponse => {
                if (networkResponse && networkResponse.ok) {
                    // Клонируем и обновляем кэш в фоне
                    cache.put(event.request, networkResponse.clone()).catch(() => {});
                }
                return networkResponse;
            }).catch(err => {
                console.log('[SW] Network fetch failed (offline?), using cache:', err.message);
                // Сеть недоступна — тихо игнорируем, кэш уже вернётся
            });

            // 3. Если есть в кэше — отдаём СРАЗУ (offline-first)
            if (cachedResponse) {
                // Запускаем обновление в фоне (fire-and-forget)
                fetchPromise.catch(() => {});
                return cachedResponse;
            }

            // 4. Нет в кэше — ждём сеть
            try {
                const networkResponse = await fetchPromise;
                if (networkResponse && networkResponse.ok) {
                    // Кэшируем успешный ответ
                    cache.put(event.request, networkResponse.clone()).catch(() => {});
                }
                return networkResponse;
            } catch (err) {
                // 5. Нет сети И нет в кэше — для навигации отдаём index.html (SPA fallback)
                if (isNavigation) {
                    const offlineResponse = await cache.match('./index.html');
                    if (offlineResponse) return offlineResponse;
                }
                // Для остальных ресурсов — ошибка
                return new Response('Offline: resource not cached', {
                    status: 503,
                    statusText: 'Service Unavailable',
                    headers: { 'Content-Type': 'text/plain; charset=utf-8' }
                });
            }
        })
    );
});

// Push notifications (оставляем как было)
self.addEventListener('push', event => {
    const data = event.data ? event.data.json() : {};
    const title = data.title || 'NCD';
    const options = {
        body: data.body || 'У вас есть обновления по целям',
        icon: 'icon-192.png',
        badge: 'icon-48.png',
        vibrate: [200, 100, 200],
        tag: 'goaltracker-notification',
        renotify: true
    };
    event.waitUntil(
        self.registration.showNotification(title, options)
    );
});

self.addEventListener('notificationclick', event => {
    event.notification.close();
    event.waitUntil(
        clients.matchAll({ type: 'window', includeUncontrolled: true }).then(clientList => {
            for (const client of clientList) {
                if (client.url.includes(self.location.origin) && 'focus' in client) {
                    return client.focus();
                }
            }
            return clients.openWindow('./');
        })
    );
});

// Обработка сообщений от клиента (skipWaiting на команду)
self.addEventListener('message', event => {
    if (event.data && event.data.type === 'SKIP_WAITING') {
        self.skipWaiting();
    }
});
