/* Cloud-first account isolation with owner-scoped offline writes and secure logout. */
(function () {
    'use strict';
    if (window.CloudSync) return; // Loading the bundle twice must not create another auth client.
    const CONFIG = 'gt-supabase-config-v1', OWNER = 'gt-supabase-owner-v1', LOCK = 'gt-session-locked-v1';
    const clone = value => JSON.parse(JSON.stringify(value));
    const stable = value => Array.isArray(value) ? value.map(stable) : value && typeof value === 'object' ? Object.fromEntries(Object.keys(value).sort().map(key => [key, stable(value[key])])) : value;
    const same = (a, b) => JSON.stringify(stable(a)) === JSON.stringify(stable(b));
    const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
    const empty = () => ({ goals: [], transactions: [], safetyFund: {}, profile: {}, financeOther: {}, calendar: {} });
    const normalize = value => ({ ...empty(), ...(value || {}) });
    function validateState(value) {
        const state = normalize(value);
        if (!Array.isArray(state.goals) || !Array.isArray(state.transactions) ||
            !['safetyFund','profile','financeOther','calendar'].every(key => object(state[key])) ||
            state.goals.some(goal => !object(goal) || typeof goal.id !== 'string' || typeof goal.title !== 'string') ||
            ['nickname','status','createdAt','customAvatarData'].some(key => state.profile[key] !== undefined && typeof state.profile[key] !== 'string')) throw new Error('Unsupported cloud data');
        return state;
    }
    function merge(base, local, remote, prefer, path = '', conflicts = []) {
        if (same(local, base)) return { value: remote, conflicts };
        if (same(remote, base) || same(local, remote)) return { value: local, conflicts };
        if (path === '/safetyFund') {
            if (!prefer) conflicts.push(path);
            return { value: prefer === 'remote' ? remote : local, conflicts };
        }
        if (object(local) && object(remote) && (object(base) || base === undefined)) {
            const value = {};
            for (const key of new Set([...Object.keys(base || {}), ...Object.keys(remote), ...Object.keys(local)])) {
                if (['__proto__','constructor','prototype'].includes(key)) continue;
                const next = merge(base?.[key], local[key], remote[key], prefer, `${path}/${key}`, conflicts).value;
                if (next !== undefined) value[key] = next;
            }
            return { value, conflicts };
        }
        const keyed = array => Array.isArray(array) && array.every(item => object(item) && typeof item.id === 'string') && new Set(array.map(item => item.id)).size === array.length;
        if (keyed(local) && keyed(remote) && (keyed(base) || base === undefined)) {
            const maps = [base || [], local, remote].map(items => new Map(items.map(item => [item.id, item])));
            const value = [];
            for (const id of new Set([...remote.map(item => item.id), ...local.map(item => item.id), ...(base || []).map(item => item.id)])) {
                const item = merge(maps[0].get(id), maps[1].get(id), maps[2].get(id), prefer, `${path}/${id}`, conflicts).value;
                if (item !== undefined) value.push(item);
            }
            return { value, conflicts };
        }
        if (!prefer) conflicts.push(path || '/');
        return { value: prefer === 'remote' ? remote : local, conflicts };
    }
    function validateConfig(url, key) {
        const parsed = new URL(url);
        if (parsed.protocol !== 'https:' || parsed.username || parsed.password || parsed.search || parsed.hash || !['','/'].includes(parsed.pathname)) throw new Error('Укажите HTTPS URL проекта без пути, пароля и параметров.');
        if (!/^sb_publishable_[A-Za-z0-9_-]+$/.test(key)) {
            let role;
            try { role = JSON.parse(atob(key.split('.')[1].replace(/-/g,'+').replace(/_/g,'/'))).role; } catch {}
            if (role !== 'anon') throw new Error('Допустим только публичный anon/publishable key. Секретные ключи запрещены.');
        }
        return { url: parsed.origin, key };
    }
    window.CloudSyncCore = { merge, normalize, empty, validateConfig };
    let app, client, config, session, subscription, timer, polling, busy = false, applying = false;
    let bootstrapIdentity = null, bootstrapPromise = null;
    let dataChannel = null, realtimeIdentity = null, realtimeTimer, rerunSync = false;
    const singleton = {instance:null,url:null,key:null,generation:0};
    let sdkEpoch = 0, authPending = false;
    let playerTagVersion = 0, freshPlayerTag = null;
    let accountEpoch = 0, authCycle = 0, readyIdentity = null, desiredIdentity = null, settledNoSession = false;
    let transitioning = false, loggingOut = false, accountQueue = Promise.resolve(), sessionLoad = null, syncWork = null, logoutWork = null, initializing = null;
    let tokenWrites = Promise.resolve(), pendingWrites = Promise.resolve(), calendarMode = null;
    const activeRequests = new Set();
    let syncDiagnostic = '', sessionError = false, storageWarning = false;
    function canOpenCachedAccount(user = app?.user) {
        if (!user?.supabaseUserId || localStorage.getItem(LOCK) === 'true') return false;
        const saved = read(CONFIG, window.SupabaseConfig || null);
        const owner = localStorage.getItem(OWNER);
        return !!saved?.url && (!owner || owner === `${saved.url}|${user.supabaseUserId}`);
    }
    function showStartupFallback() {
        if (canOpenCachedAccount()) app.showApp(); else app.showAccountLoading?.();
    }
    function connectionState() {
        if (session) return { state:readyIdentity === ownerId() && !transitioning ? 'active' : transitioning ? 'loading' : 'load_error', needsBinding:false, text:readyIdentity === ownerId() && !transitioning ? 'Сессия активна' : transitioning ? 'Загружаем данные аккаунта…' : 'Сессия активна. Данные пока не синхронизированы.' };
        return { state:sessionError ? 'restore_error' : 'no_session', needsBinding:false, text:sessionError ? 'Не удалось восстановить сессию. Повторите вход.' : 'Войдите в облачный аккаунт.' };
    }
    let message = 'Облако не подключено. Данные сохраняются на устройстве.', conflict = false, bindNeeded = false, previews = [];
    const preferences = window.NCDNativeStorage?.preferences || window.Capacitor?.Plugins?.Preferences;
    const nativePreferences = window.NCDNativeStorage?.isNative?.() ?? !!window.Capacitor?.isNativePlatform?.();
    const AUTH_PREFERENCE_PREFIX = 'goaltracker.supabase.';
    const authStorage = {
        async getItem(key) {
            if (nativePreferences) {
                try {
                    const result = await preferences.get({ key: AUTH_PREFERENCE_PREFIX + key });
                    if (result.value !== null) return result.value;
                    // Однократная миграция сессии из прежнего WebView localStorage.
                    const legacy = localStorage.getItem(key);
                    if (legacy !== null) {
                        await preferences.set({ key: AUTH_PREFERENCE_PREFIX + key, value: legacy });
                        return legacy;
                    }
                    return null;
                } catch (error) { storageWarning = true; throw error; }
            }
            return localStorage.getItem(key);
        },
        async setItem(key, value) {
            if (nativePreferences) {
                try {
                    await preferences.set({ key: AUTH_PREFERENCE_PREFIX + key, value });
                    return;
                } catch (error) { storageWarning = true; throw error; }
            }
            localStorage.setItem(key, value);
        },
        async removeItem(key) {
            if (nativePreferences) {
                try { await preferences.remove({ key: AUTH_PREFERENCE_PREFIX + key }); } catch {}
            }
            localStorage.removeItem(key);
        }
    };
    const read = (key, fallback) => { const value = localStorage.getItem(key); return value ? JSON.parse(value) : fallback; };
    const write = (key, value) => localStorage.setItem(key, JSON.stringify(value));
    const ownerId = () => session?.user?.id ? `${config.url}|${session.user.id}` : null;
    const metaKey = () => `gt-cloud-state-v1:${ownerId()}`;
    const backupKey = () => `gt-cloud-backup-v1:${ownerId()}`;
    const pendingKey = identity => `gt-cloud-pending-v1:${identity}`;
    const authKey = key => key.startsWith('goaltracker.supabase.') || key.startsWith('gt-supabase-auth:') || /^sb-.*-auth-token/.test(key) || key.startsWith('tokens.');
    function scope() { return { epoch:accountEpoch, identity:ownerId(), userId:session?.user?.id, db:client }; }
    function current(saved) { return !saved?.cancelled && !!saved?.identity && saved.epoch === accountEpoch && saved.identity === ownerId() && saved.db === client && localStorage.getItem(OWNER) === saved.identity; }
    function assertCurrent(saved) { if (!current(saved)) throw Object.assign(new Error('Аккаунт изменился.'), { code:'NCD_STALE' }); }
    function stopAccountRequests() { clearTimeout(timer); clearTimeout(realtimeTimer); clearInterval(polling); stopRealtime(); for (const controller of activeRequests) controller.abort(); }
    async function clearUserCaches({ keepAuth = false, pending = null } = {}) {
        const preferenceKeys = nativePreferences && typeof preferences.keys === 'function' ? (await preferences.keys()).keys : [];
        const knownAuthKeys = config ? [`${AUTH_PREFERENCE_PREFIX}gt-supabase-auth:${config.url}`, ...Object.values(tokenKeys()).map(key => AUTH_PREFERENCE_PREFIX+key)] : [];
        const keys = new Set([...Object.keys(localStorage),...preferenceKeys,...knownAuthKeys,'gt_goals','gt_finance','gt_calendar','gt_profile','gt_safety_fund','goalTracker_finance','goalTracker_health_local_v1']);
        const currentKeys = new Set(knownAuthKeys.flatMap(key => [key,key.replace(AUTH_PREFERENCE_PREFIX,'')]));
        const preserveKeys = [...keys].filter(key => (keepAuth && currentKeys.has(key)) || key === pending);
        let failure;
        try {
            if (window.ProfileStorage.clearUserData) await window.ProfileStorage.clearUserData({ preserveKeys });
            else { await window.ProfileStorage.flush?.(); await window.ProfileStorage.save({ schemaVersion:1,profileReset:true,user:null,goals:[],events:[],notes:{},habits:[],achievements:[],settings:{autoSync:true} }); }
        } catch (error) { failure = error; }
        const keep = new Set([CONFIG,LOCK,'theme','goalTracker_data',...preserveKeys]);
        for (const key of keys) if (!keep.has(key)) {
            localStorage.removeItem(key);
            if (nativePreferences) { try { await preferences.remove({ key }); } catch (error) { failure ||= error; } }
        }
        const stored = window.ProfileStorage.get?.();
        const marker = stored?.profileReset && !stored.user ? stored : {schemaVersion:1,profileReset:true,user:null,goals:[],events:[],notes:{},habits:[],achievements:[],settings:{autoSync:true},storageRevision:Math.max(Date.now(),(stored?.storageRevision||0)+1)};
        localStorage.setItem('goalTracker_data',JSON.stringify(marker));
        if (nativePreferences) { try { await preferences.set({key:'goalTracker_data',value:JSON.stringify(marker)}); } catch (error) { failure ||= error; } }
        if (failure) throw failure;
    }
    function savePending(identity, value) {
        const key = pendingKey(identity), epoch = accountEpoch;
        if (value) write(key,value); else localStorage.removeItem(key);
        if (nativePreferences) pendingWrites = pendingWrites.catch(() => {}).then(async () => {
            if (epoch !== accountEpoch || identity !== ownerId()) return;
            if (value) await preferences.set({ key,value:JSON.stringify(value) }); else await preferences.remove({ key });
        }).catch(() => { storageWarning = true; });
    }
    function status(text) { message = text; refresh(); document.dispatchEvent(new Event('goaltracker:cloud-session')); }
    function capture() {
        const finance = window.finance?.getData?.() || read('goalTracker_finance', {});
        const { transactions = [], safetyFund = {}, ...financeOther } = finance;
        return clone({ goals: app.goals, transactions, safetyFund, financeOther,
            profile: { nickname: app.user?.nickname || '', status: app.user?.status || '', createdAt: app.user?.createdAt || '', customAvatarData: app.getCustomAvatar?.() || '' },
            calendar: { notes: app.notes || {}, events: app.events || [], achievements: app.achievements || [] } });
    }
    function localEmpty(state) {
        return !state.goals.length && !state.transactions.length && !state.safetyFund.balance && !(state.safetyFund.history || []).length &&
            !(state.financeOther.investments?.assets || []).length && !(state.financeOther.growth?.ideas || []).length &&
            !state.financeOther.growth?.baseIncome && !state.financeOther.growth?.currentIncome && !(state.financeOther.growth?.history || []).length &&
            (!state.safetyFund.targetMonths || state.safetyFund.targetMonths === 6) &&
            !Object.values(state.financeOther.budget?.categories || {}).some(item => item.limit) &&
            !Object.keys(state.calendar.notes || {}).length && !(state.calendar.events || []).length && !(state.calendar.achievements || []).length && !state.profile.customAvatarData && !state.profile.status;
    }
    function appBusy() { return app._calendarCompletionPending || app._attachmentPending || app._goalSaveInProgress || app._goalActionPending || app._profileSaving || app._avatarLoading || app._resetting; }
    function localChanged() {
        if (applying || loggingOut || !session || !config || localStorage.getItem(OWNER) !== ownerId()) return;
        if (transitioning || readyIdentity !== ownerId()) {
            if (!app._accountTransition && app.user?.supabaseUserId === session.user.id) {
                const pending = read(pendingKey(ownerId()),null);
                savePending(ownerId(), { base:pending?.base || empty(), local:capture() });
            }
            return;
        }
        const base = read(metaKey(),{}).base || empty(), local = capture();
        if (same(base,local)) { savePending(ownerId(),null); return; }
        savePending(ownerId(),{ base,local });
        status(navigator.onLine === false ? 'Офлайн: изменения ожидают отправки в ваш аккаунт.' : 'Сохраняем в облаке…');
        clearTimeout(timer); timer = setTimeout(() => sync(),0);
    }

    const DOCUMENT_VERSION = '__goaltrackerVersion';
    function documentContent(value) {
        if (Array.isArray(value)) return value.map(item => object(item) ? Object.fromEntries(Object.entries(item).filter(([key]) => key !== DOCUMENT_VERSION)) : item);
        return object(value) ? Object.fromEntries(Object.entries(value).filter(([key]) => key !== DOCUMENT_VERSION)) : value;
    }
    function versionedDocument(value) {
        const next = clone(value), version = crypto.randomUUID();
        if (Array.isArray(next)) { if (next.length) { if (!object(next[0])) throw new Error('Неподдерживаемый формат облачных записей.'); next[0][DOCUMENT_VERSION] = version; } }
        else next[DOCUMENT_VERSION] = version;
        return next;
    }
    function payloadFailure(field) {
        const error = new Error('Некорректное поле перед отправкой в облако.');
        error.payloadField = field;
        return error;
    }
    function cleanId(value, field = 'id') {
        // Accept existing string IDs as well as UUIDs; never coerce objects or regenerate IDs.
        if (typeof value !== 'string' || !value.trim() || value !== value.trim() ||
            /\s|[\x00-\x1f]/.test(value) || ['undefined','null','[object Object]'].includes(value)) throw payloadFailure(field);
        return value;
    }
    function cleanTimestamp(value) {
        // Missing/invalid SQL timestamps are omitted so database defaults can apply.
        if (value == null || value === '') return undefined;
        if (typeof value === 'string') {
            const parts = /^(\d{4})-(\d{2})-(\d{2})/.exec(value);
            if (!parts || Number(parts[2]) < 1 || Number(parts[2]) > 12 || Number(parts[3]) < 1 ||
                Number(parts[3]) > new Date(Date.UTC(Number(parts[1]), Number(parts[2]), 0)).getUTCDate()) return undefined;
        }
        const date = Object.prototype.toString.call(value) === '[object Date]' ? value :
            typeof value === 'string' && /^\d{4}-\d{2}-\d{2}(?:T\d{2}:\d{2}(?::\d{2}(?:\.\d{1,3})?)?(?:Z|[+-]\d{2}:?\d{2}))?$/.test(value) ? new Date(value) : null;
        return date && Number.isFinite(date.getTime()) ? date.toISOString() : undefined;
    }
    function cleanPayload(value) {
        if (Array.isArray(value)) return value.map(cleanPayload);
        if (!object(value)) return value;
        const result = {};
        for (const [key, field] of Object.entries(value)) {
            if (['__proto__','constructor','prototype'].includes(key) || field === undefined) continue;
            if (['created_at','updated_at','createdAt','updatedAt'].includes(key)) {
                const timestamp = cleanTimestamp(field);
                if (timestamp !== undefined) result[key] = timestamp;
            } else if (['id','user_id'].includes(key)) result[key] = cleanId(field, key);
            else result[key] = cleanPayload(field);
        }
        return result;
    }
    function cloudFailure(error, operation) {
        const failure = new Error('Облачный запрос не завершён.');
        failure.code = error?.code; failure.operation = operation;
        return failure;
    }
    function publishPlayerTag(saved, shortId, version) {
        assertCurrent(saved);
        if (version !== playerTagVersion) return;
        freshPlayerTag={identity:saved.identity,userId:saved.userId,client:saved.db,epoch:saved.epoch,shortId:shortId || null};
        app.user.shortId=shortId || null;
        document.dispatchEvent(new CustomEvent('goaltracker:player-tag',{detail:freshPlayerTag}));
    }
    function currentPlayerTag() {
        const saved=scope();
        return freshPlayerTag && current(saved) && freshPlayerTag.epoch===saved.epoch && freshPlayerTag.identity===saved.identity && freshPlayerTag.client===saved.db ? freshPlayerTag : null;
    }
    async function fetchPlayerTag(saved=scope()) {
        if(!session?.user?.id || !app?.user || !saved.db)return null;
        assertCurrent(saved);
        const version=++playerTagVersion;
        const {data,error}=await saved.db.from('profiles').select('short_id').eq('id',saved.userId).single();
        assertCurrent(saved);
        if(error && error.code!=='PGRST116')throw cloudFailure(error,'profiles.short_id');
        publishPlayerTag(saved,data?.short_id || null,version);
        return version===playerTagVersion ? {short_id:data?.short_id || null} : {short_id:currentPlayerTag()?.shortId || null};
    }
    const PROFILE_COLUMNS = 'id,username,handle,short_id';
    async function fetchProfile(saved = scope()) {
        if (!session?.user?.id || !app?.user || !saved.userId || !saved.db) return null;
        assertCurrent(saved);
        const version=++playerTagVersion;
        const result = await saved.db.from('profiles').select(PROFILE_COLUMNS).eq('id', saved.userId).maybeSingle();
        assertCurrent(saved);
        if (result.error) throw cloudFailure(result.error,'profiles.select');
        const profile = result.data || null;
        if (profile && profile.id !== saved.userId) throw cloudFailure({code:'42501'},'profiles.owner');
        // This read runs independently of finance hydration; never reuse a cached ID.
        publishPlayerTag(saved,profile?.short_id || null,version);
        app.user.handle = profile?.handle || null;
        document.dispatchEvent(new Event('goaltracker:cloud-session'));
        return profile;
    }
    async function tableRow(table, userId, db = client, saved = scope()) {
        if (!session?.user?.id || !app?.user || !userId || !db) return null;
        assertCurrent(saved);
        cleanId(userId, 'user_id');
        if (table === 'profiles') return fetchProfile(saved);
        const result = await db.from(table).select('user_id,data').eq('user_id', userId).maybeSingle();
        assertCurrent(saved);
        if (result.error) {
            throw cloudFailure(result.error, `${table}.select`);
        }
        const row = result.data || null;
        if (row && row.user_id !== userId) throw cloudFailure({code:'42501'},`${table}.owner`);
        return row;
    }

    // Goals and transactions are rows keyed by id; other domains use per-user documents.
    const GOAL_FIELDS = ['id','title','description','category','priority','deadline','status','progress','tags','subgoals'];
    const GOAL_ALIASES = { parentId: 'parent_id', createdAt: 'created_at', updatedAt: 'updated_at', targetAmount: 'target_amount', currentAmount: 'current_amount', isCompleted: 'is_completed' };
    const GOAL_WRITE_FIELDS = ['id','title','description','priority','category','status','progress'];
    function goalArray(value, field) {
        if (value == null) return [];
        let parsed = value;
        if (typeof parsed === 'string') {
            try { parsed = JSON.parse(parsed); } catch { throw payloadFailure(field); }
        }
        if (!Array.isArray(parsed) || (field === 'tags' ? parsed.some(tag => typeof tag !== 'string') : parsed.some(step => !object(step)))) throw payloadFailure(field);
        return clone(parsed);
    }
    function goalToRow(goal, userId) {
        cleanId(goal.id);
        // Keep local/legacy metadata out of PostgREST's column inference.
        const row = { user_id: cleanId(userId, 'user_id') };
        for (const key of GOAL_WRITE_FIELDS) if (goal[key] !== undefined) row[key] = clone(goal[key]);
        for (const key of ['subgoals','tags']) if (goal[key] !== undefined) row[key] = goalArray(goal[key],key);
        const parentId = goal.parentId !== undefined ? goal.parentId : goal.parent_id;
        if (parentId !== undefined) row.parent_id = parentId === null ? null : cleanId(parentId,'parent_id');
        return cleanPayload(row);
    }
    function goalFromRow(row) {
        const goal = {};
        for (const key of GOAL_FIELDS) if (row[key] !== undefined) goal[key] = clone(row[key]);
        for (const [local, column] of Object.entries(GOAL_ALIASES)) if (row[column] !== undefined) goal[local] = clone(row[column]);
        return goal;
    }
    async function goalRows(userId, db = client, saved = scope()) {
        if (!session?.user?.id || !app?.user || !userId || !db) return [];
        assertCurrent(saved);
        const rows = [], pageSize = 500;
        for (let start = 0; ; start += pageSize) {
            const result = await db.from('goals').select('*').eq('user_id', userId).order('id').range(start, start + pageSize - 1);
            assertCurrent(saved);
            if (result.error) throw cloudFailure(result.error, 'goals.select');
            if ((result.data || []).some(row => row.user_id !== userId)) throw cloudFailure({code:'42501'},'goals.owner');
            rows.push(...(result.data || []));
            if ((result.data || []).length < pageSize) return rows;
        }
    }
    async function writeGoals(goals, previous, identity, saved = scope()) {
        assertCurrent(saved);
        if (ownerId() !== identity || localStorage.getItem(OWNER) !== identity) throw new Error('Аккаунт изменился.');
        const userId = cleanId(session.user.id, 'user_id');
        const goalsPayload = goals.map(goal => goalToRow(goal, userId));
        const ids = new Set(goalsPayload.map(goal => goal.id));
        if (ids.size !== goalsPayload.length) throw new Error('Обнаружены повторяющиеся ID целей.');
        const old = new Map(previous.map(row => [row.id, row]));
        const changed = goalsPayload.filter(row => {
            const before = old.get(row.id);
            return !before || Object.keys(row).some(key => !same(row[key], before[key]));
        });
        if (changed.length) {
            const result = await client.from('goals').upsert(changed, { onConflict: 'id', defaultToNull: false });
            assertCurrent(saved);
            if (result.error) throw cloudFailure(result.error, 'goals.upsert');
        }
        for (const row of previous) if (!ids.has(row.id)) {
            if (ownerId() !== identity || localStorage.getItem(OWNER) !== identity) throw new Error('Аккаунт изменился.');
            const result = await client.from('goals').delete().eq('user_id', userId).eq('id', row.id);
            assertCurrent(saved);
            if (result.error) throw cloudFailure(result.error, 'goals.delete');
        }
    }

    const TRANSACTION_FIELDS = ['id','type','amount','category','description','date'];
    const TRANSACTION_COLUMNS = 'id,user_id,type,amount,category,description,date';
    function transactionFromRow(row) {
        return Object.fromEntries(TRANSACTION_FIELDS.filter(key=>row[key] !== undefined).map(key=>[key,clone(row[key])]));
    }
    function transactionToRow(transaction,userId) {
        if (!object(transaction)) throw payloadFailure('transaction');
        const row = {id:cleanId(transaction.id),user_id:cleanId(userId,'user_id')};
        for (const key of TRANSACTION_FIELDS) if (key!=='id' && transaction[key] !== undefined) row[key]=clone(transaction[key]);
        if (row.amount !== undefined && (!Number.isFinite(row.amount) || row.amount<0)) throw payloadFailure('amount');
        if (row.type !== undefined && !['income','expense'].includes(row.type)) throw payloadFailure('type');
        return cleanPayload(row);
    }
    async function transactionRows(userId,db=client,saved=scope()) {
        assertCurrent(saved);
        const rows=[],pageSize=500;
        for(let start=0;;start+=pageSize) {
            const result=await db.from('finance_transactions').select(TRANSACTION_COLUMNS).eq('user_id',cleanId(userId,'user_id')).order('id').range(start,start+pageSize-1);
            assertCurrent(saved);
            if(result.error)throw cloudFailure(result.error,'finance_transactions.select');
            if((result.data||[]).some(row=>row.user_id!==userId))throw cloudFailure({code:'42501'},'finance_transactions.owner');
            rows.push(...(result.data||[]));
            if((result.data||[]).length<pageSize)return rows;
        }
    }
    async function writeTransactions(transactions,previous,identity,saved=scope()) {
        assertCurrent(saved);
        if(ownerId()!==identity)throw cloudFailure({code:'42501'},'finance_transactions.owner');
        const userId=saved.userId,payload=transactions.map(transaction=>transactionToRow(transaction,userId));
        const ids=new Set(payload.map(row=>row.id));
        if(ids.size!==payload.length)throw new Error('Обнаружены повторяющиеся ID транзакций.');
        const old=new Map(previous.map(row=>[row.id,row]));
        const changed=payload.filter(row=>!old.has(row.id)||Object.keys(row).some(key=>!same(row[key],old.get(row.id)[key])));
        if(changed.length) {
            const result=await saved.db.from('finance_transactions').upsert(changed,{onConflict:'id',defaultToNull:false});
            assertCurrent(saved);
            if(result.error)throw cloudFailure(result.error,'finance_transactions.upsert');
        }
        for(const row of previous)if(!ids.has(row.id)) {
            assertCurrent(saved);
            const result=await saved.db.from('finance_transactions').delete().eq('user_id',userId).eq('id',row.id);
            assertCurrent(saved);
            if(result.error)throw cloudFailure(result.error,'finance_transactions.delete');
        }
    }
    async function pullDirectState(saved = scope()) {
        assertCurrent(saved); const userId = cleanId(saved.userId,'user_id'), db = saved.db;
        const tables = ['profiles','goals','finance_transactions','safety_fund','user_profile'];
        const values = await Promise.all(tables.map(table => table === 'goals' ? goalRows(userId,db,saved) : table === 'finance_transactions' ? transactionRows(userId,db,saved) : tableRow(table,userId,db,saved)));
        let calendarRow = null;
        if (calendarMode !== 'legacy') {
            try { calendarRow = await tableRow('calendar_events',userId,db,saved); calendarMode = 'document'; }
            catch (error) { if (!['PGRST205','42P01'].includes(error.code)) throw error; calendarMode = 'legacy'; }
        }
        assertCurrent(saved);
        const rows = Object.fromEntries(tables.map((table,index) => [table,values[index]])); rows.calendar_events = calendarRow;
        const profileRow = rows.profiles, fullProfile = documentContent(rows.user_profile?.data);
        const { __goaltrackerSync:extras,...profile } = fullProfile || {};
        return { rows,revision:Number(profileRow?.revision || 0),exists:!!calendarRow || values.some(value => Array.isArray(value) ? value.length>0 : !!value),state:normalize({
            goals:rows.goals.map(goalFromRow),transactions:rows.finance_transactions.map(transactionFromRow),safetyFund:documentContent(rows.safety_fund?.data)||{},
            profile:fullProfile ? profile : profileRow?.extra?.profile || (profileRow ? {nickname:profileRow.nickname || profileRow.username || profileRow.handle || ''} : {}),
            financeOther:extras?.financeOther || profileRow?.extra?.financeOther || {},
            calendar:calendarRow ? documentContent(calendarRow.data) : extras?.calendar || profileRow?.extra?.calendar || {}
        }) };
    }

    async function writeDocument(table, data, previous, identity, saved = scope()) {
        assertCurrent(saved);
        if (ownerId() !== identity || localStorage.getItem(OWNER) !== identity) throw new Error('Аккаунт изменился.');
        if (previous && same(documentContent(previous.data), data)) return;
        const userId = cleanId(session.user.id, 'user_id');
        // Create-only upsert cannot overwrite a row inserted by another device.
        // Existing JSONB documents use a conditional update to preserve concurrent edits.
        const payload = versionedDocument(cleanPayload(data));
        let result;
        if (previous) {
            let query = client.from(table).update({ data: payload }).eq('user_id', userId);
            const old = previous.data;
            if (Array.isArray(old) && old.length === 0) query = query.eq('data', '[]');
            else {
                const versionPath = Array.isArray(old) ? `data->0->>${DOCUMENT_VERSION}` : `data->>${DOCUMENT_VERSION}`;
                const version = Array.isArray(old) ? old[0]?.[DOCUMENT_VERSION] : old?.[DOCUMENT_VERSION];
                query = version ? query.eq(versionPath, version) : query.is(versionPath, null);
                if (Array.isArray(old) && !version) query = query.neq('data', '[]');
            }
            result = await query.select('user_id');
        } else {
            result = await client.from(table).upsert({ user_id: userId, data: payload }, { onConflict: 'user_id', ignoreDuplicates: true }).select('user_id');
        }
        assertCurrent(saved);
        if (result.error) throw cloudFailure(result.error, `${table}.${previous ? 'update' : 'upsert'}`);
        if (!result.data?.length) throw cloudFailure({ code: '40001' }, `${table}.compare-and-swap`);
    }

    const rejectedProfileWrites = new WeakMap();
    async function upsertOwnedProfile(fields, options = {}, saved = scope()) {
        try {
            assertCurrent(saved);
            const { data, error } = await saved.db.auth.getUser();
            assertCurrent(saved);
            const user = data?.user;
            if (error || !user?.id) return { skipped: true, error: null };
            const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
            if (!uuid.test(user.id) || user.id !== saved.userId || user.id !== session?.user?.id) {
                return { skipped: true, error: null };
            }
            // Production profiles use id/username; short_id is generated by the server.
            // Full profile documents belong to user_profile, never this payload.
            const username = typeof fields?.username === 'string' ? fields.username.trim() : '';
            if (!username) return { skipped: true, error: null };
            const handle = String(fields?.handle || user.user_metadata?.ncd_handle || app?.user?.handle || (/^[a-z][a-z0-9_]{2,31}$/.test(username.toLowerCase()) ? username : 'user_' + user.id.replace(/-/g,'').slice(0,27))).trim().replace(/^@/, '').toLowerCase();
            if (!/^[a-z][a-z0-9_]{2,31}$/.test(handle)) return { error: { code:'22023', message:'Некорректный handle профиля' } };
            const payload = { id: user.id, username, handle };
            const rejected = rejectedProfileWrites.get(saved.db);
            if (rejected?.userId === user.id) return { error: rejected.error };
            const result = await saved.db.from('profiles').upsert(payload, { ...options, onConflict: 'id' });
            assertCurrent(saved);
            // A schema rejection cannot recover by polling the same endpoint.
            if (result.error && (result.status === 400 || ['PGRST204','42703','22P02'].includes(result.error.code))) {
                rejectedProfileWrites.set(saved.db, { userId:user.id, error:result.error });
            }
            return result;
        } catch (error) {
            return { error };
        }
    }

    async function pushDirectState(state, remote, identity, saved = scope()) {
        assertCurrent(saved);
        const profileData = { ...state.profile, __goaltrackerSync: { financeOther: state.financeOther, calendar: state.calendar } };
        await writeGoals(state.goals, remote.rows.goals, identity, saved);
        await writeTransactions(state.transactions,remote.rows.finance_transactions,identity,saved);
        for (const [table, data] of [['safety_fund',state.safetyFund],['user_profile',profileData]]) {
            await writeDocument(table, data, remote.rows[table], identity, saved);
        }
        if (calendarMode === 'document') await writeDocument('calendar_events',state.calendar,remote.rows.calendar_events,identity,saved);
        assertCurrent(saved);
        const profileRow = remote.rows.profiles;
        const value = { username: state.profile.nickname || 'Профиль' };
        if (!profileRow || (profileRow.username || profileRow.nickname) !== value.username) {
            const result = await upsertOwnedProfile(value, {}, saved);
            if (result.skipped) throw cloudFailure({code:'42501'}, 'profiles.auth');
            if (result.error) throw cloudFailure(result.error, 'profiles.upsert');
        }
    }

    async function saveSocialProfile(nickname = app?.user?.nickname, { preserveExisting = false } = {}) {
        const username = String(nickname || '').trim();
        if (transitioning || loggingOut || readyIdentity !== ownerId() || !client || !session || !app || username.length < 2 || username.length > 32) return false;
        const saved = scope();
        const pendingKey = `gt-social-profile-pending-v1:${ownerId()}`;
        if (!preserveExisting) write(pendingKey, { username });
        // Production social schema uses profiles(id, username, short_id, ...).
        // Upsert only owned fields so generated short_id and other server fields survive.
        if (!bootstrapIdentity) await tableRow('profiles', saved.userId, saved.db, saved);
        const result = await upsertOwnedProfile({ username }, { ignoreDuplicates: preserveExisting }, saved);
        if (result.skipped) return false;
        if (result.error) throw result.error;
        if (!preserveExisting) localStorage.removeItem(pendingKey);
        return true;
    }

    function restoreSocialProfile() {
        if (!session) return Promise.resolve(false);
        const pending = read(`gt-social-profile-pending-v1:${ownerId()}`, null);
        return saveSocialProfile(pending?.username || app?.user?.nickname, { preserveExisting: !pending });
    }

    async function pushGoals() {
        // All changes use the same merge/receipt path; never overwrite cloud goals independently.
        return sync();
    }

    function renderPulledState() {
        try { app.renderGoals(); } catch {}
        try { app.renderCalendar(); } catch {}
        try { window.renderFinanceView?.(); } catch {}
        try { app.renderProfile(); } catch {}
        try { app.updateGreeting(); } catch {}
    }

    async function bootstrapCloud(force = false) {
        if (!client || !session || !app) return false;
        if (transitioning || readyIdentity !== ownerId() || localStorage.getItem(OWNER) !== ownerId()) return acceptSession(session,true);
        return sync(force ? 'remote' : undefined);
    }

    function stopRealtime() {
        clearTimeout(realtimeTimer);
        const previous = dataChannel; dataChannel = null; realtimeIdentity = null;
        if (previous && client?.removeChannel) Promise.resolve(client.removeChannel(previous)).catch(() => {});
    }
    function startRealtime() {
        if (!client?.channel || !session || realtimeIdentity === ownerId()) return;
        stopRealtime();
        const identity = ownerId(), userId = session.user.id, saved = scope();
        realtimeIdentity = identity;
        dataChannel = client.channel(`goaltracker-data:${userId}`);
        const changed = () => {
            if (!current(saved) || readyIdentity !== identity || transitioning) return;
            clearTimeout(realtimeTimer);
            realtimeTimer = setTimeout(() => sync(), 150);
        };
        for (const table of ['goals','calendar_events','finance_transactions','safety_fund','user_profile','profiles']) {
            if (table === 'calendar_events' && calendarMode === 'legacy') continue;
            const column = table === 'profiles' ? 'id' : 'user_id';
            dataChannel = dataChannel.on('postgres_changes', { event: '*', schema: 'public', table, filter: `${column}=eq.${userId}` }, changed);
        }
        dataChannel.subscribe(state => {
            if (!current(saved)) return;
            if (state === 'SUBSCRIBED') changed();
            // A periodic direct read remains active when Realtime is unavailable.
        });
    }
    async function applyState(compute, saved = scope()) {
        assertCurrent(saved);
        if (appBusy()) return false;
        applying = true;
        const controls = [...document.querySelectorAll('button,input,textarea,select')].map(element => [element, element.disabled]);
        controls.forEach(([element]) => { element.disabled = true; });
        try {
            await window.ProfileStorage.flush?.();
            assertCurrent(saved);
            const before = capture(), next = normalize(compute(before));
            if (same(before, next) && app.user?.supabaseUserId === session.user.id) return true;
            const local = app.serialize();
            const financeBefore = window.finance?.getData?.() || read('goalTracker_finance', {});
            // Keep a reviewable local backup before any incoming cloud replacement.
            write(backupKey(), { savedAt: new Date().toISOString(), profile: local, finance: financeBefore, avatar: before.profile.customAvatarData });
            const data = { ...local, user: { ...(local.user || {}), nickname: next.profile.nickname || local.user?.nickname || session.user.email?.split('@')[0] || 'Профиль', status: next.profile.status || '', ...(next.profile.createdAt ? { createdAt: next.profile.createdAt } : {}) },
                goals: next.goals, notes: next.calendar.notes || {}, events: next.calendar.events || [], achievements: next.calendar.achievements || [] };
            if (!data.user.id) data.user.id = crypto.randomUUID();
            data.user.supabaseUserId = session.user.id;
            const finance = { ...next.financeOther, transactions: next.transactions, safetyFund: next.safetyFund };
            const avatarKey = `customAvatarData:${data.user.id || data.user.createdAt || 'local'}`;
            const avatar = next.profile.customAvatarData || '';
            if (avatar && (avatar.length > 200000 || !/^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(avatar))) throw new Error('Облачный аватар имеет неподдерживаемый формат.');
            try {
                localStorage.setItem('goalTracker_finance', JSON.stringify(finance));
                localStorage.setItem(avatarKey, avatar);
                await window.ProfileStorage.save(data);
                assertCurrent(saved);
            } catch (error) {
                localStorage.setItem('goalTracker_finance', JSON.stringify(financeBefore));
                localStorage.setItem(avatarKey, before.profile.customAvatarData || '');
                throw error;
            }
            app.loadData(); window.finance?.replaceData?.(finance); app.updateGreeting(); app.render();
            app.rescheduleAllNotifications?.().catch(() => {});
            return true;
        } finally {
            applying = false; controls.forEach(([element, disabled]) => { if (element.isConnected) element.disabled = disabled; });
        }
    }
    async function settleReceipt(meta, prefer, saved = scope()) {
        assertCurrent(saved);
        if (!meta.receipt) return true;
        let merged;
        const applied = await applyState(now => {
            merged = merge(meta.receipt.before, now, meta.receipt.accepted, prefer);
            if (merged.conflicts.length) { conflict = true; throw new Error('Локальные правки пересеклись с входящей синхронизацией. Повторите синхронизацию.'); }
            return merged.value;
        },saved);
        assertCurrent(saved);
        if (applied) { delete meta.receipt; write(metaKey(), meta); }
        return applied;
    }
    function sync(prefer) {
        if (syncWork) { rerunSync = true; return syncWork; }
        const work = performSync(prefer); syncWork = work;
        work.finally(() => { if (syncWork === work) syncWork = null; }).catch(() => {});
        return work;
    }
    async function performSync(prefer) {
        if (!client || !session || !app || transitioning || loggingOut || readyIdentity !== ownerId()) return false;
        if (busy || applying) { rerunSync = true; return false; }
        const identity = ownerId(), saved = scope();
        if (localStorage.getItem(OWNER) !== identity) { setTimeout(() => acceptSession(session,true),0); return false; }
        if (navigator.onLine === false) { status('Офлайн: данные остаются на устройстве.'); return false; }
        if (appBusy()) { clearTimeout(timer); timer = setTimeout(() => sync(prefer), 1000); return false; }
        busy = true; conflict = false; syncDiagnostic = ''; status('Синхронизация…');
        let operation = 'tables.select';
        try {
            let meta = read(metaKey(), { base: null, revision: 0 });
            if (!await settleReceipt(meta, prefer, saved)) { status('Ожидание завершения локального сохранения.'); return false; }
            const response = await pullDirectState(saved);
            if (app._resetting || ownerId() !== identity || localStorage.getItem(OWNER) !== identity) throw new Error('Аккаунт изменился. Синхронизация прервана.');
            const remote = validateState(response.state), local = validateState(capture());
            const initialBase = response.exists && localEmpty(local) ? clone(local) : empty();
            if (!meta.base && response.exists && Object.keys(remote.profile).length) initialBase.profile = clone(local.profile);
            const base = meta.base || initialBase;
            const pending = merge(base, local, remote);
            previews = pending.conflicts.map(path => {
                const get = state => path.split('/').slice(1).reduce((value, key) => Array.isArray(value) ? value.find(item => item.id === key) : value?.[key], state);
                const describe = value => path.includes('customAvatarData') ? (value ? 'Фото профиля' : 'Без фото') : path === '/safetyFund' ? `Баланс: ${value?.balance || 0}, пополнений: ${value?.history?.length || 0}` : value === undefined ? 'Удалено' : JSON.stringify(value).slice(0, 250);
                return `${path.split('/').at(-1)} · На устройстве: ${describe(get(local))} · В облаке: ${describe(get(remote))}`;
            });
            if (prefer && pending.conflicts.length) write(`gt-cloud-conflict-backup-v1:${identity}`, { savedAt: new Date().toISOString(), base, local, remote });
            const merged = prefer ? merge(base, local, remote, prefer) : pending;
            if (merged.conflicts.length) { conflict = true; status(`Обнаружены пересекающиеся изменения (${merged.conflicts.length}). Выберите версию спорных полей.`); return false; }
            operation = 'tables.write';
            await pushDirectState(merged.value, response, identity, saved);
            const confirmed = await pullDirectState(saved);
            const accepted = validateState(confirmed.state);
            const revision = confirmed.revision;
            if (app._resetting || ownerId() !== identity || localStorage.getItem(OWNER) !== identity) throw new Error('Аккаунт изменился. Данные сохранены в прежнем аккаунте; локальный профиль не заменён.');
            // Receipt is durable before applying: edits made while the request was in flight survive.
            meta = { base: accepted, revision, receipt: { before: local, accepted } };
            write(metaKey(), meta);
            if (!await settleReceipt(meta, prefer, saved)) { status('Облако сохранено. Ожидание локального сохранения.'); timer = setTimeout(() => sync(prefer), 1000); return false; }
            assertCurrent(saved);
            renderPulledState();
            if (same(capture(),meta.base)) savePending(identity,null);
            startRealtime();
            status('Синхронизировано · ' + new Date().toLocaleTimeString('ru-RU'));
            if (!same(capture(), meta.base)) localChanged();
            return true;
        } catch (error) {
            if (!current(saved)) return false;
            // Do not log responses, tokens, profile content or credentials.
            const code = /^(?:PGRST\d{3}|[0-9A-Z]{5})$/.test(error?.code || '') ? error.code : '';
            syncDiagnostic = code ? `Код: ${code} · Операция: ${error.operation || operation}` : error.payloadField ? `Некорректное поле: ${error.payloadField}. Отправка остановлена; данные сохранены на устройстве.` : '';
            if (code === '40001') { clearTimeout(timer); timer = setTimeout(() => sync(prefer), 150); }
            // Keep direct REST failures visible; never report a partial write as synchronized.
            status(conflict ? 'Локальные и облачные правки пересеклись. Выберите версию спорных полей.' : 'Синхронизация не завершена. Локальные данные сохранены. Повторите попытку; если ошибка сохраняется, проверьте доступ к данным в Supabase.');
            return false;
        } finally {
            busy = false; refresh();
            if (rerunSync && current(saved) && !transitioning && !loggingOut) { rerunSync = false; clearTimeout(timer); timer = setTimeout(() => sync(),0); }
        }
    }
    function acceptSession(next, force = false, quiet = true, onOpened = null) {
        if (!next?.user?.id) next = null;
        if (loggingOut) return Promise.resolve(false);
        const identity = next?.user?.id ? `${config.url}|${next.user.id}` : null;
        // While the user is filling in auth, SDK/focus/reconnect events must not
        // start a profile load. Explicit successful authentication passes quiet=false.
        if (quiet && next && readyIdentity !== identity && document.getElementById('cloudAuthModal')?.classList.contains('active')) return Promise.resolve(false);
        if (!force && identity === desiredIdentity && sessionLoad) { session = next; return sessionLoad; }
        if (!force && next && readyIdentity === identity && localStorage.getItem(OWNER) === identity) { session = next; return Promise.resolve(true); }
        if (!next && settledNoSession && !app.user && !sessionLoad) return Promise.resolve(false);
        const owned = !!identity && app.user?.supabaseUserId === next.user.id && (!localStorage.getItem(OWNER) || localStorage.getItem(OWNER) === identity);
        const previousMeta = identity ? read(`gt-cloud-state-v1:${identity}`,{}) : {};
        let pending = identity ? read(pendingKey(identity),null) : null;
        if (owned && !pending && previousMeta.base && !same(previousMeta.base,capture())) pending = { base:previousMeta.base,local:capture() };
        if (!owned) pending = null;
        let opened = false, openingState = null;
        const openBeforeSync = !!next;
        const epoch = ++accountEpoch; session = next; desiredIdentity = identity; readyIdentity = null; transitioning = true; settledNoSession = false;
        stopAccountRequests(); conflict = false; bindNeeded = false; previews = []; syncDiagnostic = ''; app._accountTransition = true; if (!openBeforeSync) app.showAccountLoading?.();
        const openWorkspace = () => {
            openingState = capture(); opened = true; app._accountTransition = false;
            authNotice = ''; authSuccess = false; closeAuth(); app.showApp();
            onOpened?.(true);
        };
        // The owned cache is already loaded by app.init(); no queue, disk write or network may delay it.
        if (owned && openBeforeSync) openWorkspace();
        status(next ? 'Загружаем данные аккаунта…' : 'Войдите в облачный аккаунт.');
        const work = accountQueue.catch(() => {}).then(async () => {
            if (epoch !== accountEpoch) return false;
            if (syncWork) await syncWork.catch(() => {});
            await pendingWrites.catch(() => {}); await tokenWrites.catch(() => {});
            const start = Date.now();
            while (appBusy()) { if (Date.now()-start > 16000) throw new Error('Дождитесь завершения текущего действия и повторите вход.'); await new Promise(resolve => setTimeout(resolve,20)); }
            if (epoch !== accountEpoch) return false;
            if (owned && !pending && nativePreferences) {
                const stored = await preferences.get({ key:pendingKey(identity) });
                if (stored.value) pending = JSON.parse(stored.value);
            }
            if (!owned) app.clearAccountMemory?.();
            await app.cancelAllNotifications?.();
            if (!owned) await clearUserCaches({ keepAuth:true });
            if (epoch !== accountEpoch) return false;
            if (!next) {
                settledNoSession = true; transitioning = false; app._accountTransition = false;
                app.showAuth(); return false;
            }
            localStorage.setItem(OWNER,identity); calendarMode = null;
            const metadata = next.user.user_metadata || {};
            if (!owned) app.user = { id:next.user.id,supabaseUserId:next.user.id,nickname:metadata.ncd_handle || metadata.username || metadata.nickname || next.user.email?.split('@')[0] || 'Профиль',createdAt:next.user.created_at || new Date().toISOString() };
            app.settings.autoSync = true;
            if (openBeforeSync && !opened) openWorkspace();
            app.user.shortId = null;
            await window.ProfileStorage.save(app.serialize());
            if (navigator.onLine === false) throw cloudFailure({code:'FETCH_ERROR'},'account.pull');
            const saved = scope();
            // Yield to the visible local workspace before starting network hydration.
            await new Promise(resolve => setTimeout(resolve, 0));
            assertCurrent(saved);
            const response = await withCloudTimeout(async () => {
                const response = await pullDirectState(saved);
                if (!response.rows.profiles || !response.rows.profiles.handle) {
                    // Missing rows are normal on first login. Insert only the owned profile,
                    // without replacing a profile concurrently created by another device.
                    const nickname = response.rows.profiles?.username || response.state.profile?.nickname || app.user.nickname;
                    const hadProfile = !!response.rows.profiles;
                    const handle = next.user.user_metadata?.ncd_handle;
                    const profile = { username:nickname };
                    if (typeof handle === 'string' && /^[a-z][a-z0-9_]{2,31}$/.test(handle)) profile.handle = handle;
                    const created = await upsertOwnedProfile(profile, {}, saved);
                    if (created.skipped) throw cloudFailure({code:'42501'}, 'profiles.auth');
                    if (created.error) throw cloudFailure(created.error, 'profiles.upsert');
                    response.rows.profiles = await tableRow('profiles',next.user.id,saved.db,saved);
                    if (!hadProfile) response.state.profile = { ...response.state.profile, nickname:response.rows.profiles?.username || response.rows.profiles?.nickname || nickname };
                }
                return response;
            }, saved);
            const remote = validateState(response.state);
            assertCurrent(saved);
            let incoming = remote;
            if (owned && pending) incoming = merge(validateState(pending.base),validateState(pending.local),remote,'remote').value;
            if (opened) incoming = merge(openingState,capture(),incoming,'local').value;
            write(metaKey(),{ base:remote,revision:response.revision });
            if (!await applyState(() => incoming,saved)) throw new Error('Не удалось применить данные аккаунта. Повторите вход.');
            app.user.handle = response.rows.profiles?.handle;
            assertCurrent(saved); readyIdentity = identity; bootstrapIdentity = identity; transitioning = false; app._accountTransition = false;
            if (!same(incoming,remote)) savePending(identity,{ base:remote,local:incoming }); else savePending(identity,null);
            app.showApp(); renderPulledState(); startRealtime();
            clearInterval(polling); polling = setInterval(() => sync(),5000);
            status('Синхронизировано · ' + new Date().toLocaleTimeString('ru-RU'));
            if (!same(capture(),remote)) localChanged();
            return true;
        }).catch(error => {
            if (epoch !== accountEpoch) return false;
            readyIdentity = null; transitioning = false; app._accountTransition = false;
            if (opened) {
                savePending(identity,{ base:pending?.base || openingState, local:capture() });
                syncDiagnostic = error.code ? `Код: ${error.code} · Операция: ${error.operation || 'account.pull'}` : '';
                authNotice = ''; authSuccess = false;
                status('Сессия активна. Данные пока не синхронизированы.');
                return false;
            }
            app.clearAccountMemory?.();
            syncDiagnostic = error.code ? `Код: ${error.code} · Операция: ${error.operation || 'account.pull'}` : '';
            const modal = document.getElementById('cloudAuthModal');
            document.getElementById('app').style.display = 'none'; document.getElementById('appSplash')?.setAttribute('hidden','');
            modal.classList.add('active'); modal.dataset.entry = 'true'; document.body.classList.add('ncd-auth-open');
            // Data-sync failures belong to the cloud status, not to credential errors.
            authNotice = ''; authSuccess = false; setAuthStep('email'); refresh();
            status('Не удалось загрузить данные аккаунта. Повторите попытку.'); return false;
        });
        accountQueue = work; sessionLoad = work;
        work.finally(() => { if (sessionLoad === work) sessionLoad = null; });
        return work;
    }
    async function withCloudTimeout(work, saved) {
        let timeout;
        try {
            return await Promise.race([
                Promise.resolve().then(work),
                new Promise((_, reject) => {
                    timeout = setTimeout(() => {
                        saved.cancelled = true;
                        reject(cloudFailure({code:'FETCH_ERROR'}, 'account.timeout'));
                    }, 2500);
                })
            ]);
        } finally { clearTimeout(timeout); }
    }
    async function boundedFetch(input, options = {}) {
        const controller = new AbortController();
        const abort = () => controller.abort();
        if (options.signal?.aborted) controller.abort();
        else options.signal?.addEventListener('abort', abort, { once: true });
        activeRequests.add(controller);
        const timeout = setTimeout(abort, 2500);
        try { return await window.fetch(input, { ...options, cache:'no-store', signal: controller.signal }); }
        finally { activeRequests.delete(controller); clearTimeout(timeout); options.signal?.removeEventListener('abort', abort); }
    }
    function tokenKeys() {
        const project = new URL(config.url).hostname.replace(/[^a-z0-9.-]/gi, '_');
        return {
            access: `tokens.${project}.access_token`,
            refresh: `tokens.${project}.refresh_token`
        };
    }
    function persistSessionTokens(next) {
        const cycle = authCycle;
        const work = tokenWrites.catch(() => {}).then(async () => { if (next && (loggingOut || cycle !== authCycle)) return; await writeSessionTokens(next); });
        tokenWrites = work; return work;
    }
    async function writeSessionTokens(next) {
        const keys = tokenKeys();
        if (next?.access_token && next?.refresh_token) {
            await Promise.all([
                authStorage.setItem(keys.access, next.access_token),
                authStorage.setItem(keys.refresh, next.refresh_token)
            ]);
        } else if (!next) {
            await Promise.all([
                authStorage.removeItem(keys.access),
                authStorage.removeItem(keys.refresh)
            ]);
        }
    }
    async function restoreSessionTokens() {
        const keys = tokenKeys();
        const [access_token, refresh_token] = await Promise.all([
            authStorage.getItem(keys.access),
            authStorage.getItem(keys.refresh)
        ]);
        if (!access_token || !refresh_token) return null;
        const result = await client.auth.setSession({ access_token, refresh_token });
        if (result.error) throw result.error;
        return result.data.session;
    }
    function initialize() {
        if (initializing) return initializing;
        if (client || !app || loggingOut) return Promise.resolve();
        const work = initializeClient(); initializing = work;
        work.finally(() => { if (initializing === work) initializing = null; }).catch(() => {});
        return work;
    }
    async function initializeClient() {
        try {
            const saved = read(CONFIG, window.SupabaseConfig || null);
            if (!saved) {
                await Promise.resolve();
                if (!document.getElementById('cloudAuthModal')?.classList.contains('active')) app.showAuth();
                return;
            }
            config = validateConfig(saved.url, saved.key);
            if (!window.supabase?.createClient) throw new Error('SDK unavailable');
            if (singleton.instance && (singleton.url !== config.url || singleton.key !== config.key)) throw new Error('SUPABASE_RESTART_REQUIRED');
            singleton.generation = ++sdkEpoch;
            if (nativePreferences && (await preferences.get({key:LOCK})).value === 'true') localStorage.setItem(LOCK,'true');
            const ownedAuthStorage = {
                getItem: key => singleton.generation === sdkEpoch && localStorage.getItem(LOCK) !== 'true' ? authStorage.getItem(key) : Promise.resolve(null),
                setItem: (key,value) => {
                    if (singleton.generation !== sdkEpoch || (localStorage.getItem(LOCK) === 'true' && !authPending)) return Promise.resolve();
                    if (!authPending && session?.user?.id) {
                        let owner; try { owner = JSON.parse(value)?.user?.id; } catch {}
                        if (owner && owner !== session.user.id) return Promise.resolve();
                    }
                    return authStorage.setItem(key,value);
                },
                // Refresh failures must not erase the durable login. Logout owns deletion.
                removeItem: key => singleton.generation === sdkEpoch && loggingOut ? authStorage.removeItem(key) : Promise.resolve()
            };
            if (!singleton.instance) {
                singleton.instance = window.supabase.createClient(config.url, config.key, { global: { fetch: boundedFetch }, auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false, storage: ownedAuthStorage, storageKey: `gt-supabase-auth:${config.url}` } });
                singleton.url=config.url; singleton.key=config.key;
            }
            client = singleton.instance;
            const db = client, cycle = authCycle;
            subscription = client.auth.onAuthStateChange((event, next) => {
                const eventCycle = authCycle;
                // SDK auth callbacks must not await SDK operations (avoids auth lock deadlocks).
                setTimeout(() => {
                    if (db !== client || eventCycle !== authCycle || loggingOut) return;
                    if (initializing && next) return; // Startup restoration owns the first workspace open.
                    if (event === 'TOKEN_REFRESHED' && next?.user?.id && session?.user?.id && next.user.id !== session.user.id) return;
                    if (event === 'SIGNED_OUT' || !next) return; // Only logout() clears the account and tokens.
                    if (localStorage.getItem(LOCK) === 'true') return;
                    if (next) persistSessionTokens(next).catch(() => {});
                    // Only explicit logout clears our backup tokens; startup/refresh errors must retain them.
                    acceptSession(next, false, true).catch(() => status('Облачная сессия недоступна. Локальная работа продолжается.'));
                }, 0);
            });
            if (localStorage.getItem(LOCK) === 'true') { await client.auth.stopAutoRefresh?.(); await acceptSession(null); return; }
            await resumeStoredSession(db, cycle);
        } catch {
            sessionError = true; authNotice = ''; authSuccess = false;
            // An unavailable session store/network is not evidence of logout.
            showStartupFallback(); refresh(); status(connectionState().text);
        }
    }
    async function resumeStoredSession(db = client, cycle = authCycle) {
        if (!db || loggingOut || localStorage.getItem(LOCK) === 'true') return;
        try {
            // SDK getSession may refresh an expired access token over the network.
            // Render the persisted account first, then let that refresh run in the background.
            if (!session) {
                const cached = await authStorage.getItem(`gt-supabase-auth:${config.url}`);
                let stored; try { stored = JSON.parse(cached || 'null'); } catch {}
                if (stored?.user?.id && stored.access_token && stored.refresh_token) {
                    await new Promise((resolve, reject) => {
                        acceptSession(stored, false, false, resolve).then(resolve, reject);
                    });
                }
            }
            const { data, error } = await withCloudTimeout(() => db.auth.getSession(), {});
            if (error) throw error;
            const restored = data?.session || await restoreSessionTokens();
            if (db !== client || cycle !== authCycle || loggingOut) return;
            sessionError = false;
            if (restored?.user?.id) {
                persistSessionTokens(restored).catch(() => {});
                // Open the owned workspace first; hydration continues in the background.
                await new Promise((resolve, reject) => {
                    acceptSession(restored, false, false, resolve).then(resolve, reject);
                });
            } else await acceptSession(null);
            clearInterval(polling); polling = setInterval(() => sync(),5000);
        } catch {
            if (db !== client || cycle !== authCycle || loggingOut) return;
            sessionError = true; authNotice = ''; authSuccess = false;
            if (!session) showStartupFallback();
            status(connectionState().text);
        }
    }

    async function configure(url, key) {
        if (initializing) await initializing;
        if (session || busy) throw new Error('Сначала выйдите из облачного аккаунта.');
        const value = validateConfig(url.trim(), key.trim());
        const owner = localStorage.getItem(OWNER);
        if (owner && !owner.startsWith(value.url + '|')) throw new Error('Устройство связано с другим проектом. Используйте отдельный профиль браузера.');
        if (singleton.instance && (singleton.url!==value.url || singleton.key!==value.key)) {
            write(CONFIG,value);
            throw new Error('Настройки Supabase сохранены. Перезапустите приложение, чтобы сменить проект.');
        }
        if (client && config?.url===value.url && config?.key===value.key) { write(CONFIG,value); return; }
        write(CONFIG, value); stopRealtime(); subscription?.data?.subscription?.unsubscribe(); client = null; config = value;
        await initialize();
    }
    function validAuthEmail(value) {
        const email = String(value || '').trim();
        if (email.length > 254 || /\s/.test(email)) return false;
        const parts = email.split('@');
        if (parts.length !== 2) return false;
        const [local, domain] = parts;
        if (!local || local.length > 64 || !/^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+$/i.test(local) || local.startsWith('.') || local.endsWith('.') || local.includes('..')) return false;
        const labels = domain.split('.');
        return labels.length >= 2 && labels.every(label => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/i.test(label)) && /^(?:[a-z]{2,63}|xn--[a-z0-9-]{2,59})$/i.test(labels.at(-1));
    }
    async function existingAuthSession(db) {
        if (loggingOut || localStorage.getItem(LOCK) === 'true') return null;
        if (session?.user?.id) return session;
        const { data, error } = await db.auth.getSession();
        if (error) throw new Error(authErrorMessage(error));
        return data?.session?.user?.id ? data.session : null;
    }
    async function openAuthenticatedSession(next) {
        localStorage.removeItem(LOCK);
        if (nativePreferences) await preferences.remove({key:LOCK});
        await persistSessionTokens(next);
        await client.auth.startAutoRefresh?.();
        const hydrated = await new Promise((resolve, reject) => {
            acceptSession(next, false, false, resolve).then(resolve, reject);
        });
        closeAuth();
        return {confirmationRequired:false, hydrated};
    }
    async function authenticate(email, password, signUp, registration = null) {
        if (!validAuthEmail(email)) throw new Error('Введите корректный email (например, you@example.com)');
        email = email.trim();
        if (loggingOut || logoutWork) throw new Error('Дождитесь завершения выхода.');
        await initialize();
        if (!client) throw new Error('Подключение к облаку временно недоступно. Повторите попытку.');
        const db = client, cycle = authCycle;
        const restored = await existingAuthSession(db);
        if (cycle !== authCycle || db !== client || loggingOut) throw new Error('Сессия изменилась. Повторите вход.');
        if (restored) return openAuthenticatedSession(restored);
        if (String(password || '').length < 8) throw new Error('Пароль должен быть не менее 8 символов');
        const attempt = ++authCycle;
        const handle = signUp && registration ? normalizeAuthNickname(registration.nickname) : null;
        if (handle && !await checkAuthNickname(handle)) throw new Error(HANDLE_TAKEN);
        const method = signUp ? 'signUp' : 'signInWithPassword';
        const credentials = signUp
            ? { email, password, options: { data: { username: handle || app?.user?.nickname || '', nickname: handle || app?.user?.nickname || '', ...(handle ? { ncd_handle: handle } : {}) } } }
            : { email, password };
        let result; authPending = true;
        try { result = await db.auth[method](credentials); } catch (error) { throw new Error(authErrorMessage(error, signUp)); } finally { authPending = false; }
        if (attempt !== authCycle || db !== client || loggingOut) throw new Error('Сессия изменилась. Повторите вход.');
        if (signUp && result.error) throw new Error(authErrorMessage(result.error, true));
        // With email confirmation enabled Supabase may hide duplicate accounts
        // behind a successful signup response with an empty identities array.
        const duplicate = signUp && (
            (!result.error && !result.data?.session && Array.isArray(result.data?.user?.identities) && result.data.user.identities.length === 0)
        );
        if (duplicate) {
            authPending = true;
            try {
                const restored = await existingAuthSession(db);
                result = restored ? { data:{session:restored}, error:null } : await db.auth.signInWithPassword({ email,password });
            } catch (error) { throw new Error(authErrorMessage(error)); } finally { authPending = false; }
            if (result.error) {
                throw new Error(authErrorMessage(result.error));
            }
            if (!result.data?.session) throw new Error('Этот email уже занят, пожалуйста, войдите.');
        }
        // Reuse the submitted credentials once; never ask the user to type them again.
        if (signUp && !duplicate && !result.error && !result.data?.session) {
            authPending = true;
            try {
                const restored = await existingAuthSession(db);
                const login = restored ? { data:{session:restored}, error:null } : await db.auth.signInWithPassword({ email, password });
                if (attempt !== authCycle || db !== client || loggingOut) throw new Error('Сессия изменилась. Повторите вход.');
                if (login.error?.code === 'email_not_confirmed') {
                    authNotice = 'Подтвердите адрес по ссылке в письме.';
                } else if (login.error) throw new Error(authErrorMessage(login.error));
                else if (login.data?.session) result = login;
            } catch (error) {
                throw error;
            } finally { authPending = false; }
        }
        if (result.error && handle && !isAuthNetworkError(result.error) && !await checkAuthNickname(handle)) throw new Error(HANDLE_TAKEN);
        if (result.error) throw new Error(authErrorMessage(result.error, signUp));
        if (result.data?.session) {
            if (attempt !== authCycle || db !== client || loggingOut) throw new Error('Сессия изменилась. Повторите вход.');
            return openAuthenticatedSession(result.data.session);
        }
        else { authNotice = 'Подтвердите регистрацию по ссылке в письме.'; authSuccess = true; status(authNotice); }
        return { confirmationRequired: !result.data?.session };
    }
    function logout() {
        if (logoutWork) return logoutWork;
        const db = client; loggingOut = true; authCycle++; accountEpoch++; localStorage.setItem(LOCK,'true'); readyIdentity = null; desiredIdentity = null;
        session = null; conflict = false; bindNeeded = false; previews = []; syncDiagnostic = ''; transitioning = true; app._accountTransition = true; stopAccountRequests();
        subscription?.data?.subscription?.unsubscribe(); subscription = null; app.showAccountLoading?.();
        status('Выход из аккаунта…');
        const work = (async () => {
            let clean = false;
            try {
                if (nativePreferences) { try { await preferences.set({key:LOCK,value:'true'}); } catch {} }
                await db?.auth.stopAutoRefresh?.();
                try { await db?.auth.signOut({ scope:'local' }); } catch { /* Local erasure is required even without the network. */ }
                if (db) rejectedProfileWrites.delete(db);
                if (syncWork) await syncWork.catch(() => {});
                await accountQueue.catch(() => {}); await tokenWrites.catch(() => {}); await pendingWrites.catch(() => {});
                const start = Date.now(); while (appBusy()) { if (Date.now()-start > 16000) throw new Error('Не удалось завершить очистку. Повторите выход.'); await new Promise(resolve => setTimeout(resolve,20)); }
                app.clearAccountMemory?.(); await app.cancelAllNotifications?.();
                await clearUserCaches(); clean = true;
            } finally {
                sdkEpoch++; client = null; session = null; readyIdentity = null; desiredIdentity = null; bootstrapIdentity = null; sessionLoad = null;
                transitioning = false; loggingOut = false; app._accountTransition = false; settledNoSession = clean; busy = false; applying = false; rerunSync = false; calendarMode = null; initializing = null;
                app.clearAccountMemory?.(); app.showAuth();
                if (!clean) { authNotice = 'Не удалось полностью очистить хранилище. Повторите выход перед сменой аккаунта.'; authSuccess = false; refresh(); }
            }
            return true;
        })();
        logoutWork = work; work.finally(() => { if (logoutWork === work) logoutWork = null; }).catch(() => {});
        return work;
    }
    let authNotice = '', authSuccess = false;
    function normalizeAuthNickname(value) {
        const name = String(value || '').trim().replace(/^@+/, '').toLowerCase();
        if (!/^[a-z][a-z0-9_]{2,31}$/.test(name)) throw new Error('Используйте 3–32 символа: латинские буквы, цифры и _. Начните с буквы.');
        return name;
    }
    async function checkAuthEmail(value) {
        const email = String(value || '').trim().toLowerCase();
        if (!validAuthEmail(email)) throw new Error('Введите корректный email (например, you@example.com)');
        if (!client) await initialize();
        if (!client) throw new Error('Подключение к облаку временно недоступно. Повторите попытку.');
        try {
            const { data, error } = await client.rpc('ncd_email_available', { check_email: email });
            if (error) throw error;
            if (typeof data !== 'boolean') throw new Error('Invalid availability response');
            return data;
        } catch (error) {
            throw new Error(isAuthNetworkError(error) ? 'Проверьте подключение' : 'Проверка email временно недоступна. Повторите попытку.');
        }
    }

    const HANDLE_TAKEN = 'Этот никнейм уже занят. Придумайте другой';
    async function checkAuthNickname(value) {
        const nickname = normalizeAuthNickname(value);
        if (!client) await initialize();
        if (!client) throw new Error('Подключение к облаку временно недоступно. Повторите попытку.');
        const db = client;
        try {
            const { data, error } = await db.from('profiles').select('handle').eq('handle', nickname).maybeSingle();
            if (error && !['42501','PGRST301','PGRST302'].includes(error.code)) throw error;
            if (db !== client) throw new Error('Подключение изменилось. Повторите проверку.');
            if (!error && data !== null && data !== undefined) return false;
            // Empty SELECT can mean RLS hid a taken handle. Only the server may confirm availability.
            const verified = await db.rpc('ncd_handle_available', { candidate:nickname });
            if (verified.error) throw verified.error;
            if (db !== client || typeof verified.data !== 'boolean') throw new Error('Invalid availability response');
            return verified.data;
        } catch (error) {
            throw new Error(isAuthNetworkError(error) ? 'Проверьте подключение' : 'Проверка никнейма временно недоступна. Повторите попытку.');
        }
    }
    let nicknameCheckVersion = 0, nicknameCheckTimer;
    let nicknameAvailability = { value:'', state:'idle' };
    function updateNicknameAvailability(form) {
        const input = form.querySelector('[name="nickname"]');
        const status = form.querySelector('[data-nickname-status]');
        const active = form.dataset.step === 'profile';
        const valid = nicknameAvailability.value === input.value && nicknameAvailability.state === 'available';
        const invalid = ['taken','invalid','error'].includes(nicknameAvailability.state);
        input.setAttribute('aria-invalid', String(invalid));
        if (status) {
            status.textContent = nicknameAvailability.message || '';
            status.classList.toggle('is-error', invalid);
            status.classList.toggle('is-success', valid);
        }
        form.querySelector('[type="submit"]').disabled = !!form.dataset.saving || (active && !valid);
    }
    async function checkNicknameLive(form) {
        clearTimeout(nicknameCheckTimer);
        const version = ++nicknameCheckVersion;
        const input = form.querySelector('[name="nickname"]');
        const value = input.value;
        let handle;
        try { handle = normalizeAuthNickname(value); }
        catch (error) {
            nicknameAvailability = { value, state:value ? 'invalid' : 'idle', message:value ? error.message : '' };
            updateNicknameAvailability(form); return;
        }
        nicknameAvailability = { value, state:'checking', message:'Проверяем никнейм…' };
        updateNicknameAvailability(form);
        try {
            const available = await checkAuthNickname(handle);
            if (version !== nicknameCheckVersion || input.value !== value || form.dataset.step !== 'profile') return;
            nicknameAvailability = { value, state:available ? 'available' : 'taken', message:available ? 'Никнейм свободен' : HANDLE_TAKEN };
        } catch (error) {
            if (version !== nicknameCheckVersion || input.value !== value || form.dataset.step !== 'profile') return;
            nicknameAvailability = { value, state:'error', message:error.message };
        }
        updateNicknameAvailability(form);
    }
    function isAuthNetworkError(error) {
        return navigator.onLine === false || error?.name === 'AuthRetryableFetchError' ||
            /fetch|network|connection|offline|timeout|timed out/i.test(`${error?.name || ''} ${error?.code || ''} ${error?.message || ''}`);
    }
    function authErrorMessage(error, signup = false) {
        // Preserve the provider's diagnosis. The UI renders this with textContent.
        return error?.message || error?.code || (signup ? 'Не удалось зарегистрироваться.' : 'Не удалось войти.');
    }

    function setAuthStep(step, focus = true) {
        const modal = document.getElementById('cloudAuthModal'), form = modal.querySelector('form');
        const signup = form.querySelector('[value="signup"]').checked, recovery = form.dataset.recovery === 'true';
        const previousStep = form.dataset.step;
        form.dataset.step = step;
        form.querySelectorAll('[data-auth-stage]').forEach(panel => {
            panel.hidden = panel.dataset.authStage !== step;
            panel.querySelectorAll('input').forEach(input => { input.disabled = panel.hidden; input.required = !panel.hidden; });
        });
        form.querySelector('.cloud-auth-mode').hidden = step !== 'email' || recovery;
        const password = form.querySelector('[name="password"]');
        password.autocomplete = signup ? 'new-password' : 'current-password';
        if (step !== 'password') {
            password.value = ''; password.type = 'password';
            const reveal = form.querySelector('[data-auth-show-password]');
            reveal.textContent = 'Показать'; reveal.setAttribute('aria-pressed','false'); reveal.setAttribute('aria-label','Показать пароль');
        }
        form.querySelector('[data-cloud-forgot]').hidden = recovery || signup || step !== 'password';
        form.querySelector('[data-cloud-back]').hidden = !recovery;
        modal.querySelector('[data-auth-prev]').hidden = recovery || step === 'email' || step === 'confirm';
        const label = { email: recovery ? 'Восстановить доступ' : 'Ваша почта', profile:'Как вас найти?', password:signup ? 'Создайте пароль' : 'С возвращением', confirm:'Проверьте почту' };
        const descriptions = { email:recovery ? 'Отправим письмо с инструкцией по сбросу пароля.' : 'Один аккаунт для ваших целей, заметок и планов.', profile:'Выберите уникальный никнейм. Игровой ID будет создан автоматически.', password:signup ? 'Не менее 8 символов. Пароль известен только вам.' : 'Введите пароль, чтобы открыть своё пространство.', confirm:form.querySelector('[name="email"]').value };
        document.getElementById('cloudAuthTitle').textContent = label[step];
        form.querySelector('[data-auth-description]').textContent = descriptions[step];
        form.querySelector('[data-auth-edit-email]').textContent = form.querySelector('[name="email"]').value;
        form.querySelector('[type="submit"]').innerHTML = step === 'confirm' ? 'Войти после подтверждения' : recovery ? 'Отправить письмо' : step === 'password' ? (signup ? 'Создать аккаунт' : 'Войти') : 'Продолжить <span aria-hidden="true">→</span>';
        const order = signup ? ['email','profile','password'] : ['email','password'];
        const progress = modal.querySelector('[data-auth-progress]'); progress.hidden = recovery || step === 'confirm';
        progress.querySelectorAll('li').forEach((dot,index) => {
            dot.hidden = !signup && index === 1;
            const dotStep = ['email','profile','password'][index];
            dot.classList.toggle('is-done',order.indexOf(dotStep) < order.indexOf(step));
            if (dotStep === step) dot.setAttribute('aria-current','step'); else dot.removeAttribute('aria-current');
        });
        if (step === 'profile' && previousStep !== 'profile') checkNicknameLive(form);
        else if (step !== 'profile') { clearTimeout(nicknameCheckTimer); nicknameCheckVersion++; }
        updateNicknameAvailability(form);
        if (focus && step !== 'confirm') form.querySelector(`[data-auth-stage="${step}"] input`)?.focus({ preventScroll:true });
    }
    function setAuthMode(recovery) {
        const modal = document.getElementById('cloudAuthModal'), form = modal.querySelector('form');
        if (form.dataset.saving) return;
        form.dataset.recovery = recovery ? 'true' : 'false';
        authNotice = ''; authSuccess = false;
        const password = form.querySelector('[name="password"]'); password.value = ''; password.type = 'password';
        const reveal = form.querySelector('[data-auth-show-password]'); reveal.textContent = 'Показать'; reveal.setAttribute('aria-pressed','false'); reveal.setAttribute('aria-label','Показать пароль');
        if (!recovery) form.querySelector('[value="signin"]').checked = true;
        setAuthStep('email'); refresh();
    }
    async function requestPasswordReset(email) {
        if (!client) await initialize();
        if (!client) throw new Error('Подключение к облаку временно недоступно. Повторите попытку.');
        const { error } = await client.auth.resetPasswordForEmail(email.trim());
        if (error) throw new Error(authErrorMessage(error));
        authNotice = 'Инструкция по сбросу отправлена на почту'; authSuccess = true;
        refresh(); app?.showToast?.(authNotice, 'success');
    }
    function closeAuth() {
        const modal = document.getElementById('cloudAuthModal');
        if (!modal) return;
        clearTimeout(nicknameCheckTimer); nicknameCheckVersion++;
        if (!session && (modal.dataset.entry === 'true' || modal.querySelector('form').dataset.saving)) return;
        const wasOpen = modal.classList.contains('active');
        modal.classList.remove('active');
        modal.querySelector('[name="password"]').value = '';
        document.body.classList.remove('ncd-auth-open');
        if (wasOpen && document.getElementById('settingsModal')?.classList.contains('active')) {
            document.querySelector(session ? '[data-cloud-logout]' : '[data-cloud-open-auth]')?.focus();
        }
    }
    function openAuth(options = {}) {
        const modal = document.getElementById('cloudAuthModal');
        if (!modal || (session && readyIdentity === ownerId()) || modal.querySelector('form').dataset.saving) return;
        modal.querySelector('[name="password"]').value = '';
        modal.classList.add('active');
        document.body.classList.add('ncd-auth-open');
        modal.dataset.entry = String(!!options.entry);
        modal.querySelector('#closeCloudAuthBtn').hidden = !!options.entry;
        setAuthMode(false);
        if (options.mode === 'signup') { modal.querySelector('[value="signup"]').checked = true; setAuthStep('email'); }
        refresh();
        modal.querySelector('[name="email"]').focus();
    }
    function refresh() {
        const container = document.getElementById('cloudSyncPanel');
        if (!container) return;
        const set = (selector, text) => { const node = container.querySelector(selector); if (node) node.textContent = text; };
        const connected = !!session && readyIdentity === ownerId() && !transitioning;
        const synced = connected && message.startsWith('Синхронизировано');
        set('[data-cloud-session-state]', connectionState().text);
        set('[data-cloud-status]', synced ? 'Синхронизировано 🟢' : connected ? 'Аккаунт подключён 🟢' : message);
        container.querySelector('[data-cloud-status]').classList.toggle('is-connected', connected);
        set('[data-cloud-sync-status]', message);
        container.querySelector('[data-cloud-sync-status]').hidden = !session || synced || bindNeeded;
        set('[data-cloud-diagnostic]', syncDiagnostic);
        container.querySelector('[data-cloud-diagnostic]').hidden = !syncDiagnostic;
        container.querySelector('[data-cloud-status]').classList.toggle('is-synced', synced);
        set('[data-cloud-account]', session?.user?.email || session?.user?.id || '');
        container.querySelector('[data-cloud-account]').hidden = !session;
        container.querySelector('[data-cloud-open-auth]').hidden = !!session;
        container.querySelector('[data-cloud-actions]').hidden = !session;
        const details = container.querySelector('[data-cloud-details]');
        details.hidden = !session || !(bindNeeded || conflict);
        container.querySelector('[data-cloud-session-state]').hidden = !session || !bindNeeded;
        container.querySelector('[data-cloud-bind]').hidden = !bindNeeded;
        container.querySelector('[data-cloud-conflicts]').hidden = !conflict;
        set('[data-cloud-conflict-preview]', previews.join('\n'));
        const form = document.querySelector('[data-cloud-auth]');
        if (form) form.hidden = !!session && readyIdentity === ownerId();
        const authStatus = document.querySelector('[data-cloud-auth-status]');
        if (authStatus) { authStatus.textContent = authNotice; authStatus.classList.toggle('is-success', authSuccess); }
        if (session && readyIdentity === ownerId()) closeAuth();

    }
    async function submitCloudForm(event) {
        event.preventDefault(); const form = event.target;
        if (form.dataset.saving) return;
        const modal = document.getElementById('cloudAuthModal');
        const step = form.dataset.step || 'email', recovery = form.dataset.recovery === 'true';
        const signup = form.querySelector('[value="signup"]').checked;
        if (step === 'confirm') { form.querySelector('[value="signin"]').checked = true; authNotice = ''; authSuccess = false; setAuthStep('email'); refresh(); return; }
        const email = form.querySelector('[name="email"]').value.trim();
        const password = form.querySelector('[name="password"]').value;
        if (!validAuthEmail(email)) {
            authNotice = 'Введите корректный email (например, you@example.com)'; authSuccess = false;
            if (step !== 'email') setAuthStep('email', false);
            refresh(); form.querySelector('[name="email"]').focus(); return;
        }
        if (step === 'password' && password.length < 8) {
            authNotice = 'Пароль должен быть не менее 8 символов'; authSuccess = false;
            refresh(); form.querySelector('[name="password"]').focus(); return;
        }
        const activeInput = form.querySelector(`[data-auth-stage="${step}"] input`);
        if (activeInput && !activeInput.reportValidity()) return;
        authNotice = ''; authSuccess = false; refresh();
        if (step === 'email' && !recovery && !signup) { setAuthStep('password'); return; }
        const controls = [...modal.querySelectorAll('input, button')].map(element => [element, element.disabled]);
        form.dataset.saving = 'true'; form.setAttribute('aria-busy', 'true');
        controls.forEach(([element]) => { element.disabled = true; });
        let nextStep = step;
        try {
            if (recovery) await requestPasswordReset(email);
            else if (step === 'email') {
                if (!await checkAuthEmail(email)) throw new Error("Этот email уже зарегистрирован. Перейдите во вкладку 'Войти'");
                nextStep = 'profile';
            } else if (step === 'profile') {
                const handle = normalizeAuthNickname(form.querySelector('[name="nickname"]').value);
                if (!await checkAuthNickname(handle)) {
                    nicknameAvailability = {value:form.querySelector('[name="nickname"]').value,state:'taken',message:HANDLE_TAKEN};
                    throw new Error(HANDLE_TAKEN);
                }
                form.querySelector('[name="nickname"]').value = handle; nextStep = 'password';
            } else {
                const result = await authenticate(email, password, signup, signup ? { nickname:form.querySelector('[name="nickname"]').value } : null);
                if (result.confirmationRequired) nextStep = 'confirm';
                else if (result.hydrated === false) nextStep = 'email';
            }
        } catch (error) {
            authNotice = error.message || 'Не удалось выполнить действие. Попробуйте ещё раз.'; authSuccess = false;
            if (/никнейм уже занят/.test(authNotice)) nextStep = 'profile';
        } finally {
            if (step === 'password' || recovery) form.querySelector('[name="password"]').value = '';
            delete form.dataset.saving; form.removeAttribute('aria-busy');
            controls.forEach(([element, disabled]) => { element.disabled = disabled; });
            if (modal.classList.contains('active')) setAuthStep(nextStep, false);
            refresh();
            if (nextStep !== step && modal.classList.contains('active')) setAuthStep(nextStep);
        }
    }
    function bindUI() {
        const container = document.getElementById('cloudSyncPanel');
        if (!container || container.dataset.bound) { refresh(); return; }
        container.dataset.bound = 'true';
        container.querySelector('[data-cloud-open-auth]').addEventListener('click', openAuth);
        const modal = document.getElementById('cloudAuthModal');
        modal.querySelector('[data-cloud-auth]').addEventListener('submit', submitCloudForm);
        modal.querySelector('#closeCloudAuthBtn').addEventListener('click', closeAuth);
        modal.querySelector('[data-cloud-forgot]').addEventListener('click', () => setAuthMode(true));
        modal.querySelector('[data-cloud-back]').addEventListener('click', () => setAuthMode(false));
        modal.querySelectorAll('[name="mode"]').forEach(input => input.addEventListener('change', () => {
            if (modal.querySelector('form').dataset.saving) return;
            authNotice = ''; authSuccess = false; modal.querySelector('[name="password"]').value = ''; setAuthStep('email'); refresh();
        }));
        modal.querySelector('[data-auth-prev]').addEventListener('click', () => {
            const form = modal.querySelector('form'); if (form.dataset.saving) return;
            authNotice = ''; form.querySelector('[name="password"]').value = '';
            setAuthStep(form.dataset.step === 'password' && form.querySelector('[value="signup"]').checked ? 'profile' : 'email'); refresh();
        });
        modal.querySelector('[data-auth-edit-email]').addEventListener('click', () => { authNotice = ''; modal.querySelector('[name="password"]').value = ''; setAuthStep('email'); refresh(); });
        modal.querySelector('[name="nickname"]').addEventListener('input', event => {
            event.target.value = event.target.value.replace(/^@+/, '').toLowerCase();
            const form = event.target.form;
            clearTimeout(nicknameCheckTimer); nicknameCheckVersion++;
            nicknameAvailability = { value:event.target.value, state:'checking', message:'Проверяем никнейм…' };
            authNotice = ''; authSuccess = false; refresh(); updateNicknameAvailability(form);
            nicknameCheckTimer = setTimeout(() => checkNicknameLive(form), 300);
        });
        modal.querySelector('[data-auth-show-password]').addEventListener('click', event => {
            const field = modal.querySelector('[name="password"]'), show = field.type === 'password'; field.type = show ? 'text' : 'password';
            event.currentTarget.textContent = show ? 'Скрыть' : 'Показать'; event.currentTarget.setAttribute('aria-pressed',String(show)); event.currentTarget.setAttribute('aria-label',show ? 'Скрыть пароль' : 'Показать пароль');
        });
        const sizeAuth = () => { modal.style.setProperty('--auth-height', `${window.visualViewport?.height || window.innerHeight}px`); modal.style.setProperty('--auth-offset', `${window.visualViewport?.offsetTop || 0}px`); };
        window.visualViewport?.addEventListener('resize', sizeAuth); window.visualViewport?.addEventListener('scroll', sizeAuth); window.addEventListener('resize',sizeAuth); sizeAuth();
        document.addEventListener('keydown', event => {
            if (!modal.classList.contains('active')) return;
            if (event.key === 'Escape') { event.preventDefault(); if (modal.dataset.entry !== 'true') closeAuth(); }
            if (event.key === 'Tab') {
                const controls = [...modal.querySelectorAll('button,input')].filter(element => !element.disabled && !element.closest('[hidden]'));
                const first = controls[0], last = controls[controls.length - 1];
                if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
                else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
            }
        });
        container.querySelector('[data-cloud-logout]').addEventListener('click', () => logout().catch(error => status(error.message)));
        container.querySelector('[data-cloud-bind]').addEventListener('click', () => {
            if (!session || busy || applying) return;
            // Account switching always pulls the target account; local data is never rebound for upload.
            bootstrapCloud(true).catch(() => {});
        });
        container.querySelectorAll('[data-cloud-resolve]').forEach(button => button.addEventListener('click', () => sync(button.dataset.cloudResolve)));
        refresh();
    }
    function prepareLocalReset() {
        clearTimeout(timer); clearInterval(polling); stopRealtime();
        const owner = localStorage.getItem(OWNER);
        // Local reset must not become a bulk deletion in the cloud on next login.
        if (owner) write(`gt-cloud-state-v1:${owner}`, { base: null, revision: 0 });
    }
    function attachmentStorage() {
        if (!client || !session || busy || applying || transitioning || loggingOut || readyIdentity !== ownerId() || localStorage.getItem(OWNER) !== ownerId())
            throw new Error('Войдите в облачный аккаунт, привяжите профиль и дождитесь синхронизации.');
        const identity = ownerId(), storage = client.storage.from('goal-attachments');
        return { userId: session.user.id, storage, assertOwner() {
            if (identity !== ownerId() || localStorage.getItem(OWNER) !== identity) throw new Error('Облачный аккаунт изменился.');
        } };
    }
    function rememberPlayerTag(userId, shortId, expectedClient) {
        if (expectedClient !== client || session?.user?.id !== userId || loggingOut || !app?.user || app.user.supabaseUserId !== userId) return false;
        if (shortId !== null && !/^#[A-Z0-9]{6,8}$/.test(shortId)) return false;
        publishPlayerTag(scope(),shortId,++playerTagVersion);
        return true;
    }
    Object.defineProperty(window,'supabaseClient',{get:()=>singleton.instance,configurable:false});
    window.CloudSync = { get client(){return singleton.instance;}, currentPlayerTag, fetchPlayerTag:()=>fetchPlayerTag(), fetchProfile:()=>fetchProfile(), rememberPlayerTag, canOpenCachedAccount, authClient: () => client, connectionState, refresh, socialConnection() {
        if (!client || !session?.user?.id || loggingOut || localStorage.getItem(LOCK) === 'true') return null;
        const ownProfile = app?.user?.supabaseUserId === session.user.id || app?.user?.id === session.user.id;
        return { client, userId: session.user.id, identity: ownerId(), shortId: ownProfile ? app?.user?.shortId || null : null, handle: (ownProfile ? app?.user?.handle : null) || session.user.user_metadata?.ncd_handle || null };
    }, attachmentStorage, openAuth, closeAuth, prepareLocalReset, attach(instance) { app = instance; bindUI(); initialize(); }, bindUI, localChanged, sync, pushGoals, saveSocialProfile, bootstrapCloud, configured: () => !!client, isApplying: () => applying, isSyncing: () => busy || transitioning,
        configure, authenticate, checkAuthNickname, logout, capture, localEmpty };
    window.addEventListener('online', () => { if (loggingOut) return; if (client && session) { if (readyIdentity === ownerId()) sync(); else acceptSession(session,true); } else if (client && localStorage.getItem(LOCK) !== 'true') resumeStoredSession(); else initialize(); });
    window.addEventListener('focus', () => { if (!loggingOut && !session && sessionError) { resumeStoredSession(); return; } if (!loggingOut && session) { if (readyIdentity === ownerId()) sync(); else acceptSession(session,true); } });
    document.addEventListener('goaltracker:storage-saved', localChanged);
    document.addEventListener('goaltracker:finance-changed', localChanged);
    document.addEventListener('goaltracker:profile-rendered', bindUI);
})();
