/* Public browser configuration. Never put service_role/secret keys here. */
window.SupabaseConfig = Object.freeze({
    url: 'https://kvyhbbctpyeoikjqhubu.supabase.co',
    // null: read the published RPC signature. Set an exact argument name if OpenAPI is disabled.
    playerTagArgument: null,
    key: 'sb_publishable_LbOFnz8L3twvPEZBOxYg1g_RdzjrWgi'
});
