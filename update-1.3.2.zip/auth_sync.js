/* ============================================================
   GoalTracker Pro — Auth Sync (облачная синхронизация)
   Классический <script> (без модулей). Зависимости: только window.app.
   - Email/Password форма (локальный профиль + опциональный cloud)
   - Статус: "Облачная синхронизация: В сети / Локально"
   - Bridge к app.syncData / app.settings.syncUrl
   ============================================================ */
(function () {
'use strict';

var LS_KEY = 'goaltracker_cloud_auth';

function loadAuth() {
    try {
        var raw = localStorage.getItem(LS_KEY);
        return raw ? JSON.parse(raw) : { email: '', loggedIn: false };
    } catch (e) { return { email: '', loggedIn: false }; }
}

function saveAuth(a) {
    try { localStorage.setItem(LS_KEY, JSON.stringify(a)); } catch (e) {}
}

function getApp() {
    return (typeof window !== 'undefined' && window.app instanceof Object && window.app.syncData) ? window.app : null;
}

function isOnline() {
    var app = getApp();
    var base = '';
    try { base = app ? app.getSyncBase() : ''; } catch (e) { base = ''; }
    return !!(base && navigator.onLine !== false);
}

function syncStatusText() {
    var app = getApp();
    var base = '';
    try { base = app ? app.getSyncBase() : ''; } catch (e) {}
    if (base) return { text: 'Облачная синхронизация: В сети', online: true, base: base };
    return { text: 'Облачная синхронизация: Локально', online: false, base: '' };
}

function renderStatus(el) {
    if (!el) return;
    var s = syncStatusText();
    var auth = loadAuth();
    el.innerHTML =
        '<span class="sync-dot ' + (s.online ? 'online' : 'local') + '"></span>' +
        '<span>' + s.text + '</span>' +
        (auth.loggedIn && auth.email ? '<span class="sync-email">' + escapeHtml(auth.email) + '</span>' : '');
}

function escapeHtml(t) {
    if (!t) return '';
    var d = document.createElement('div');
    d.textContent = t;
    return d.innerHTML;
}

/* Публичное API */
var AuthSync = {
    getEmail: function () { return loadAuth().email || ''; },
    isLoggedIn: function () { return !!loadAuth().loggedIn; },
    status: syncStatusText,
    isOnline: isOnline,

    login: function (email, password) {
        email = String(email || '').trim().toLowerCase();
        if (!/^\S+@\S+\.\S+$/.test(email)) return { ok: false, error: 'Введите корректный email' };
        if (String(password || '').length < 4) return { ok: false, error: 'Пароль — минимум 4 символа' };
        var a = { email: email, loggedIn: true, at: new Date().toISOString() };
        saveAuth(a);
        // Пробуем тихую синхронизацию, если задан сервер
        var app = getApp();
        if (app && app.settings && app.settings.autoSync) {
            try { setTimeout(function () { app.syncData(true); }, 300); } catch (e) {}
        }
        AuthSync.refreshAll();
        return { ok: true };
    },

    register: function (email, password) {
        // Локальная регистрация = тот же login (серверная часть — через syncUrl в настройках)
        return AuthSync.login(email, password);
    },

    logout: function () {
        saveAuth({ email: '', loggedIn: false });
        AuthSync.refreshAll();
    },

    refreshAll: function () {
        if (typeof document === 'undefined' || !document.querySelectorAll) return;
        document.querySelectorAll('[data-auth-sync-status]').forEach(renderStatus);
        var emailInputs = document.querySelectorAll('[data-auth-email]');
        var auth = loadAuth();
        emailInputs.forEach(function (inp) {
            if (document.activeElement !== inp) inp.value = auth.email || '';
        });
    },

    bind: function () {
        if (typeof document === 'undefined' || !document.querySelectorAll) return;
        // Формы профиля
        document.querySelectorAll('[data-auth-form]').forEach(function (form) {
            if (form.__authSyncBound) return;
            form.__authSyncBound = true;
            form.addEventListener('submit', function (e) {
                e.preventDefault();
                var email = form.querySelector('[data-auth-email]')?.value || '';
                var pass = form.querySelector('[data-auth-password]')?.value || '';
                var mode = form.querySelector('[data-auth-mode]')?.value || 'login';
                var err = form.querySelector('[data-auth-error]');
                var res = mode === 'register' ? AuthSync.register(email, pass) : AuthSync.login(email, pass);
                if (err) {
                    err.textContent = res.ok ? 'Готово! Профиль привязан к ' + email : (res.error || 'Ошибка');
                    err.className = res.ok ? 'auth-sync-msg ok' : 'auth-sync-msg error';
                    err.style.display = 'block';
                }
                var app = getApp();
                if (res.ok && app) {
                    try { app.showToast('Вход выполнен: ' + email, 'success'); } catch (e) {}
                }
            });
        });
        // Кнопки переключения Войти/Регистрация
        document.querySelectorAll('[data-auth-tab]').forEach(function (btn) {
            if (btn.__authSyncBound) return;
            btn.__authSyncBound = true;
            btn.addEventListener('click', function () {
                var form = btn.closest('form') || document.querySelector('[data-auth-form]');
                var modeInput = form?.querySelector('[data-auth-mode]');
                var submitBtn = form?.querySelector('[data-auth-submit]');
                var all = document.querySelectorAll('[data-auth-tab]');
                all.forEach(function (b) { b.classList.remove('active'); });
                btn.classList.add('active');
                if (modeInput) modeInput.value = btn.dataset.authTab;
                if (submitBtn) submitBtn.textContent = btn.dataset.authTab === 'register' ? 'Регистрация' : 'Войти';
            });
        });
        // Кнопка "Синхронизировать сейчас" в профиле
        document.querySelectorAll('[data-auth-sync-now]').forEach(function (btn) {
            if (btn.__authSyncBound) return;
            btn.__authSyncBound = true;
            btn.addEventListener('click', function () {
                var app = getApp();
                if (app) { try { app.syncData(false); } catch (e) {} }
                setTimeout(AuthSync.refreshAll, 800);
            });
        });
        AuthSync.refreshAll();
        if (!AuthSync.__netBound && typeof window.addEventListener === 'function') {
            AuthSync.__netBound = true;
        }
    }
};

if (typeof window !== 'undefined') {
    window.AuthSync = AuthSync;
    if (typeof document !== 'undefined' && document.addEventListener) {
        document.addEventListener('DOMContentLoaded', function () { try { AuthSync.bind(); } catch (e) {} });
        // Перебиндить после рендера профиля (app.renderProfile перерисовывает DOM)
        document.addEventListener('goaltracker:profile-rendered', function () { try { AuthSync.bind(); } catch (e) {} });
    }
    if (typeof window.addEventListener === 'function') {
        window.addEventListener('online', AuthSync.refreshAll);
        window.addEventListener('offline', AuthSync.refreshAll);
    }
}
})();
