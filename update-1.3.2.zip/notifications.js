// ===== GoalTracker Pro - Notifications Module (Capacitor LocalNotifications + Web fallback) =====
// Полноценная система локальных и календарных PUSH-уведомлений
// Работает как классический <script> (без bundler): Capacitor-подключение опционально,
// в браузере используется Web Notifications API + in-app toast/schedule.

(function () {
'use strict';

// Опциональные Capacitor-модули (подхватываются, если уже загружены на странице)
var CapacitorCore = (typeof window !== 'undefined' && (window.Capacitor)) || null;
var CapLocalNotifications = null;
try {
    if (CapacitorCore && CapacitorCore.Plugins && CapacitorCore.Plugins.LocalNotifications) {
        CapLocalNotifications = CapacitorCore.Plugins.LocalNotifications;
    } else if (typeof window !== 'undefined' && window.LocalNotifications) {
        CapLocalNotifications = window.LocalNotifications;
    }
} catch (e) { CapLocalNotifications = null; }

// Безопасные оболочки поверх Capacitor LocalNotifications (fallback → Web Notification)
var LocalNotifications = CapLocalNotifications || {
    async requestPermissions() { return { display: 'granted' }; },
    async checkPermissions() { return { display: 'granted' }; },
    async schedule() { return true; },
    async cancel() { return true; },
    async getPending() { return { notifications: [] }; },
    addListener() { return { remove() {} }; }
};
var Capacitor = CapacitorCore || { isNativePlatform() { return false; } };

class NotificationManager {
    constructor(app) {
        this.app = app;
        this.isNative = Capacitor.isNativePlatform();
        this.initialized = false;
        this.notificationIds = {
            habits: 1000,        // 1000-1999: напоминания по привычкам
            deadlines: 2000,     // 2000-2999: дедлайны целей
            calendar: 3000,      // 3000-3999: события календаря
            streak: 4000,        // 4000-4999: стрик-алерты
            test: 9999           // тестовое уведомление
        };
    }

    // ===== ИНИЦИАЛИЗАЦИЯ =====
    async init() {
        if (this.initialized) return;
        
        try {
            // Запрашиваем разрешения при первом запуске
            const perm = await LocalNotifications.requestPermissions();
            console.log('[Notifications] Permissions:', perm);
            
            if (this.isNative) {
                // На Android 13+ нужно запросить POST_NOTIFICATIONS
                if (perm.display === 'granted') {
                    console.log('[Notifications] ✅ Разрешения получены');
                } else {
                    console.warn('[Notifications] ⚠️ Разрешения не получены:', perm.display);
                }
            }

            // Слушаем клики по уведомлениям
            LocalNotifications.addListener('localNotificationActionPerformed', (notification) => {
                this.handleNotificationClick(notification);
            });

            this.initialized = true;
            console.log('[Notifications] Модуль инициализирован');
        } catch (e) {
            console.error('[Notifications] Ошибка инициализации:', e);
        }
    }

    // ===== РАЗРЕШЕНИЯ =====
    async requestPermissions() {
        const perm = await LocalNotifications.requestPermissions();
        if (this.app) {
            this.app.settings.notifications = perm.display === 'granted';
            this.app.saveData();
        }
        return perm.display === 'granted';
    }

    async checkPermissions() {
        const perm = await LocalNotifications.checkPermissions();
        return perm.display === 'granted';
    }

    // ===== ОСНОВНЫЕ МЕТОДЫ ПЛАНИРОВАНИЯ =====

    // Планирует одно уведомление
    async schedule(options) {
        if (!this.app.settings.notifications) {
            console.log('[Notifications] Уведомления отключены в настройках');
            return false;
        }

        const hasPerm = await this.checkPermissions();
        if (!hasPerm) {
            console.warn('[Notifications] Нет разрешения на уведомления');
            return false;
        }

        try {
            await LocalNotifications.schedule({
                notifications: [{
                    id: options.id,
                    title: options.title,
                    body: options.body,
                    schedule: options.schedule || { at: new Date(Date.now() + 1000) },
                    sound: this.app.settings.notificationSound ? 'default' : undefined,
                    vibration: this.app.settings.notificationVibration ? true : false,
                    extra: options.extra || {},
                    actionTypeId: options.actionTypeId || 'default',
                    attachments: options.attachments || []
                }]
            });
            console.log(`[Notifications] ✅ Запланировано: #${options.id} - ${options.title}`);
            return true;
        } catch (e) {
            console.error('[Notifications] Ошибка планирования:', e);
            return false;
        }
    }

    // Отменяет уведомление по ID
    async cancel(id) {
        try {
            await LocalNotifications.cancel({ notifications: [{ id }] });
            console.log(`[Notifications] 🗑️ Отменено: #${id}`);
            return true;
        } catch (e) {
            console.error('[Notifications] Ошибка отмены:', e);
            return false;
        }
    }

    // Отменяет несколько уведомлений
    async cancelMultiple(ids) {
        try {
            await LocalNotifications.cancel({ notifications: ids.map(id => ({ id })) });
            console.log(`[Notifications] 🗑️ Отменено несколько: ${ids.join(', ')}`);
            return true;
        } catch (e) {
            console.error('[Notifications] Ошибка массовой отмены:', e);
            return false;
        }
    }

    // Получает все запланированные уведомления
    async getPending() {
        try {
            const result = await LocalNotifications.getPending();
            return result.notifications;
        } catch (e) {
            console.error('[Notifications] Ошибка получения списка:', e);
            return [];
        }
    }

    // ===== ТИП А: НАПОМИНАНИЯ ПО ПРИВЫЧКАМ (Daily Habits) =====

    // Планирует напоминания для одной привычки
    async scheduleHabitReminders(habit) {
        // Удаляем старые уведомления для этой привычки
        await this.cancelHabitReminders(habit.id);

        if (!habit.reminders || !habit.reminders.length) {
            console.log(`[Notifications] У привычки "${habit.title}" нет настроенных напоминаний`);
            return;
        }

        const daysMap = { 'Пн': 1, 'Вт': 2, 'Ср': 3, 'Чт': 4, 'Пт': 5, 'Сб': 6, 'Вс': 0 };
        let scheduled = 0;

        for (const reminder of habit.reminders) {
            const { time, days } = reminder; // time: "10:00", days: ["Пн", "Ср", "Пт"]
            
            if (!days || !days.length) continue;

            const [hours, minutes] = time.split(':').map(Number);
            
            for (const dayName of days) {
                const weekday = daysMap[dayName];
                if (weekday === undefined) continue;

                const id = this.notificationIds.habits + habit.id.hashCode() + weekday * 10 + scheduled;
                
                await this.schedule({
                    id,
                    title: `⏰ Напоминание: ${habit.title}`,
                    body: `Время выполнить привычку! ${habit.description || ''}`,
                    schedule: {
                        repeats: true,
                        every: 'week',
                        weekday: weekday + 1, // Capacitor: 1=Понедельник, 7=Воскресенье
                        hour: hours,
                        minute: minutes,
                        // Устанавливаем дату начала на ближайший соответствующий день недели
                        at: this.getNextWeekdayDate(weekday, hours, minutes)
                    },
                    extra: {
                        type: 'habit',
                        habitId: habit.id,
                        habitTitle: habit.title,
                        action: 'open-habit'
                    },
                    actionTypeId: 'habit-reminder'
                });
                scheduled++;
            }
        }

        console.log(`[Notifications] Привычка "${habit.title}": запланировано ${scheduled} напоминаний`);
        return scheduled;
    }

    // Отменяет все напоминания для привычки
    async cancelHabitReminders(habitId) {
        const pending = await this.getPending();
        const habitIds = pending
            .filter(n => n.extra?.type === 'habit' && n.extra?.habitId === habitId)
            .map(n => n.id);
        
        if (habitIds.length) {
            await this.cancelMultiple(habitIds);
        }
    }

    // Перепланирует все напоминания по привычкам
    async rescheduleAllHabits() {
        if (!this.app.settings.habitReminders) return;
        
        // Сначала отменяем все старые习惯-уведомления
        const pending = await this.getPending();
        const habitIds = pending
            .filter(n => n.extra?.type === 'habit')
            .map(n => n.id);
        if (habitIds.length) await this.cancelMultiple(habitIds);

        // Планируем заново
        let total = 0;
        for (const habit of this.app.habits) {
            total += await this.scheduleHabitReminders(habit);
        }
        console.log(`[Notifications] Всего запланировано напоминаний по привычкам: ${total}`);
        return total;
    }

    // ===== ТИП Б: ДЕДЛАЙНЫ ЦЕЛЕЙ И КАЛЕНДАРЬ =====

    // Планирует уведомление за 24 часа до дедлайна цели
    async scheduleGoalDeadline(goal) {
        await this.cancelGoalDeadline(goal.id);

        if (!goal.deadline || goal.status !== 'active') return;
        if (!this.app.settings.deadlineWarnings) return;

        const deadline = new Date(goal.deadline + 'T00:00:00');
        const now = new Date();
        
        // Уведомление за 24 часа
        const remind24h = new Date(deadline.getTime() - 24 * 60 * 60 * 1000);
        if (remind24h > now) {
            await this.schedule({
                id: this.notificationIds.deadlines + goal.id.hashCode(),
                title: '⏳ Дедлайн приближается!',
                body: `До дедлайна "${goal.title}" осталось 24 часа!`,
                schedule: { at: remind24h },
                extra: {
                    type: 'deadline',
                    goalId: goal.id,
                    goalTitle: goal.title,
                    action: 'open-goal',
                    timing: '24h'
                },
                actionTypeId: 'deadline-warning'
            });
        }

        // Уведомление в день дедлайна (утром)
        const remindDay = new Date(deadline);
        remindDay.setHours(9, 0, 0, 0);
        if (remindDay > now) {
            await this.schedule({
                id: this.notificationIds.deadlines + goal.id.hashCode() + 1,
                title: '🔥 Сегодня дедлайн!',
                body: `Цель "${goal.title}" должна быть завершена сегодня!`,
                schedule: { at: remindDay },
                extra: {
                    type: 'deadline',
                    goalId: goal.id,
                    goalTitle: goal.title,
                    action: 'open-goal',
                    timing: 'day'
                },
                actionTypeId: 'deadline-day'
            });
        }
    }

    async cancelGoalDeadline(goalId) {
        const pending = await this.getPending();
        const ids = pending
            .filter(n => n.extra?.type === 'deadline' && n.extra?.goalId === goalId)
            .map(n => n.id);
        if (ids.length) await this.cancelMultiple(ids);
    }

    // Планирует уведомление для события календаря
    async scheduleCalendarEvent(event) {
        await this.cancelCalendarEvent(event.id);

        if (!event.date || !event.time) return;
        if (!this.app.settings.calendarReminders) return;

        const eventDate = new Date(event.date + 'T' + event.time);
        const now = new Date();
        
        // За 30 минут до события
        const remind30m = new Date(eventDate.getTime() - 30 * 60 * 1000);
        if (remind30m > now) {
            await this.schedule({
                id: this.notificationIds.calendar + event.id.hashCode(),
                title: '📅 Скоро событие!',
                body: `Через 30 минут: ${event.title}${event.location ? ` (${event.location})` : ''}`,
                schedule: { at: remind30m },
                extra: {
                    type: 'calendar',
                    eventId: event.id,
                    eventTitle: event.title,
                    action: 'open-calendar',
                    timing: '30m'
                },
                actionTypeId: 'calendar-reminder'
            });
        }

        // В момент события
        if (eventDate > now) {
            await this.schedule({
                id: this.notificationIds.calendar + event.id.hashCode() + 1,
                title: '🔔 Событие началось!',
                body: `${event.title}${event.location ? ` — ${event.location}` : ''}`,
                schedule: { at: eventDate },
                extra: {
                    type: 'calendar',
                    eventId: event.id,
                    eventTitle: event.title,
                    action: 'open-calendar',
                    timing: 'now'
                },
                actionTypeId: 'calendar-now'
            });
        }
    }

    async cancelCalendarEvent(eventId) {
        const pending = await this.getPending();
        const ids = pending
            .filter(n => n.extra?.type === 'calendar' && n.extra?.eventId === eventId)
            .map(n => n.id);
        if (ids.length) await this.cancelMultiple(ids);
    }

    // Перепланирует все дедлайны и календарь
    async rescheduleAllDeadlinesAndCalendar() {
        let total = 0;
        
        // Цели с дедлайнами
        for (const goal of this.app.goals) {
            await this.scheduleGoalDeadline(goal);
            total++;
        }
        
        // События календаря (notes с временем)
        for (const [dateStr, notes] of Object.entries(this.app.notes)) {
            for (const note of notes) {
                if (note.time) {
                    await this.scheduleCalendarEvent({ 
                        id: note.id, 
                        title: note.content, 
                        date: dateStr, 
                        time: note.time,
                        location: note.location
                    });
                    total++;
                }
            }
        }
        
        console.log(`[Notifications] Запланировано дедлайнов и событий: ${total}`);
        return total;
    }

    // ===== ТИП В: ВЕЧЕРНИЙ СТРИК-СПАС (Streak Protection Alert) =====

    async scheduleStreakAlert() {
        await this.cancelStreakAlert();
        
        if (!this.app.settings.streakAlerts) return;
        if (!this.app.settings.gamification) return;

        // Планируем на 20:30 каждый день
        const now = new Date();
        const alertTime = new Date();
        alertTime.setHours(20, 30, 0, 0);
        
        // Если уже прошло 20:30 сегодня — ставим на завтра
        if (alertTime <= now) {
            alertTime.setDate(alertTime.getDate() + 1);
        }

        // Повторяем ежедневно
        await this.schedule({
            id: this.notificationIds.streak,
            title: '⚠️ Твой стрик под угрозой!',
            body: 'Осталось 3 часа, чтобы закрыть привычки и не потерять XP!',
            schedule: {
                repeats: true,
                every: 'day',
                hour: 20,
                minute: 30,
                at: alertTime
            },
            extra: {
                type: 'streak',
                action: 'open-habits'
            },
            actionTypeId: 'streak-alert'
        });

        console.log('[Notifications] 📅 Streak-alert запланирован на 20:30 ежедневно');
    }

    async cancelStreakAlert() {
        await this.cancel(this.notificationIds.streak);
    }

    // Проверяет невыполненные привычки и показывает локальный toast (если приложение открыто)
    checkStreakNow() {
        if (!this.app.settings.streakAlerts) return;
        
        const today = new Date().toISOString().split('T')[0];
        const incompleteHabits = this.app.habits.filter(h => 
            h.frequency === 'daily' && 
            (!h.completedDays || !h.completedDays.includes(today))
        );

        if (incompleteHabits.length > 0) {
            const msg = `⚠️ Твой стрик под угрозой! Не выполнено: ${incompleteHabits.map(h => h.title).join(', ')}. Осталось время до 23:59!`;
            this.app.showToast(msg, 'warning');
            
            // Также можем отправить уведомление прямо сейчас (незапланированное)
            if (this.app.settings.notifications && this.isNative) {
                this.schedule({
                    id: this.notificationIds.streak + 1, // one-shot
                    title: '⚠️ Стрик под угрозой!',
                    body: `Не выполнено привычек: ${incompleteHabits.length}. Ещё есть время!`,
                    schedule: { at: new Date(Date.now() + 1000) },
                    extra: { type: 'streak', action: 'open-habits', immediate: true }
                });
            }
        }
    }

    // ===== ОБРАБОТКА КЛИКОВ ПО УВЕДОМЛЕНИЯМ =====

    handleNotificationClick(notification) {
        const extra = notification.notification.extra || {};
        console.log('[Notifications] Клик по уведомлению:', extra);

        if (!this.app) return;

        switch (extra.action) {
            case 'open-habit':
            case 'open-habits':
                this.app.switchView('habits');
                // Скролл к конкретной привычке
                setTimeout(() => this.scrollToHabit(extra.habitId), 100);
                break;
                
            case 'open-goal':
                this.app.switchView('goals');
                setTimeout(() => this.app.openGoalDetail(extra.goalId), 100);
                break;
                
            case 'open-calendar':
                this.app.switchView('calendar');
                // Можно переключить на нужную дату
                if (extra.eventDate) {
                    setTimeout(() => {
                        this.app.currentMonth = new Date(extra.eventDate);
                        this.app.renderCalendar();
                    }, 100);
                }
                break;
                
            case 'open-achievements':
                this.app.switchView('achievements');
                break;
        }
    }

    scrollToHabit(habitId) {
        const el = document.querySelector(`.habit-item [data-habit-id="${habitId}"]`)?.closest('.habit-item');
        if (el) {
            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            el.classList.add('highlight');
            setTimeout(() => el.classList.remove('highlight'), 2000);
        }
    }

    // ===== ТЕСТОВОЕ УВЕДОМЛЕНИЕ =====

    async sendTestNotification() {
        return this.schedule({
            id: this.notificationIds.test,
            title: '🧪 Тестовое уведомление',
            body: 'GoalTracker Pro: push-уведомления работают! ✅',
            schedule: { at: new Date(Date.now() + 2000) }, // через 2 сек
            extra: { type: 'test' },
            actionTypeId: 'test'
        });
    }

    // ===== УПРАВЛЕНИЕ ВСЕМИ УВЕДОМЛЕНИЯМИ =====

    // Полная перепланировка всего
    async rescheduleAll() {
        console.log('[Notifications] 🔄 Полная перепланировка...');
        
        // Отменяем всё
        await this.cancelAll();
        
        // Планируем заново согласно настройкам
        const results = {
            habits: 0,
            deadlines: 0,
            calendar: 0,
            streak: 0
        };

        if (this.app.settings.habitReminders) {
            results.habits = await this.rescheduleAllHabits();
        }
        
        if (this.app.settings.deadlineWarnings) {
            results.deadlines = await this.rescheduleAllDeadlinesAndCalendar();
        }
        
        if (this.app.settings.calendarReminders) {
            // Уже включено в rescheduleAllDeadlinesAndCalendar
        }
        
        if (this.app.settings.streakAlerts) {
            await this.scheduleStreakAlert();
            results.streak = 1;
        }

        console.log('[Notifications] ✅ Перепланировка завершена:', results);
        return results;
    }

    // Отмена абсолютно всех уведомлений
    async cancelAll() {
        const pending = await this.getPending();
        const ids = pending.map(n => n.id);
        if (ids.length) {
            await this.cancelMultiple(ids);
        }
        console.log('[Notifications] 🗑️ Все уведомления отменены');
    }

    // ===== УТИЛИТЫ =====

    // Получает дату ближайшего заданного дня недели
    getNextWeekdayDate(weekday, hour, minute) {
        // weekday: 0=Вс, 1=Пн, ..., 6=Сб (JS standard)
        // Capacitor ожидает 1=Пн, 7=Вс для weekday в schedule
        const now = new Date();
        const target = new Date();
        target.setHours(hour, minute, 0, 0);
        
        const currentWeekday = now.getDay(); // 0=Вс
        let daysUntil = weekday - currentWeekday;
        
        if (daysUntil <= 0) daysUntil += 7; // Следующая неделя
        if (daysUntil === 0 && target <= now) daysUntil = 7; // Уже прошло сегодня
        
        target.setDate(now.getDate() + daysUntil);
        return target;
    }
}

// Хелпер для стабильного hashCode строки
if (!String.prototype.hashCode) {
String.prototype.hashCode = function() {
    let hash = 0;
    for (let i = 0; i < this.length; i++) {
        const char = this.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash;
    }
    return Math.abs(hash);
};
}

// Экспорт для использования в app.js
if (typeof window !== 'undefined') {
    window.NotificationManager = NotificationManager;
}

})();