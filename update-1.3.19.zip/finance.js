(function () {
    'use strict';

    const STORAGE_KEY = 'goalTracker_finance';
    const CATEGORY_NAMES = {
        salary: 'Зарплата',
        freelance: 'Подработка',
        food: 'Еда',
        transport: 'Транспорт',
        housing: 'Жильё',
        health: 'Здоровье',
        entertainment: 'Развлечения',
        other: 'Другое'
    };

    const CUSTODIAN_COIN = `<svg viewBox="0 0 64 64" aria-hidden="true" focusable="false">
        <circle cx="32" cy="32" r="27" fill="#07181e" stroke="#22d3ee" stroke-width="2"/>
        <circle cx="32" cy="32" r="22" fill="none" stroke="#ecfeff" stroke-width="1" opacity=".7"/>
        <path d="M27 45V19h9c11 0 11 16 0 16H23m0 5h15" fill="none" stroke="#ecfeff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>`;
    const motionPreference = window.matchMedia?.('(prefers-reduced-motion: reduce)');
    let celebrationTimers = [];
    let custodianObserver = null;

    let activeStep = 'accounting';
    let renderedStep = null;
    let eventsBound = false;
    let depositFormOpen = false;
    let data = loadData();

    function defaults() {
        return {
            transactions: [],
            budget: {
                categories: {
                    food: { name: 'Еда', limit: 0 },
                    transport: { name: 'Транспорт', limit: 0 },
                    housing: { name: 'Жильё', limit: 0 },
                    health: { name: 'Здоровье', limit: 0 },
                    entertainment: { name: 'Развлечения', limit: 0 },
                    other: { name: 'Другое', limit: 0 }
                }
            },
            safetyFund: { balance: 0, targetMonths: 6, history: [], newDepositMade: false, lastSeenBalance: 0 },
            investments: { assets: [] },
            growth: { baseIncome: 0, currentIncome: 0, history: [], ideas: [] }
        };
    }

    function number(value, fallback = 0) {
        const parsed = Number(value);
        return Number.isFinite(parsed) ? parsed : fallback;
    }

    function array(value) {
        return Array.isArray(value) ? value : [];
    }

    function normalize(raw) {
        const base = defaults();
        const source = raw && typeof raw === 'object' ? raw : {};
        const oldSalary = source.growthTracker?.salaryGrowth || {};
        const oldPortfolio = source.investments?.portfolio;
        const rawAssets = Array.isArray(source.investments?.assets)
            ? source.investments.assets
            : Object.entries(oldPortfolio?.assets || {}).map(([symbol, asset]) => ({ symbol, ...asset }));

        const categories = { ...base.budget.categories };
        const storedCategories = source.budget?.categories;
        if (storedCategories && typeof storedCategories === 'object') {
            Object.entries(storedCategories).forEach(([key, category]) => {
                categories[key] = {
                    name: category?.name || CATEGORY_NAMES[key] || key,
                    limit: Math.max(0, number(category?.limit))
                };
            });
        }

        return {
            transactions: array(source.transactions).map(item => ({
                id: item?.id || createId(),
                type: item?.type === 'income' ? 'income' : 'expense',
                amount: Math.max(0, number(item?.amount)),
                category: item?.category || 'other',
                description: String(item?.description || ''),
                date: item?.date || today()
            })),
            budget: { categories },
            safetyFund: {
                balance: Math.max(0, number(source.safetyFund?.balance)),
                targetMonths: Math.max(1, number(source.safetyFund?.targetMonths, 6)),
                history: array(source.safetyFund?.history),
                newDepositMade: Boolean(source.safetyFund?.newDepositMade),
                lastSeenBalance: Math.max(0, number(source.safetyFund?.lastSeenBalance, number(source.safetyFund?.balance)))
            },
            investments: {
                assets: rawAssets.map(asset => ({
                    id: asset?.id || createId(),
                    symbol: String(asset?.symbol || 'ASSET').toUpperCase(),
                    name: String(asset?.name || asset?.symbol || 'Актив'),
                    quantity: Math.max(0, number(asset?.quantity)),
                    buyPrice: Math.max(0, number(asset?.buyPrice)),
                    currentPrice: Math.max(0, number(asset?.currentPrice, number(asset?.buyPrice)))
                }))
            },
            growth: {
                baseIncome: Math.max(0, number(source.growth?.baseIncome, number(oldSalary.baseSalary))),
                currentIncome: Math.max(0, number(source.growth?.currentIncome, number(oldSalary.currentSalary))),
                history: array(source.growth?.history || source.growthTracker?.incomeGrowthHistory),
                ideas: array(source.growth?.ideas || oldSalary.ideas).map(idea =>
                    typeof idea === 'string'
                        ? { id: createId(), title: idea, status: 'idea' }
                        : { id: idea?.id || createId(), title: String(idea?.title || ''), status: idea?.status || 'idea' }
                )
            }
        };
    }

    function loadData() {
        try {
            const stored = localStorage.getItem(STORAGE_KEY);
            return normalize(stored ? JSON.parse(stored) : null);
        } catch (error) {
            console.error('[Finance] Не удалось прочитать данные:', error);
            return defaults();
        }
    }

    function saveData() {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
            document.dispatchEvent(new CustomEvent('goaltracker:finance-changed'));
        } catch (error) {
            console.error('[Finance] Не удалось сохранить данные:', error);
        }
    }

    function createId() {
        if (window.crypto?.randomUUID) return window.crypto.randomUUID();
        const bytes = new Uint8Array(16);
        if (window.crypto?.getRandomValues) window.crypto.getRandomValues(bytes);
        else for (let i=0;i<bytes.length;i++) bytes[i]=Math.floor(Math.random()*256);
        bytes[6]=(bytes[6]&15)|64; bytes[8]=(bytes[8]&63)|128;
        const hex=Array.from(bytes,value=>value.toString(16).padStart(2,'0')).join('');
        return `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`;
    }

    function today() {
        return new Date().toISOString().slice(0, 10);
    }

    function money(value) {
        return `${number(value).toLocaleString('ru-RU', { maximumFractionDigits: 2 })} ₽`;
    }

    function percent(value) {
        return `${number(value).toLocaleString('ru-RU', { maximumFractionDigits: 1 })}%`;
    }

    function escapeHtml(value) {
        const element = document.createElement('div');
        element.textContent = String(value ?? '');
        return element.innerHTML;
    }

    function monthKey(date = new Date()) {
        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
    }

    function currentMonthTransactions() {
        const month = monthKey();
        return data.transactions.filter(item => String(item.date).startsWith(month));
    }

    function totals() {
        return currentMonthTransactions().reduce((result, item) => {
            result[item.type] += number(item.amount);
            return result;
        }, { income: 0, expense: 0 });
    }

    function averageMonthlyExpenses() {
        const expenses = data.transactions.filter(item => item.type === 'expense');
        if (!expenses.length) return 0;
        const monthly = new Map();
        expenses.forEach(item => {
            const key = String(item.date).slice(0, 7) || monthKey();
            monthly.set(key, (monthly.get(key) || 0) + number(item.amount));
        });
        return [...monthly.values()].reduce((sum, value) => sum + value, 0) / monthly.size;
    }

    function progress(value, tone = '') {
        const safe = Math.max(0, Math.min(100, number(value)));
        return `<div class="finance-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(safe)}"><span class="${tone}" style="width:${safe}%"></span></div>`;
    }

    function emptyState(text) {
        return `<div class="finance-empty">${escapeHtml(text)}</div>`;
    }

    function renderAccounting() {
        const summary = totals();
        const balance = summary.income - summary.expense;
        const recent = [...data.transactions].sort((a, b) => String(b.date).localeCompare(String(a.date))).slice(0, 30);
        return `
            <div class="finance-terminal"><div class="finance-summary-grid">
                <article class="finance-metric balance"><span>Баланс месяца <span aria-hidden="true">↗</span></span><strong>${money(balance)}</strong><small>Доходы минус расходы</small></article>
                <article class="finance-metric"><span>Финансовая подушка <span aria-hidden="true">◈</span></span><strong>${money(data.safetyFund.balance)}</strong><small>Накоплено к текущему моменту</small></article>
                <article class="finance-metric income"><span>Доход за месяц <span aria-hidden="true">↓</span></span><strong>${money(summary.income)}</strong><small>Расходы: ${money(summary.expense)}</small></article>
            </div>
            <div class="finance-layout">
                <details class="finance-card finance-entry"><summary><span>+ Новая операция</span><span class="entry-disclosure">Раскрыть форму</span></summary>
                    <form class="finance-form" data-finance-form="transaction">
                        <div class="finance-segmented" role="group" aria-label="Тип операции">
                            <label><input type="radio" name="type" value="expense" checked><span>Расход</span></label>
                            <label><input type="radio" name="type" value="income"><span>Доход</span></label>
                        </div>
                        <div class="finance-form-grid">
                            <label><span>Сумма</span><input name="amount" type="number" min="0.01" step="0.01" inputmode="decimal" placeholder="0" required></label>
                            <label><span>Категория</span><select name="category">${Object.entries(CATEGORY_NAMES).map(([key, name]) => `<option value="${key}">${name}</option>`).join('')}</select></label>
                            <label><span>Дата</span><input name="date" type="date" value="${today()}" required></label>
                            <label class="finance-field-wide"><span>Описание</span><input name="description" maxlength="100" placeholder="Например, продукты"></label>
                        </div>
                        <button class="btn btn-primary finance-submit" type="submit">Добавить операцию</button>
                    </form>
                </details>
                <section class="finance-card">
                    <div class="finance-card-head"><div><span class="finance-kicker">История</span><h3>Последние операции</h3></div><span class="finance-count">${data.transactions.length}</span></div>
                    <div class="finance-ledger-wrap"><table class="finance-ledger"><thead><tr><th>Дата</th><th>Операция</th><th>Категория</th><th>Сумма</th></tr></thead><tbody>
                        ${recent.length ? recent.map(item => `<tr><td>${escapeHtml(item.date)}</td><td><span class="ledger-description"><span class="ledger-category-icon" aria-hidden="true">${({salary:"↓",freelance:"⌘",food:"◉",transport:"↗",housing:"⌂",health:"♡",entertainment:"▷"})[item.category] || "◇"}</span><strong>${escapeHtml(item.description || CATEGORY_NAMES[item.category] || 'Операция')}</strong></span></td><td class="ledger-category">${escapeHtml(CATEGORY_NAMES[item.category] || item.category)}</td><td class="${item.type}">${item.type === 'income' ? '+' : '-'}${money(item.amount)}</td></tr>`).join('') : '<tr><td colspan="4">Операций пока нет</td></tr>'}
                    </tbody></table></div>
                </section>
            </div></div>`;
    }

    function renderBudget() {
        const spending = currentMonthTransactions().filter(item => item.type === 'expense').reduce((map, item) => {
            map[item.category] = (map[item.category] || 0) + number(item.amount);
            return map;
        }, {});
        const categories = Object.entries(data.budget.categories);
        return `
            <section class="finance-card">
                <div class="finance-card-head"><div><span class="finance-kicker">Шаг 2</span><h3>Бюджет на текущий месяц</h3></div><span class="finance-hint">Лимиты сохраняются автоматически</span></div>
                <form data-finance-form="budget" class="finance-budget-list">
                    ${categories.map(([key, category]) => {
                        const spent = number(spending[key]);
                        const limit = number(category.limit);
                        const used = limit > 0 ? spent / limit * 100 : 0;
                        const tone = used >= 100 ? 'danger' : used >= 80 ? 'warning' : '';
                        return `<div class="finance-budget-row">
                            <div class="finance-budget-meta"><strong>${escapeHtml(category.name)}</strong><span>${money(spent)} из ${money(limit)}</span></div>
                            ${progress(used, tone)}
                            <label><span>Лимит</span><input name="limit-${escapeHtml(key)}" type="number" min="0" step="100" value="${limit}"></label>
                        </div>`;
                    }).join('')}
                    <button class="btn btn-primary finance-submit" type="submit">Сохранить лимиты</button>
                </form>
            </section>`;
    }

    function renderSafety() {
        const monthly = averageMonthlyExpenses();
        const months = monthly > 0 ? data.safetyFund.balance / monthly : 0;
        const targetAmount = monthly * data.safetyFund.targetMonths;
        const completed = targetAmount > 0 ? data.safetyFund.balance / targetAmount * 100 : 0;
        return `
            <div class="finance-summary-grid">
                <article class="finance-metric balance"><span>Накоплено</span><strong data-safety-balance>${money(data.safetyFund.balance)}</strong></article>
                <article class="finance-metric"><span>Средние расходы</span><strong>${money(monthly)} / мес.</strong></article>
                <article class="finance-metric"><span>Запас</span><strong data-safety-months>${months.toLocaleString('ru-RU', { maximumFractionDigits: 1 })} мес.</strong></article>
            </div>
            <section class="finance-card">
                <div class="finance-card-head"><div><span class="finance-kicker">Шаг 3</span><h3>Финансовая подушка</h3></div><strong data-safety-percent>${percent(completed)}</strong></div>
                ${progress(completed)}
                <p class="finance-caption">Цель: ${data.safetyFund.targetMonths} мес. расходов · ${money(targetAmount)}</p>

                <p class="custodian-status" role="status" aria-live="polite" aria-atomic="true"></p>

                <div class="piggy-quick-row" aria-label="Быстрое пополнение">
                    <button class="piggy-quick-chip" type="button" data-piggy-quick="500">+500 ₽</button>
                    <button class="piggy-quick-chip" type="button" data-piggy-quick="1000">+1 000 ₽</button>
                    <button class="piggy-quick-chip" type="button" data-piggy-quick="2000">+2 000 ₽</button>
                    <button class="piggy-quick-chip" type="button" data-piggy-quick="5000">+5 000 ₽</button>
                    <button class="piggy-quick-chip is-manual" type="button" data-piggy-toggle aria-expanded="${depositFormOpen}" aria-controls="piggyDepositForm">${depositFormOpen ? '✖ Закрыть ввод' : '+ Другая сумма'}</button>
                </div>

                <form class="finance-form finance-inline-form piggy-deposit-form${depositFormOpen ? '' : ' is-collapsed'}" id="piggyDepositForm" data-finance-form="deposit">
                    <label><span>Сумма пополнения</span><input name="amount" type="number" min="0.01" step="0.01" placeholder="0" required></label>
                    <button class="btn btn-primary" type="submit">Сохранить</button>
                </form>
                <p class="finance-hint piggy-safe-note${depositFormOpen ? '' : ' is-collapsed'}">Только сумма — без карт, CVV и паролей. Данные хранятся локально в вашем браузере.</p>

                <form class="finance-form finance-inline-form piggy-goal-form" data-finance-form="safety">
                    <label><span>Цель в месяцах</span><input name="targetMonths" type="number" min="1" max="36" step="1" value="${data.safetyFund.targetMonths}" required></label>
                    <button class="btn btn-secondary" type="submit">Сохранить цель</button>
                </form>
            </section>`;
    }

    // Effects never change the deposit balance or rebuild the scene.
    function clearCustodianCelebration(stage = document.querySelector('.custodian-stage')) {
        celebrationTimers.forEach(window.clearTimeout);
        celebrationTimers = [];
        stage?.classList.remove('is-celebrating');
        stage?.querySelector('.custodian-confetti')?.replaceChildren();
    }

    function syncCustodianVisibility() {
        const stage = document.querySelector('.custodian-stage');
        if (!stage) return;
        const paused = document.hidden || stage.dataset.offscreen === 'true';
        stage.classList.toggle('is-paused', paused);
        if (paused || motionPreference?.matches) clearCustodianCelebration(stage);
    }

    function setupCustodianScene() {
        custodianObserver?.disconnect();
        const stage = document.querySelector('.custodian-stage');
        if (!stage) return;
        if ('IntersectionObserver' in window) {
            stage.dataset.offscreen = 'true';
            custodianObserver = new IntersectionObserver(entries => {
                if (!stage.isConnected) return;
                stage.dataset.offscreen = String(!entries[0].isIntersecting);
                syncCustodianVisibility();
            }, { threshold: 0 });
            custodianObserver.observe(stage);
        }
        syncCustodianVisibility();
    }

    function celebrateCustodian() {
        const stage = document.querySelector('.custodian-stage');
        if (!stage) return;
        clearCustodianCelebration(stage);
        if (document.hidden || motionPreference?.matches || stage.classList.contains('is-paused')) return;
        // One layout read restarts only this finite animation after rapid deposits.
        void stage.offsetWidth;
        stage.classList.add('is-celebrating');
        celebrationTimers.push(window.setTimeout(() => {
            if (!stage.isConnected || document.hidden) return;
            const host = stage.querySelector('.custodian-confetti');
            if (!host) return;
            for (let i = 0; i < 24; i += 1) {
                const particle = document.createElement('i');
                const angle = i / 24 * Math.PI * 2;
                const radius = 65 + Math.random() * 65;
                particle.style.setProperty('--burst-x', `${Math.cos(angle) * radius}px`);
                particle.style.setProperty('--burst-y', `${Math.sin(angle) * radius + 35}px`);
                particle.style.setProperty('--burst-turn', `${90 + Math.random() * 270}deg`);
                particle.style.setProperty('--burst-color', i % 3 === 0 ? '#ecfeff' : i % 2 ? '#22d3ee' : '#fbbf24');
                host.appendChild(particle);
            }
        }, 500));
        celebrationTimers.push(window.setTimeout(() => clearCustodianCelebration(stage), 2500));
    }

    function addSafetyDeposit(value) {
        const amount = Math.max(0, number(value));
        if (amount <= 0) return false;
        data.safetyFund.balance += amount;
        data.safetyFund.history.push({ date: today(), balance: data.safetyFund.balance });
        data.safetyFund.newDepositMade = true;
        return true;
    }

    function animateSafetyValue(element) {
        if (!element) return;
        element.classList.remove('is-updating');
        void element.offsetWidth;
        element.classList.add('is-updating');
    }

    function updateSafetyUi() {
        const monthly = averageMonthlyExpenses();
        const months = monthly > 0 ? data.safetyFund.balance / monthly : 0;
        const targetAmount = monthly * data.safetyFund.targetMonths;
        const completed = targetAmount > 0 ? data.safetyFund.balance / targetAmount * 100 : 0;
        const safeProgress = Math.max(0, Math.min(100, number(completed)));
        const balanceElement = document.querySelector('[data-safety-balance]');
        const monthsElement = document.querySelector('[data-safety-months]');
        const percentElement = document.querySelector('[data-safety-percent]');
        const progressElement = document.querySelector('.finance-card .finance-progress');
        if (balanceElement) balanceElement.textContent = money(data.safetyFund.balance);
        if (monthsElement) monthsElement.textContent = `${months.toLocaleString('ru-RU', { maximumFractionDigits: 1 })} мес.`;
        if (percentElement) percentElement.textContent = percent(completed);
        if (progressElement) {
            progressElement.setAttribute('aria-valuenow', String(Math.round(safeProgress)));
            const fill = progressElement.querySelector('span');
            if (fill) fill.style.width = `${safeProgress}%`;
        }
        [balanceElement, monthsElement, percentElement].forEach(animateSafetyValue);
    }

    function closeManualDepositForm() {
        depositFormOpen = false;
        const form = document.getElementById('piggyDepositForm');
        const note = document.querySelector('.piggy-safe-note');
        const toggle = document.querySelector('[data-piggy-toggle]');
        form?.classList.add('is-collapsed');
        note?.classList.add('is-collapsed');
        if (toggle) {
            toggle.setAttribute('aria-expanded', 'false');
            toggle.textContent = '+ Другая сумма';
        }
    }

    function toggleManualDepositForm() {
        depositFormOpen = !depositFormOpen;
        const form = document.getElementById('piggyDepositForm');
        const note = document.querySelector('.piggy-safe-note');
        const toggle = document.querySelector('[data-piggy-toggle]');
        form?.classList.toggle('is-collapsed', !depositFormOpen);
        note?.classList.toggle('is-collapsed', !depositFormOpen);
        if (toggle) {
            toggle.setAttribute('aria-expanded', String(depositFormOpen));
            toggle.textContent = depositFormOpen ? '✖ Закрыть ввод' : '+ Другая сумма';
        }
        if (depositFormOpen) form?.querySelector('input[name="amount"]')?.focus();
    }

    function completeInstantDeposit(value, closeForm = false) {
        if (!addSafetyDeposit(value)) return false;
        updateSafetyUi();
        if (closeForm) closeManualDepositForm();
        // This deposit is already acknowledged; reopening the tab must not replay it.
        data.safetyFund.newDepositMade = false;
        data.safetyFund.lastSeenBalance = data.safetyFund.balance;
        saveData();
        const status = document.querySelector('.custodian-status');
        if (status) status.textContent = `Подушка пополнена на ${money(number(value))}`;
        celebrateCustodian();
        return true;
    }

    // Acknowledge imported/legacy deposits without replaying a button celebration.
    function acknowledgeSavingsOnEntry() {
        const fund = data.safetyFund;
        const hasNewDeposit = fund.newDepositMade === true;
        const balanceGrew = fund.balance > fund.lastSeenBalance;
        if (!hasNewDeposit && !balanceGrew) return;
        fund.newDepositMade = false;
        fund.lastSeenBalance = fund.balance;
        saveData();
    }

    function investmentTotals() {
        return data.investments.assets.reduce((result, asset) => {
            result.cost += asset.quantity * asset.buyPrice;
            result.value += asset.quantity * asset.currentPrice;
            return result;
        }, { cost: 0, value: 0 });
    }

    function renderInvestments() {
        const total = investmentTotals();
        const gain = total.value - total.cost;
        const roi = total.cost > 0 ? gain / total.cost * 100 : 0;
        return `
            <div class="finance-summary-grid">
                <article class="finance-metric"><span>Стоимость портфеля</span><strong>${money(total.value)}</strong></article>
                <article class="finance-metric ${gain >= 0 ? 'income' : 'expense'}"><span>Результат</span><strong>${gain >= 0 ? '+' : ''}${money(gain)}</strong></article>
                <article class="finance-metric"><span>Доходность</span><strong>${percent(roi)}</strong></article>
            </div>
            <section class="finance-card">
                <div class="finance-card-head"><div><span class="finance-kicker">Шаг 4</span><h3>Инвестиционный портфель</h3></div></div>
                <div class="finance-table-wrap">
                    ${data.investments.assets.length ? `<table class="finance-table"><thead><tr><th>Актив</th><th>Количество</th><th>Цена покупки</th><th>Текущая цена</th><th>Результат</th></tr></thead><tbody>${data.investments.assets.map(asset => {
                        const result = asset.quantity * (asset.currentPrice - asset.buyPrice);
                        return `<tr><td data-label="Актив"><strong>${escapeHtml(asset.symbol)}</strong><small>${escapeHtml(asset.name)}</small></td><td data-label="Количество">${asset.quantity}</td><td data-label="Цена покупки">${money(asset.buyPrice)}</td><td data-label="Текущая цена">${money(asset.currentPrice)}</td><td data-label="Результат" class="${result >= 0 ? 'finance-positive' : 'finance-negative'}">${result >= 0 ? '+' : ''}${money(result)}</td></tr>`;
                    }).join('')}</tbody></table>` : emptyState('Добавьте первый актив в портфель')}
                </div>
                <form class="finance-form finance-asset-form" data-finance-form="investment">
                    <label><span>Тикер</span><input name="symbol" maxlength="12" placeholder="AAPL" required></label>
                    <label><span>Название</span><input name="name" maxlength="60" placeholder="Apple"></label>
                    <label><span>Количество</span><input name="quantity" type="number" min="0.000001" step="any" required></label>
                    <label><span>Цена покупки</span><input name="buyPrice" type="number" min="0" step="0.01" required></label>
                    <label><span>Текущая цена</span><input name="currentPrice" type="number" min="0" step="0.01" required></label>
                    <button class="btn btn-primary" type="submit">Добавить актив</button>
                </form>
            </section>`;
    }

    function renderIncome() {
        const delta = data.growth.currentIncome - data.growth.baseIncome;
        const growth = data.growth.baseIncome > 0 ? delta / data.growth.baseIncome * 100 : 0;
        return `
            <div class="finance-summary-grid">
                <article class="finance-metric"><span>Базовый доход</span><strong>${money(data.growth.baseIncome)}</strong></article>
                <article class="finance-metric balance"><span>Текущий доход</span><strong>${money(data.growth.currentIncome)}</strong></article>
                <article class="finance-metric ${delta >= 0 ? 'income' : 'expense'}"><span>Изменение</span><strong>${delta >= 0 ? '+' : ''}${money(delta)} · ${percent(growth)}</strong></article>
            </div>
            <div class="finance-layout">
                <section class="finance-card">
                    <div class="finance-card-head"><div><span class="finance-kicker">Шаг 5</span><h3>Рост основного дохода</h3></div></div>
                    <form class="finance-form" data-finance-form="income">
                        <div class="finance-form-grid">
                            <label><span>Базовый доход</span><input name="baseIncome" type="number" min="0" step="100" value="${data.growth.baseIncome}" required></label>
                            <label><span>Текущий доход</span><input name="currentIncome" type="number" min="0" step="100" value="${data.growth.currentIncome}" required></label>
                        </div>
                        <button class="btn btn-primary finance-submit" type="submit">Обновить доход</button>
                    </form>
                </section>
                <section class="finance-card">
                    <div class="finance-card-head"><div><span class="finance-kicker">Дополнительный доход</span><h3>Идеи для подработки</h3></div></div>
                    <form class="finance-inline-form" data-finance-form="idea"><label><span>Новая идея</span><input name="title" maxlength="100" placeholder="Например, консультации" required></label><button class="btn btn-primary" type="submit">Добавить</button></form>
                    <div class="finance-ideas">${data.growth.ideas.length ? data.growth.ideas.map(idea => `<div class="finance-idea"><span>${escapeHtml(idea.title)}</span><span class="finance-status">Идея</span></div>`).join('') : emptyState('Список идей пока пуст')}</div>
                </section>
            </div>`;
    }

    const renderers = {
        accounting: renderAccounting,
        budget: renderBudget,
        safety: renderSafety,
        investments: renderInvestments,
        income: renderIncome
    };

    function renderFinanceView(externalEntry = false) {
        const container = document.getElementById('financeMain');
        if (!container) {
            console.error('[Finance] #financeMain not found');
            return;
        }
        data = normalize(data);
        bindEvents(container);
        const enteringSafety = activeStep === 'safety' && (externalEntry || renderedStep !== 'safety');
        renderedStep = activeStep;
        clearCustodianCelebration();
        custodianObserver?.disconnect();
        container.innerHTML = `
            <nav class="finance-tabs" aria-label="Шаги финансовой грамотности">
                ${[
                    ['accounting', 'Учёт'],
                    ['budget', 'Бюджет'],
                    ['safety', 'Подушка'],
                    ['investments', 'Инвестиции'],
                    ['income', 'Доход']
                ].map(([id, title]) => `<button type="button" class="finance-tab ${activeStep === id ? 'active' : ''}" data-finance-step="${id}" aria-selected="${activeStep === id}">${title}</button>`).join('')}
            </nav>
            <div class="finance-panel" data-finance-panel>${renderers[activeStep]()}</div>`;

        // Re-rendering replaces the strip; keep the selected mobile tab in view.
        window.app?.renderInspectorOverview?.();
        const tabs = container.querySelector('.finance-tabs');
        const selectedTab = tabs.querySelector('.active');
        if (window.matchMedia?.('(max-width: 600px)').matches && selectedTab) {
            tabs.scrollLeft = Math.max(0, selectedTab.offsetLeft - tabs.offsetLeft - (tabs.clientWidth - selectedTab.offsetWidth) / 2);
        }
        setupCustodianScene();
        if (activeStep === 'safety' && enteringSafety) acknowledgeSavingsOnEntry();
    }

    function bindEvents(container) {
        if (eventsBound) return;
        eventsBound = true;
        container.addEventListener('click', event => {
            const quickDeposit = event.target.closest('[data-piggy-quick]');
            if (quickDeposit) {
                completeInstantDeposit(quickDeposit.dataset.piggyQuick);
                return;
            }
            const toggle = event.target.closest('[data-piggy-toggle]');
            if (toggle) {
                toggleManualDepositForm();
                return;
            }
            const tab = event.target.closest('[data-finance-step]');
            if (!tab) return;
            activeStep = tab.dataset.financeStep;
            renderFinanceView();
        });
        container.addEventListener('submit', handleSubmit);
    }

    function handleSubmit(event) {
        const form = event.target.closest('[data-finance-form]');
        if (!form) return;
        event.preventDefault();
        const values = Object.fromEntries(new FormData(form));

        switch (form.dataset.financeForm) {
            case 'transaction': {
                const amount = number(values.amount);
                if (amount <= 0) return;
                data.transactions.push({ id: createId(), type: values.type === 'income' ? 'income' : 'expense', amount, category: values.category || 'other', description: String(values.description || '').trim(), date: values.date || today() });
                break;
            }
            case 'budget':
                Object.keys(data.budget.categories).forEach(key => {
                    data.budget.categories[key].limit = Math.max(0, number(values[`limit-${key}`]));
                });
                break;
            case 'safety':
                data.safetyFund.targetMonths = Math.max(1, number(values.targetMonths, 6));
                break;
            case 'deposit': {
                if (!completeInstantDeposit(values.amount, true)) return;
                form.reset();
                return;
            }
            case 'investment':
                data.investments.assets.push({ id: createId(), symbol: String(values.symbol || 'ASSET').trim().toUpperCase(), name: String(values.name || values.symbol || 'Актив').trim(), quantity: Math.max(0, number(values.quantity)), buyPrice: Math.max(0, number(values.buyPrice)), currentPrice: Math.max(0, number(values.currentPrice)) });
                break;
            case 'income':
                data.growth.baseIncome = Math.max(0, number(values.baseIncome));
                data.growth.currentIncome = Math.max(0, number(values.currentIncome));
                data.growth.history.push({ date: today(), monthlyIncome: data.growth.currentIncome });
                break;
            case 'idea':
                if (String(values.title || '').trim()) data.growth.ideas.push({ id: createId(), title: String(values.title).trim(), status: 'idea' });
                break;
            default:
                return;
        }
        saveData();
        renderFinanceView();
    }

    // Existing public finance API is preserved.
    function renderFinanceViewExternal() {
        renderFinanceView(true);
    }

    document.addEventListener('visibilitychange', syncCustodianVisibility);
    motionPreference?.addEventListener?.('change', syncCustodianVisibility);

    window.renderFinanceView = renderFinanceViewExternal;
    window.finance = { renderFinanceView: renderFinanceViewExternal,
        getData: () => JSON.parse(JSON.stringify(data)),
        clearData() { data = defaults(); activeStep = 'accounting'; renderedStep = null; depositFormOpen = false; celebrationTimers.forEach(id => clearTimeout(id)); celebrationTimers = []; custodianObserver?.disconnect(); document.getElementById('financeMain')?.replaceChildren(); },
        replaceData(next) {
            data = normalize(next);
            localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
            if (window.app?.currentView === 'finance') renderFinanceView();
        }
    };
})();
